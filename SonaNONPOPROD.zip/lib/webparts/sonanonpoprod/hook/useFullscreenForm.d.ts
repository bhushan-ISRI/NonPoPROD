export default function useFullscreenForm(): void;
//# sourceMappingURL=useFullscreenForm.d.ts.map