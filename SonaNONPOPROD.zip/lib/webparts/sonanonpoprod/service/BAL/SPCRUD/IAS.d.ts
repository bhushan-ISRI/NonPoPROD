import { IIAS } from "../../INTERFACE/IIAS";
import { ISonanonpoprodProps } from "../../../components/ISonanonpoprodProps";
export interface IIITRequestsOps {
    getIIASData(props: IIAS): Promise<IIAS>;
    getIASDatafilter(props: IIAS): Promise<IIAS>;
}
export default function IASRequestsOps(props: ISonanonpoprodProps): Promise<{
    getIIASData: (sorting: any, props: ISonanonpoprodProps, filter: string) => Promise<IIAS[]>;
    getIASDatafilter: (ArtId: string | number, props: ISonanonpoprodProps) => Promise<IIAS[]>;
}>;
//# sourceMappingURL=IAS.d.ts.map