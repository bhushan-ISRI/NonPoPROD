import type { ISonanonpoprodProps } from "../../../components/ISonanonpoprodProps";
export interface ISPCRUD {
    getData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: ISonanonpoprodProps): Promise<any>;
    getRootData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, props: ISonanonpoprodProps): Promise<any>;
    insertData(listName: string, data: any, props: ISonanonpoprodProps): Promise<any>;
    updateData(listName: string, itemId: number, data: any, props: ISonanonpoprodProps): Promise<any>;
    deleteData(listName: string, itemId: number, props: ISonanonpoprodProps): Promise<any>;
    getListInfo(listName: string, props: ISonanonpoprodProps): Promise<any>;
    getListData(listName: string, columnsToRetrieve: string, props: ISonanonpoprodProps): Promise<any>;
    getTopData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: ISonanonpoprodProps): Promise<any>;
    addAttchmentInList(attFiles: File, listName: string, itemId: number, fileName: string, props: ISonanonpoprodProps): Promise<any>;
}
export default function USESPCRUD(props: ISonanonpoprodProps): Promise<ISPCRUD>;
//# sourceMappingURL=spcrud.d.ts.map