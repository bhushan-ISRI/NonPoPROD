import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/attachments";
import { ISonanonpoprodProps } from "../../../components/ISonanonpoprodProps";
export interface ISPCRUD {
    [x: string]: any;
    getData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: ISonanonpoprodProps): Promise<any>;
    getRootData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: ISonanonpoprodProps): Promise<any>;
    insertData(listName: string, data: any, props: ISonanonpoprodProps): Promise<any>;
    updateData(listName: string, itemId: number, data: any, props: ISonanonpoprodProps): Promise<any>;
    deleteData(listName: string, itemId: number, props: ISonanonpoprodProps): Promise<any>;
    getListInfo(listName: string, props: ISonanonpoprodProps): Promise<any>;
    getListData(listName: string, columnsToRetrieve: string, props: ISonanonpoprodProps): Promise<any>;
    createFolder(listName: string, folderName: string, props: ISonanonpoprodProps): Promise<any>;
    addAttchmentInList(attFiles: File, listName: string, itemId: number, fileName: string, props: ISonanonpoprodProps): Promise<any>;
}
export default function USESPCRUD(this: any): Promise<ISPCRUD>;
//# sourceMappingURL=newspcrud.d.ts.map