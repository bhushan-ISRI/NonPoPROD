import { IDeviationDevProps } from "../../INTERFACE/IDeviationDevProps";
import "@pnp/sp/sputilities";
export interface IMonth {
    Id: number;
    Title: string;
    ShortMonth: string;
    NarrowMonth: string;
}
export interface TypedHash<T> {
    [key: string]: T;
}
export interface IUtilities {
    filterData(data: any[], filterValue: string, filterColumns: string[]): Promise<any[]>;
    MonthColl(): Array<IMonth>;
    sendEmail(to: string[], cc: string[], bcc: string[], subject: string, body: string, AdditionalHeaders: TypedHash<string>, props: IDeviationDevProps, from?: string): Promise<void>;
}
export default function Utilities(): Promise<IUtilities>;
//# sourceMappingURL=utilities.d.ts.map