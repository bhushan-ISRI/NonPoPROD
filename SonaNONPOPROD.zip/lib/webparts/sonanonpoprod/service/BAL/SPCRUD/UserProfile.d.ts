import "@pnp/sp/profiles";
import { IUserProfile } from "../../INTERFACE/IUserProfile";
import { ISonanonpoprodProps } from "../../../components/ISonanonpoprodProps";
declare const UserProfileOps: () => {
    getLoggUserProfile: (props: ISonanonpoprodProps) => Promise<IUserProfile>;
};
export default UserProfileOps;
//# sourceMappingURL=UserProfile.d.ts.map