import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/attachments";
import { ISonanonpoprodProps } from "../../components/ISonanonpoprodProps";
export interface ISPCRUDOPS {
    getData(listName: string, columnsToRetrieve?: string, columnsToExpand?: string, filters?: string, orderby?: {
        column: string;
        isAscending: boolean;
    }): Promise<any>;
    getRootData(listName: string, columnsToRetrieve?: string, columnsToExpand?: string, filters?: string, orderby?: {
        column: string;
        isAscending: boolean;
    }): Promise<any>;
    insertData(listName: string, data: any): Promise<any>;
    updateData(listName: string, itemId: number, data: any): Promise<any>;
    deleteData(listName: string, itemId: number): Promise<any>;
    getListInfo(listName: string): Promise<any>;
    getListData(listName: string, columnsToRetrieve?: string): Promise<any>;
    createFolder(listName: string, folderName: string): Promise<any>;
    addAttchmentInList(data: File, listName: string, itemId: number, fileName: string): Promise<any>;
}
export default function SPCRUDOPS(props: ISonanonpoprodProps): ISPCRUDOPS;
//# sourceMappingURL=newspcrudops.d.ts.map