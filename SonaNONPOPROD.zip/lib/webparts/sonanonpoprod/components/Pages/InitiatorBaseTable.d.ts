import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
export type NonPoStatus = "Pending for Approval" | "Sent Back" | "Approved" | "Rejected" | "Closed" | string;
export interface NonPoRow {
    requestNo: string;
    requestDate: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status: NonPoStatus;
    _spId?: number;
}
interface BaseProps {
    listTitle?: string;
    onAddNon?: () => void;
    onViewRow?: (row: NonPoRow) => void;
    title?: string;
    statusEquals?: NonPoStatus | NonPoStatus[];
    disableAuthorFilter?: boolean;
}
type InitiatorBaseTableProps = ISonanonpoprodProps & BaseProps;
declare const InitiatorBaseTable: React.FC<InitiatorBaseTableProps>;
export default InitiatorBaseTable;
//# sourceMappingURL=InitiatorBaseTable.d.ts.map