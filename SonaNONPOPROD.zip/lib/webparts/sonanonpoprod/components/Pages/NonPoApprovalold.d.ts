import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
type Props = ISonanonpoprodProps & {
    title?: string;
    listTitle?: string;
};
declare const NonPoApproval: React.FC<Props>;
export default NonPoApproval;
//# sourceMappingURL=NonPoApprovalold.d.ts.map