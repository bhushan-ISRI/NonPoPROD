import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
export type NonPoStatus = "Pending for Approval" | "Sent back" | "Approved" | "Rejected" | "Draft" | "Pending for Acceptance" | "Pending for Vouching" | "Closed" | string;
export interface ApprovalRow {
    requestNo: string;
    requestDate: string;
    buyerName: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status: NonPoStatus;
    _spId?: number;
    CurrentApproverEmail: string;
}
interface MyApprovalOwnProps {
    listTitle?: string;
    title?: string;
    onView?: (row: ApprovalRow) => void;
}
type MyApprovalProps = ISonanonpoprodProps & MyApprovalOwnProps;
/** ------ Component ------ */
declare const MyApproval: React.FC<MyApprovalProps>;
export default MyApproval;
//# sourceMappingURL=MyApproval.d.ts.map