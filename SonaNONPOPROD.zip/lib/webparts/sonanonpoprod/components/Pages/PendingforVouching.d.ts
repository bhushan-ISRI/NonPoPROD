import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
export interface PendingVouchRow {
    _spId: number;
    requestNo: string;
    requestDate: string;
    buyerName: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status?: string;
    CurrentApproverEmail?: string;
}
interface PendingforVouchingProps extends ISonanonpoprodProps {
    listTitle?: string;
    title?: string;
    vouchingViewPath?: string;
    vouchingEditPath?: string;
}
/** ---------------- Component ---------------- */
declare const PendingforVouching: React.FC<PendingforVouchingProps>;
export default PendingforVouching;
//# sourceMappingURL=PendingforVouching.d.ts.map