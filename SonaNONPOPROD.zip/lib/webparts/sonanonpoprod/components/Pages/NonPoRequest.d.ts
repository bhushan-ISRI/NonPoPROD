import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
import "@pnp/sp/site-users/web";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
declare const NonPoRequest: React.FC<ISonanonpoprodProps>;
export default NonPoRequest;
//# sourceMappingURL=NonPoRequest.d.ts.map