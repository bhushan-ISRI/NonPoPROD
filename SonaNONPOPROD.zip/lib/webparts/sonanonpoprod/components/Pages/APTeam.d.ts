import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
export interface APTeamRow {
    _spId: number;
    requestNo: string;
    requestDate: string;
    buyerName: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status?: string;
    CurrentApproverEmail: string;
}
interface APTeamProps extends ISonanonpoprodProps {
    listTitle?: string;
    title?: string;
}
declare const APTeam: React.FC<APTeamProps>;
export default APTeam;
//# sourceMappingURL=APTeam.d.ts.map