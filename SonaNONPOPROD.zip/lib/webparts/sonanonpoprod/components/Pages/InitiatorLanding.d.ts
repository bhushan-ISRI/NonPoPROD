import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
import './CSS/Sidebar.scss';
import './CSS/Landing.scss';
import './CSS/NewRequest.scss';
import './CSS/Sidebar.module.scss';
export type NonPoStatus = "Pending for Approval" | "Send Back" | "Approved" | "Rejected" | string;
export interface NonPoRow {
    requestNo: string;
    requestDate: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status: NonPoStatus;
    _spId?: number;
}
interface InitiatorLandingOwnProps {
    listTitle?: string;
    onAddNon?: () => void;
    onViewRow?: (row: NonPoRow) => void;
    title?: string;
}
type InitiatorLandingProps = ISonanonpoprodProps & InitiatorLandingOwnProps;
declare const InitiatorLanding: React.FC<InitiatorLandingProps>;
export default InitiatorLanding;
//# sourceMappingURL=InitiatorLanding.d.ts.map