import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
import "./CSS/NewRequest.scss";
export declare const Vouching: (props: ISonanonpoprodProps) => JSX.Element;
//# sourceMappingURL=Vouching.d.ts.map