import "../Pages/CSS/Sidebar.scss";
import { ISonanonpoprodProps } from "../ISonanonpoprodProps";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
declare const Sidebar: (props: ISonanonpoprodProps) => JSX.Element;
export default Sidebar;
//# sourceMappingURL=Sidebar.d.ts.map