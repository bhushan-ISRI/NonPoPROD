import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
import "./CSS/NewRequest.scss";
export declare const ViewRequestSendBack: (props: ISonanonpoprodProps) => JSX.Element;
//# sourceMappingURL=ViewRequestSendBack.d.ts.map