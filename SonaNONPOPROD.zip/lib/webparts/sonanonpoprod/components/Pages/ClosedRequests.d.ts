import React from "react";
import type { ISonanonpoprodProps } from "../ISonanonpoprodProps";
export interface ClosedRow {
    _spId: number;
    requestNo: string;
    requestDate: string;
    buyerName?: string;
    vendorCode: string;
    vendorName: string;
    invoiceNo: string;
    amount: number;
    status?: string;
}
interface ClosedRequestsProps extends ISonanonpoprodProps {
    listTitle?: string;
    title?: string;
    viewFormPath?: string;
}
/** ---------------- Component ---------------- */
declare const ClosedRequests: React.FC<ClosedRequestsProps>;
export default ClosedRequests;
//# sourceMappingURL=ClosedRequests.d.ts.map