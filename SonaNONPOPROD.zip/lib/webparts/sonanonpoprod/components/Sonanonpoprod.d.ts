import * as React from "react";
import { ISonanonpoprodProps } from "./ISonanonpoprodProps";
declare const Drr: React.FC<ISonanonpoprodProps>;
export default Drr;
//# sourceMappingURL=Sonanonpoprod.d.ts.map