"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = useFullscreenForm;
// src/hooks/useFullscreenForm.ts
var react_1 = require("react");
var react_router_dom_1 = require("react-router-dom");
function useFullscreenForm() {
    var location = (0, react_router_dom_1.useLocation)();
    (0, react_1.useEffect)(function () {
        var _a;
        var params = new URLSearchParams(location.search);
        var fromState = ((_a = location.state) === null || _a === void 0 ? void 0 : _a.fullscreen) === true;
        var fromQuery = params.get("fs") === "1";
        var shouldFullscreen = fromState || fromQuery;
        if (shouldFullscreen) {
            document.body.classList.add("no-sidebar");
        }
        else {
            document.body.classList.remove("no-sidebar");
        }
        return function () {
            document.body.classList.remove("no-sidebar");
        };
    }, [location]);
}
//# sourceMappingURL=useFullscreenForm.js.map