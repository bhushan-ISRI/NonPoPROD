"use strict";
// Utilities.ts (PnPjs v4 compatible)
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Utilities;
var tslib_1 = require("tslib");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all"); // <- SPFx binding
require("@pnp/sp/sputilities"); // <- attach utility APIs (sendEmail)
// --- create & reuse a single bound SP instance per runtime ---
var _sp = null;
function getSP(context) {
    if (!_sp) {
        _sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context)); // bind to SPFx web part context once
    }
    return _sp;
}
function Utilities() {
    var _this = this;
    return new Promise(function (resolve) {
        var utilities = {
            filterData: function (data, filterValue, filterColumns) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                var searchValue;
                return tslib_1.__generator(this, function (_a) {
                    if (!filterValue)
                        return [2 /*return*/, data];
                    searchValue = filterValue.toLowerCase();
                    return [2 /*return*/, data.filter(function (item) {
                            return filterColumns.some(function (column) {
                                var value = item[column];
                                if (value === null || value === undefined)
                                    return false;
                                return value.toString().toLowerCase().includes(searchValue);
                            });
                        })];
                });
            }); },
            MonthColl: function () {
                var months = [];
                var now = new Date();
                for (var m = 0; m <= 11; m++) {
                    var dt = new Date(now.getFullYear(), m, 1);
                    months.push({
                        Id: m + 1,
                        Title: dt.toLocaleString("en-us", { month: "long" }),
                        ShortMonth: dt.toLocaleString("en-us", { month: "short" }),
                        NarrowMonth: dt.toLocaleString("en-us", { month: "narrow" }),
                    });
                }
                return months;
            },
            sendEmail: function (to, cc, bcc, subject, body, additionalHeaders, props, from) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                var sp, emailProps;
                return tslib_1.__generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            sp = getSP(props.currentSPContext);
                            emailProps = {
                                To: to,
                                CC: cc,
                                BCC: bcc,
                                Subject: subject,
                                Body: body,
                            };
                            if (from && from.trim()) {
                                emailProps.From = from;
                            }
                            if (additionalHeaders) {
                                emailProps.AdditionalHeaders = additionalHeaders;
                            }
                            return [4 /*yield*/, sp.utility.sendEmail(emailProps)];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            }); },
        };
        resolve(utilities);
    });
}
//# sourceMappingURL=utilities.js.map