"use strict";
// src/service/SPCRUD.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = USESPCRUD;
var tslib_1 = require("tslib");
var spcrudops_1 = tslib_1.__importDefault(require("../../DAL/spcrudops"));
function USESPCRUD(props) {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var spCrudOps;
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, spcrudops_1.default)(props.currentSPContext)];
                case 1:
                    spCrudOps = _a.sent();
                    return [2 /*return*/, {
                            getData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getTopData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getRootData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getRootData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            insertData: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.insertData(listName, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            updateData: function (listName, itemId, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.updateData(listName, itemId, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            deleteData: function (listName, itemId, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.deleteData(listName, itemId, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getListInfo: function (listName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getListInfo(listName, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getListData: function (listName, columnsToRetrieve, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getListData(listName, columnsToRetrieve, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getTopData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getTopData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            addAttchmentInList: function (attFiles, listName, itemId, fileName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.addAttchmentInList(attFiles, listName, itemId, fileName, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                        }];
            }
        });
    });
}
//# sourceMappingURL=spcrud.js.map