"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = USESPCRUD;
var tslib_1 = require("tslib");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/folders");
require("@pnp/sp/files");
require("@pnp/sp/attachments");
//import NEWSPCRUDOPS from
var newspcrudops_1 = tslib_1.__importDefault(require("../../DAL/newspcrudops"));
function USESPCRUD() {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var props, newspCrudOps;
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            props = {
                currentSPContext: this.context,
                context: undefined,
                isDarkTheme: false,
                environmentMessage: "",
                hasTeamsContext: false,
                userDisplayName: "",
                userEmail: "",
            };
            newspCrudOps = (0, newspcrudops_1.default)(props);
            //  const newspCrudOps =SPCRUDOPS(props: ISonanonpoprodProps); //
            return [2 /*return*/, {
                    getData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.getData(listName, columnsToRetrieve, columnsToExpand, filters, orderby)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    getRootData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.getData(listName, columnsToRetrieve, columnsToExpand, filters, orderby)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    insertData: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.insertData(listName, data)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    updateData: function (listName, itemId, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.updateData(listName, itemId, data)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    deleteData: function (listName, itemId, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.deleteData(listName, itemId)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    getListInfo: function (listName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.getListInfo(listName)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    getListData: function (listName, columnsToRetrieve, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.getListData(listName, columnsToRetrieve)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    createFolder: function (listName, folderName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.createFolder(listName, folderName)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); },
                    // uploadFile: async (folderServerRelativeUrl: string, file: File, props: ISonanonpoprodProps) => {
                    //     return await newspCrudOps.uploadFile(folderServerRelativeUrl, file, props);
                    // },
                    // deleteFile: async (fileServerRelativeUrl: string, props: ISonanonpoprodProps) => {
                    //     return await newspCrudOps.deleteFile(fileServerRelativeUrl, props);
                    // },
                    addAttchmentInList: function (attFiles, listName, itemId, fileName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, newspCrudOps.addAttchmentInList(attFiles, listName, itemId, fileName)];
                                case 1: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); }
                }];
        });
    });
}
//# sourceMappingURL=newspcrud.js.map