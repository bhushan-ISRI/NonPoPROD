"use strict";
// UserProfile.ts (PnPjs v4-compatible)
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all"); // SPFx binding helper
require("@pnp/sp/profiles"); // attach profiles APIs
// --- simple singleton so we bind context once and reuse ---
var _sp = null;
function getSP(context) {
    if (!_sp) {
        _sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context)); // bind SPFx web part context
    }
    return _sp;
}
var UserProfileOps = function () {
    var getLoggUserProfile = function (props) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, myProps, propsArr, getVal, loc;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    sp = getSP(props.currentSPContext);
                    return [4 /*yield*/, sp.profiles.myProperties()];
                case 1:
                    myProps = _b.sent();
                    propsArr = ((_a = myProps === null || myProps === void 0 ? void 0 : myProps.UserProfileProperties) !== null && _a !== void 0 ? _a : []).map(function (p) { return ({
                        Key: p === null || p === void 0 ? void 0 : p.Key,
                        Value: p === null || p === void 0 ? void 0 : p.Value,
                    }); });
                    getVal = function (key) { var _a, _b; return (_b = (_a = propsArr.find(function (p) { return p.Key === key; })) === null || _a === void 0 ? void 0 : _a.Value) !== null && _b !== void 0 ? _b : ""; };
                    loc = getVal("SPS-Location") ||
                        getVal("Office") ||
                        getVal("SPS-OfficeLocation") ||
                        getVal("OfficeNumber") ||
                        getVal("PhysicalDeliveryOfficeName") ||
                        "";
                    return [2 /*return*/, {
                            accountName: myProps === null || myProps === void 0 ? void 0 : myProps.AccountName,
                            displayName: myProps === null || myProps === void 0 ? void 0 : myProps.DisplayName,
                            email: myProps === null || myProps === void 0 ? void 0 : myProps.Email,
                            Location: loc,
                            UserProfileProperties: propsArr,
                            get: function (key) { return getVal(key); },
                        }];
            }
        });
    }); };
    return { getLoggUserProfile: getLoggUserProfile };
};
exports.default = UserProfileOps;
//# sourceMappingURL=UserProfile.js.map