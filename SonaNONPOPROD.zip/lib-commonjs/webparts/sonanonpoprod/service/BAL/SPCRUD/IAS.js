"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = IASRequestsOps;
var tslib_1 = require("tslib");
var spcrudops_1 = tslib_1.__importDefault(require("../../DAL/spcrudops"));
function IASRequestsOps(props) {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var spCrudOps, getIIASData, getIASDatafilter;
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, spcrudops_1.default)(props.currentSPContext)];
                case 1:
                    spCrudOps = _a.sent();
                    getIIASData = function (sorting, props, filter) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, spCrudOps];
                                case 1: return [4 /*yield*/, (_a.sent()).getData("IAS_List", "*,ApprovalNoteNo,SAPNo,MovementReason,Status,Stage,NA/ID,NA/Title,NA/EMail,DA/ID,DA/Title,DA/EMail,Details,Summary,WF,HeaderName,MovementType,Department,CostCenter,UniquePartImpact,GrossValue,NetValue,LastAction,CostCenterDescription,Author/Title,AttachmentFiles,NextApproverEmpID", "NA,DA,Author,AttachmentFiles", filter, sorting, props).then(function (results) {
                                        var brr = new Array();
                                        results.map(function (item) {
                                            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10;
                                            brr.push({
                                                ID: item.ID,
                                                ApprovalNoteNo: (_a = item === null || item === void 0 ? void 0 : item.ApprovalNoteNo) !== null && _a !== void 0 ? _a : null,
                                                SAPNo: (_b = item === null || item === void 0 ? void 0 : item.SAPNo) !== null && _b !== void 0 ? _b : null,
                                                MovementReason: (_c = item === null || item === void 0 ? void 0 : item.MovementReason) !== null && _c !== void 0 ? _c : null,
                                                Status: (_d = item === null || item === void 0 ? void 0 : item.Status) !== null && _d !== void 0 ? _d : null,
                                                Stage: (_e = item === null || item === void 0 ? void 0 : item.Stage) !== null && _e !== void 0 ? _e : null,
                                                NAID: (_g = (_f = item === null || item === void 0 ? void 0 : item.NA) === null || _f === void 0 ? void 0 : _f.ID) !== null && _g !== void 0 ? _g : null,
                                                NATitle: (_j = (_h = item === null || item === void 0 ? void 0 : item.NA) === null || _h === void 0 ? void 0 : _h.Title) !== null && _j !== void 0 ? _j : null,
                                                NAEmail: (_l = (_k = item === null || item === void 0 ? void 0 : item.NA) === null || _k === void 0 ? void 0 : _k.EMail) !== null && _l !== void 0 ? _l : null,
                                                DAID: (_o = (_m = item === null || item === void 0 ? void 0 : item.DA) === null || _m === void 0 ? void 0 : _m.ID) !== null && _o !== void 0 ? _o : null,
                                                DATitle: (_q = (_p = item === null || item === void 0 ? void 0 : item.DA) === null || _p === void 0 ? void 0 : _p.Title) !== null && _q !== void 0 ? _q : null,
                                                DAEmail: (_s = (_r = item === null || item === void 0 ? void 0 : item.DA) === null || _r === void 0 ? void 0 : _r.EMail) !== null && _s !== void 0 ? _s : null,
                                                Details: (_t = item === null || item === void 0 ? void 0 : item.Details) !== null && _t !== void 0 ? _t : null,
                                                Summary: (_u = item === null || item === void 0 ? void 0 : item.Summary) !== null && _u !== void 0 ? _u : null,
                                                WF: (_v = item === null || item === void 0 ? void 0 : item.WF) !== null && _v !== void 0 ? _v : null,
                                                HeaderName: (_w = item === null || item === void 0 ? void 0 : item.HeaderName) !== null && _w !== void 0 ? _w : null,
                                                MovementType: (_x = item === null || item === void 0 ? void 0 : item.MovementType) !== null && _x !== void 0 ? _x : null,
                                                Department: (_y = item === null || item === void 0 ? void 0 : item.Department) !== null && _y !== void 0 ? _y : null,
                                                CostCenter: (_z = item === null || item === void 0 ? void 0 : item.CostCenter) !== null && _z !== void 0 ? _z : null,
                                                UniquePartImpact: (_0 = item === null || item === void 0 ? void 0 : item.UniquePartImpact) !== null && _0 !== void 0 ? _0 : null,
                                                GrossValue: (_1 = item === null || item === void 0 ? void 0 : item.GrossValue) !== null && _1 !== void 0 ? _1 : null,
                                                NetValue: (_2 = item === null || item === void 0 ? void 0 : item.NetValue) !== null && _2 !== void 0 ? _2 : null,
                                                LastAction: (_3 = item === null || item === void 0 ? void 0 : item.LastAction) !== null && _3 !== void 0 ? _3 : null,
                                                CostCenterDescription: (_4 = item === null || item === void 0 ? void 0 : item.CostCenterDescription) !== null && _4 !== void 0 ? _4 : null,
                                                AttachmentFiles: null,
                                                Title: item === null || item === void 0 ? void 0 : item.Title,
                                                Author: (_5 = item === null || item === void 0 ? void 0 : item.Author.Title) !== null && _5 !== void 0 ? _5 : null,
                                                Created: (_6 = item === null || item === void 0 ? void 0 : item.Created) !== null && _6 !== void 0 ? _6 : null,
                                                NextApproverEmpID: (_7 = item === null || item === void 0 ? void 0 : item.NextApproverEmpID) !== null && _7 !== void 0 ? _7 : null,
                                                InitiatorEmpId: (_8 = item === null || item === void 0 ? void 0 : item.InitiatorEmpId) !== null && _8 !== void 0 ? _8 : null,
                                                DelegateApproverEmpID: (_9 = item === null || item === void 0 ? void 0 : item.DelegateApproverEmpID) !== null && _9 !== void 0 ? _9 : null,
                                                InventoryAttachment: (_10 = item === null || item === void 0 ? void 0 : item.InventoryAttachment) !== null && _10 !== void 0 ? _10 : null
                                            });
                                        });
                                        return brr;
                                    })];
                                case 2: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); };
                    getIASDatafilter = function (ArtId, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, spCrudOps];
                                case 1: return [4 /*yield*/, (_a.sent()).getData("IAS_List", "*,ApprovalNoteNo,SAPNo,MovementReason,Status,Stage,NA/ID,NA/Title,NA/EMail,DA/ID,DA/Title,DA/EMail,Details,Summary,WF,HeaderName,MovementType,Department,CostCenter,UniquePartImpact,GrossValue,NetValue,LastAction,CostCenterDescription,Author/Title,AttachmentFiles,NextApproverEmpID", "NA,DA,Author,AttachmentFiles", "Id eq '" + ArtId + "'"
                                    // , sorting,
                                    , { column: 'Order0', isAscending: true }, props).then(function (results) {
                                        var brr = new Array();
                                        results.map(function (item) {
                                            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11;
                                            brr.push({
                                                ID: item.ID,
                                                ApprovalNoteNo: (_a = item === null || item === void 0 ? void 0 : item.ApprovalNoteNo) !== null && _a !== void 0 ? _a : null,
                                                SAPNo: (_b = item === null || item === void 0 ? void 0 : item.SAPNo) !== null && _b !== void 0 ? _b : null,
                                                MovementReason: (_c = item === null || item === void 0 ? void 0 : item.MovementReason) !== null && _c !== void 0 ? _c : null,
                                                Status: (_d = item === null || item === void 0 ? void 0 : item.Status) !== null && _d !== void 0 ? _d : null,
                                                Stage: (_e = item === null || item === void 0 ? void 0 : item.Stage) !== null && _e !== void 0 ? _e : null,
                                                NAID: (_g = (_f = item === null || item === void 0 ? void 0 : item.NA) === null || _f === void 0 ? void 0 : _f.ID) !== null && _g !== void 0 ? _g : null,
                                                NATitle: (_j = (_h = item === null || item === void 0 ? void 0 : item.NA) === null || _h === void 0 ? void 0 : _h.Title) !== null && _j !== void 0 ? _j : null,
                                                NAEmail: (_l = (_k = item === null || item === void 0 ? void 0 : item.NA) === null || _k === void 0 ? void 0 : _k.EMail) !== null && _l !== void 0 ? _l : null,
                                                DAID: (_o = (_m = item === null || item === void 0 ? void 0 : item.DA) === null || _m === void 0 ? void 0 : _m.ID) !== null && _o !== void 0 ? _o : null,
                                                DATitle: (_q = (_p = item === null || item === void 0 ? void 0 : item.DA) === null || _p === void 0 ? void 0 : _p.Title) !== null && _q !== void 0 ? _q : null,
                                                DAEmail: (_s = (_r = item === null || item === void 0 ? void 0 : item.DA) === null || _r === void 0 ? void 0 : _r.EMail) !== null && _s !== void 0 ? _s : null,
                                                Details: (_t = item === null || item === void 0 ? void 0 : item.Details) !== null && _t !== void 0 ? _t : null,
                                                Summary: (_u = item === null || item === void 0 ? void 0 : item.Summary) !== null && _u !== void 0 ? _u : null,
                                                WF: (_v = item === null || item === void 0 ? void 0 : item.WF) !== null && _v !== void 0 ? _v : null,
                                                HeaderName: (_w = item === null || item === void 0 ? void 0 : item.HeaderName) !== null && _w !== void 0 ? _w : null,
                                                MovementType: (_x = item === null || item === void 0 ? void 0 : item.MovementType) !== null && _x !== void 0 ? _x : null,
                                                Department: (_y = item === null || item === void 0 ? void 0 : item.Department) !== null && _y !== void 0 ? _y : null,
                                                CostCenter: (_z = item === null || item === void 0 ? void 0 : item.CostCenter) !== null && _z !== void 0 ? _z : null,
                                                UniquePartImpact: (_0 = item === null || item === void 0 ? void 0 : item.UniquePartImpact) !== null && _0 !== void 0 ? _0 : null,
                                                GrossValue: (_1 = item === null || item === void 0 ? void 0 : item.GrossValue) !== null && _1 !== void 0 ? _1 : null,
                                                NetValue: (_2 = item === null || item === void 0 ? void 0 : item.NetValue) !== null && _2 !== void 0 ? _2 : null,
                                                LastAction: (_3 = item === null || item === void 0 ? void 0 : item.LastAction) !== null && _3 !== void 0 ? _3 : null,
                                                CostCenterDescription: (_4 = item === null || item === void 0 ? void 0 : item.CostCenterDescription) !== null && _4 !== void 0 ? _4 : null,
                                                AttachmentFiles: (_5 = item === null || item === void 0 ? void 0 : item.AttachmentFiles) !== null && _5 !== void 0 ? _5 : null,
                                                Title: item === null || item === void 0 ? void 0 : item.Title,
                                                Author: (_6 = item === null || item === void 0 ? void 0 : item.Author.Title) !== null && _6 !== void 0 ? _6 : null,
                                                Created: (_7 = item === null || item === void 0 ? void 0 : item.Created) !== null && _7 !== void 0 ? _7 : null,
                                                NextApproverEmpID: (_8 = item === null || item === void 0 ? void 0 : item.NextApproverEmpID) !== null && _8 !== void 0 ? _8 : null,
                                                InitiatorEmpId: (_9 = item === null || item === void 0 ? void 0 : item.InitiatorEmpId) !== null && _9 !== void 0 ? _9 : null,
                                                DelegateApproverEmpID: (_10 = item === null || item === void 0 ? void 0 : item.DelegateApproverEmpID) !== null && _10 !== void 0 ? _10 : null,
                                                InventoryAttachment: (_11 = item === null || item === void 0 ? void 0 : item.InventoryAttachment) !== null && _11 !== void 0 ? _11 : null
                                            });
                                        });
                                        return brr;
                                    })];
                                case 2: return [2 /*return*/, _a.sent()];
                            }
                        });
                    }); };
                    return [2 /*return*/, {
                            getIIASData: getIIASData,
                            getIASDatafilter: getIASDatafilter
                        }];
            }
        });
    });
}
//# sourceMappingURL=IAS.js.map