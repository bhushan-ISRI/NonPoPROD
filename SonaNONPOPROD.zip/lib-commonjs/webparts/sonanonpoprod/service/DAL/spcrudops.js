"use strict";
// src/service/DAL/spcrudops.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SPCRUDOPS;
var tslib_1 = require("tslib");
var sp_1 = require("@pnp/sp");
var spfx_1 = require("@pnp/sp/behaviors/spfx");
// import { SPFx } from "@pnp/sp/presets/all"; 
// PnP feature imports
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
// import "@pnp/sp/items/get-all";
require("@pnp/sp/folders");
require("@pnp/sp/files");
require("@pnp/sp/attachments");
require("@pnp/sp/site-users/web");
require("@pnp/sp/site-groups/web");
// Singleton SPFI with SPFx behavior
var _sp = null;
var getSP = function (ctx) {
    if (!_sp) {
        _sp = (0, sp_1.spfi)().using((0, spfx_1.SPFx)(ctx)); //  registers fetch behavior
    }
    return _sp;
};
var SPCRUDOPSImpl = /** @class */ (function () {
    function SPCRUDOPSImpl() {
    }
    SPCRUDOPSImpl.prototype.applyQuery = function (items, columnsToRetrieve, columnsToExpand, filters, orderby) {
        if (columnsToRetrieve)
            items = items.select(columnsToRetrieve);
        if (columnsToExpand)
            items = items.expand(columnsToExpand);
        if (filters)
            items = items.filter(filters);
        if (orderby)
            items = items.orderBy(orderby.column, orderby.isAscending);
        return items;
    };
    SPCRUDOPSImpl.prototype.getData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        items = sp.web.lists.getByTitle(listName).items;
                        items = this.applyQuery(items, columnsToRetrieve, columnsToExpand, filters, orderby);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getRootData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        items = sp.web.lists.getByTitle(listName).items;
                        items = this.applyQuery(items, columnsToRetrieve, columnsToExpand, filters, orderby);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.insertData = function (listName, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        return [4 /*yield*/, sp.web.lists.getByTitle(listName).items.add(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.updateData = function (listName, itemId, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        return [4 /*yield*/, sp.web.lists.getByTitle(listName).items.getById(itemId).update(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.deleteData = function (listName, itemId, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        return [4 /*yield*/, sp.web.lists.getByTitle(listName).items.getById(itemId).recycle()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListInfo = function (listName, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        return [4 /*yield*/, sp.web.lists.getByTitle(listName)()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListData = function (listName, columnsToRetrieve, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        items = sp.web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve)
                            items = items.select(columnsToRetrieve);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getTopData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        items = sp.web.lists.getByTitle(listName).items;
                        items = this.applyQuery(items, columnsToRetrieve, columnsToExpand, filters, orderby);
                        if (top)
                            items = items.top(top);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.addAttchmentInList = function (attFiles, listName, itemId, fileName, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = getSP(props.currentSPContext);
                        return [4 /*yield*/, sp.web.lists
                                .getByTitle(listName)
                                .items.getById(itemId)
                                .attachmentFiles.add(fileName, attFiles)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    return SPCRUDOPSImpl;
}());
function SPCRUDOPS(ctx) {
    // Ensure SP is initialized once per app lifecycle
    getSP(ctx);
    return Promise.resolve(new SPCRUDOPSImpl());
}
//# sourceMappingURL=spcrudops.js.map