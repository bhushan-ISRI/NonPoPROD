"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SPCRUDOPS;
var tslib_1 = require("tslib");
// SPCRUDOPS.ts
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/folders");
require("@pnp/sp/files");
require("@pnp/sp/attachments");
var SPCRUDOPSImpl = /** @class */ (function () {
    function SPCRUDOPSImpl(props) {
        if (!(props === null || props === void 0 ? void 0 : props.currentSPContext))
            throw new Error("SharePoint context is not available");
        this.sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
    }
    SPCRUDOPSImpl.prototype.getData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        items = this.sp.web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve)
                            items = items.select(columnsToRetrieve);
                        if (columnsToExpand)
                            items = items.expand(columnsToExpand);
                        if (filters)
                            items = items.filter(filters);
                        if (orderby)
                            items = items.orderBy(orderby.column, orderby.isAscending);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()]; // v4 replacement for getAll()
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getRootData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2 /*return*/, this.getData(listName, columnsToRetrieve, columnsToExpand, filters, orderby)];
            });
        });
    };
    SPCRUDOPSImpl.prototype.insertData = function (listName, data) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName).items.add(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.updateData = function (listName, itemId, data) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName).items.getById(itemId).update(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.deleteData = function (listName, itemId) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName).items.getById(itemId).recycle()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListInfo = function (listName) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListData = function (listName, columnsToRetrieve) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        items = this.sp.web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve)
                            items = items.select(columnsToRetrieve);
                        return [4 /*yield*/, items()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.createFolder = function (listName, folderName) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName).rootFolder.folders.addUsingPath(folderName)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // async uploadFile(folderServerRelativeUrl: string, file: File): Promise<any> {
    //     return await this.sp.web.getFolderByServerRelativeUrl(folderServerRelativeUrl).files.add(file.name, file, true);
    // }
    // async deleteFile(fileServerRelativeUrl: string): Promise<any> {
    //     return await this.sp.web.getFileByServerRelativeUrl(fileServerRelativeUrl).recycle();
    // }
    SPCRUDOPSImpl.prototype.addAttchmentInList = function (data, listName, itemId, fileName) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.sp.web.lists.getByTitle(listName).items.getById(itemId).attachmentFiles.add(fileName, data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    return SPCRUDOPSImpl;
}());
// ✅ Factory function
function SPCRUDOPS(props) {
    return new SPCRUDOPSImpl(props);
}
//# sourceMappingURL=newspcrudops.js.map