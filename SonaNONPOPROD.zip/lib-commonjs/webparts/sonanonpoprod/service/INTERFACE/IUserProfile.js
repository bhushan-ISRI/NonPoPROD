"use strict";
// src/service/INTERFACE/IUserProfile.ts
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IUserProfile.js.map