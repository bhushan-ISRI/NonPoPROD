"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var useFullscreenForm_1 = tslib_1.__importDefault(require("../../hook/useFullscreenForm"));
var spcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/spcrudops"));
var ROUTE_APPROVED = "/MyApprovalApproved";
var ROUTE_REJECTED = "/MyApprovalRejected";
var ROUTE_APTEAM = "/APTeamDashboard";
var HISTORY_LIST = "NonPOApprovalHistory";
var HISTORY_PARENT_FIELD = "ParentId";
/** ======  helpers ====== */
var fmtDate = function (d) {
    if (!d)
        return "—";
    var dt = new Date(d);
    if (Number.isNaN(dt.getTime()))
        return "—";
    var dd = dt.getDate().toString().padStart(2, "0");
    var mm = (dt.getMonth() + 1).toString().padStart(2, "0");
    var yyyy = dt.getFullYear();
    return "".concat(dd, "/").concat(mm, "/").concat(yyyy);
};
var toText = function (v) { return (v === null || v === undefined || v === "" ? "—" : String(v)); };
var ci = function (s) { return (s !== null && s !== void 0 ? s : "").trim().toLowerCase(); };
//export const NonPoApproval = (props: ISonanonpoprodProps) => {
var NonPoApproval = function (_a) {
    var currentSPContext = _a.currentSPContext, _b = _a.title, title = _b === void 0 ? "NON PO Approval" : _b, _c = _a.listTitle, listTitle = _c === void 0 ? "NonPO" : _c;
    (0, useFullscreenForm_1.default)();
    var navigate = (0, react_router_dom_1.useNavigate)();
    var params = (0, react_router_dom_1.useSearchParams)()[0];
    var idParam = params.get("id");
    var modeParam = (params.get("mode") || "view").toLowerCase();
    var isEdit = modeParam === "edit";
    var numericId = (0, react_1.useMemo)(function () {
        var n = Number(idParam);
        return Number.isFinite(n) ? n : undefined;
    }, [idParam]);
    // UI state
    var _d = (0, react_1.useState)(false), loading = _d[0], setLoading = _d[1];
    var _e = (0, react_1.useState)(""), err = _e[0], setErr = _e[1];
    // Requester 
    var _f = (0, react_1.useState)(undefined), requestNo = _f[0], setRequestNo = _f[1];
    var _g = (0, react_1.useState)("—"), requestDate = _g[0], setRequestDate = _g[1];
    var _h = (0, react_1.useState)("—"), employeeName = _h[0], setEmployeeName = _h[1];
    var _j = (0, react_1.useState)("—"), division = _j[0], setDivision = _j[1];
    var _k = (0, react_1.useState)("—"), email = _k[0], setEmail = _k[1];
    var _l = (0, react_1.useState)("—"), hod = _l[0], setHod = _l[1];
    var _m = (0, react_1.useState)("—"), department = _m[0], setDepartment = _m[1];
    var _o = (0, react_1.useState)("—"), employeeStatus = _o[0], setEmployeeStatus = _o[1];
    var _p = (0, react_1.useState)("—"), contactNo = _p[0], setContactNo = _p[1];
    var _q = (0, react_1.useState)("—"), locationVal = _q[0], setLocationVal = _q[1];
    var _r = (0, react_1.useState)("—"), rm = _r[0], setRm = _r[1];
    // Invoice (editable in edit mode)
    var _s = (0, react_1.useState)("—"), vendorCode = _s[0], setVendorCode = _s[1];
    var _t = (0, react_1.useState)(""), vendorName = _t[0], setVendorName = _t[1];
    var _u = (0, react_1.useState)("—"), natureOfExpenses = _u[0], setNatureOfExpenses = _u[1];
    var _v = (0, react_1.useState)(""), invoiceNo = _v[0], setInvoiceNo = _v[1];
    var _w = (0, react_1.useState)("—"), invoiceDate = _w[0], setInvoiceDate = _w[1];
    var _x = (0, react_1.useState)(""), basicAmount = _x[0], setBasicAmount = _x[1];
    var _y = (0, react_1.useState)(""), gst = _y[0], setGst = _y[1];
    var _z = (0, react_1.useState)(""), otherCharges = _z[0], setOtherCharges = _z[1];
    var _0 = (0, react_1.useState)(""), totalAmount = _0[0], setTotalAmount = _0[1];
    var _1 = react_1.default.useState([]), ApprovalMatrixdata = _1[0], setApprovalMatrix = _1[1];
    var _2 = react_1.default.useState([]), WorkflowHistorydata = _2[0], setWorkflowHistory = _2[1];
    // Remarks
    var _3 = (0, react_1.useState)(""), paymentRemarks = _3[0], setPaymentRemarks = _3[1];
    var _4 = (0, react_1.useState)(""), approvalRemarks = _4[0], setApprovalRemarks = _4[1];
    var _5 = react_1.default.useState(false), HODApprover = _5[0], setHODApprover = _5[1];
    var _6 = react_1.default.useState(false), CFOApprover = _6[0], setCFOApprover = _6[1];
    var _7 = react_1.default.useState(false), PerformerApprover = _7[0], setPerformerApprover = _7[1];
    // History
    var _8 = (0, react_1.useState)([]), history = _8[0], setHistory = _8[1];
    /** =====history ===== */
    var loadItem = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, select, expand, orderBy, rows, it, parsedApprovalMatrix, parsedWorkflowHistory;
        var _a, _b, _c;
        return tslib_1.__generator(this, function (_d) {
            switch (_d.label) {
                case 0: return [4 /*yield*/, (0, spcrudops_1.default)(currentSPContext)];
                case 1:
                    spCrudOps = _d.sent();
                    select = "Id,Title,RequestDate,EmployeeName,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus," +
                        "ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,Status,PaymentRemarks,ApprovalRemarks," +
                        "VendorCode/Title,NatureofExpense/Title,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title";
                    expand = "VendorCode,NatureofExpense,CurrentApprover";
                    orderBy = { column: "Id", isAscending: false };
                    return [4 /*yield*/, spCrudOps.getTopData(listTitle, select, expand, "Id eq ".concat(numericId), orderBy, 1, { currentSPContext: currentSPContext })];
                case 2:
                    rows = (_a = (_d.sent())) !== null && _a !== void 0 ? _a : [];
                    if (!rows.length)
                        throw new Error("Item not found for ID: ".concat(numericId));
                    it = rows[0];
                    setRequestNo((it === null || it === void 0 ? void 0 : it.Title) || undefined);
                    // Requester (read-only)
                    setRequestDate(fmtDate(it === null || it === void 0 ? void 0 : it.RequestDate));
                    setEmployeeName(toText(it === null || it === void 0 ? void 0 : it.EmployeeName));
                    setDivision(toText(it === null || it === void 0 ? void 0 : it.Division));
                    setEmail(toText(it === null || it === void 0 ? void 0 : it.Email));
                    setHod(toText(it === null || it === void 0 ? void 0 : it.HOD));
                    setDepartment(toText(it === null || it === void 0 ? void 0 : it.Department));
                    setEmployeeStatus(toText(it === null || it === void 0 ? void 0 : it.EmployeeStatus));
                    setContactNo(toText(it === null || it === void 0 ? void 0 : it.ContactNo));
                    setLocationVal(toText(it === null || it === void 0 ? void 0 : it.Location));
                    setRm(toText(it === null || it === void 0 ? void 0 : it.RM));
                    // Invoice
                    setVendorCode(toText((_b = it === null || it === void 0 ? void 0 : it.VendorCode) === null || _b === void 0 ? void 0 : _b.Title));
                    setVendorName(toText(it === null || it === void 0 ? void 0 : it.VendorName) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.VendorName) || ""));
                    setNatureOfExpenses(toText((_c = it === null || it === void 0 ? void 0 : it.NatureofExpense) === null || _c === void 0 ? void 0 : _c.Title));
                    setInvoiceNo(toText(it === null || it === void 0 ? void 0 : it.InvoiceNumber) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.InvoiceNumber) || ""));
                    setInvoiceDate(fmtDate(it === null || it === void 0 ? void 0 : it.InvoiceDate));
                    setBasicAmount(toText(it === null || it === void 0 ? void 0 : it.Basicamount) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.Basicamount) || ""));
                    setGst(toText(it === null || it === void 0 ? void 0 : it.GST) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.GST) || ""));
                    setOtherCharges(toText(it === null || it === void 0 ? void 0 : it.OtherCharges) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.OtherCharges) || ""));
                    setTotalAmount(toText(it === null || it === void 0 ? void 0 : it.Totalamount) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.Totalamount) || ""));
                    setPaymentRemarks(toText(it === null || it === void 0 ? void 0 : it.PaymentRemarks) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.PaymentRemarks) || ""));
                    setApprovalRemarks(toText(it === null || it === void 0 ? void 0 : it.ApprovalRemarks) === "—" ? "" : String((it === null || it === void 0 ? void 0 : it.ApprovalRemarks) || ""));
                    parsedApprovalMatrix = [];
                    if (it.ApprovalMatrix) {
                        try {
                            parsedApprovalMatrix = JSON.parse(it.ApprovalMatrix);
                        }
                        catch (parseError) {
                            console.error("Error parsing ApprovalMatrix JSON:", parseError);
                        }
                    }
                    setApprovalMatrix(parsedApprovalMatrix);
                    parsedWorkflowHistory = [];
                    if (it.WorkflowHistory) {
                        try {
                            parsedWorkflowHistory = JSON.parse(it.WorkflowHistory);
                        }
                        catch (parseError) {
                            console.error("Error parsing WorkflowHistory JSON:", parseError);
                        }
                    }
                    setWorkflowHistory(parsedWorkflowHistory);
                    return [2 /*return*/];
            }
        });
    }); };
    var loadHistory = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, selectH, expandH, orderH, rowsH, mapped, e_1;
        var _a, _b;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _c.trys.push([0, 5, , 6]);
                    return [4 /*yield*/, (0, spcrudops_1.default)(currentSPContext)];
                case 1:
                    spCrudOps = _c.sent();
                    selectH = "Id,Title,ActionTaken,Remarks,ActionDate,Approver/Title";
                    expandH = "Approver";
                    orderH = { column: "Id", isAscending: false };
                    return [4 /*yield*/, spCrudOps.getRootData(HISTORY_LIST, selectH, expandH, "".concat(HISTORY_PARENT_FIELD, " eq ").concat(numericId), orderH, { currentSPContext: currentSPContext })];
                case 2:
                    rowsH = (_a = (_c.sent())) !== null && _a !== void 0 ? _a : [];
                    if (!(!rowsH.length && requestNo)) return [3 /*break*/, 4];
                    return [4 /*yield*/, spCrudOps.getRootData(HISTORY_LIST, selectH, expandH, "Title eq '".concat(String(requestNo).replace(/'/g, "''"), "'"), orderH, { currentSPContext: currentSPContext })];
                case 3:
                    rowsH =
                        (_b = (_c.sent())) !== null && _b !== void 0 ? _b : [];
                    _c.label = 4;
                case 4:
                    mapped = rowsH.map(function (h) {
                        var _a;
                        return ({
                            id: h === null || h === void 0 ? void 0 : h.Id,
                            approver: ((_a = h === null || h === void 0 ? void 0 : h.Approver) === null || _a === void 0 ? void 0 : _a.Title) || "—",
                            actionTaken: toText(h === null || h === void 0 ? void 0 : h.ActionTaken),
                            remarks: toText(h === null || h === void 0 ? void 0 : h.Remarks),
                            actionDate: fmtDate(h === null || h === void 0 ? void 0 : h.ActionDate),
                        });
                    });
                    setHistory(mapped);
                    return [3 /*break*/, 6];
                case 5:
                    e_1 = _c.sent();
                    console.warn("[NonPoApproval] history fetch warning:", e_1);
                    setHistory([]);
                    return [3 /*break*/, 6];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        var abort = false;
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var e_2;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, 4, 5]);
                        setLoading(true);
                        setErr("");
                        if (!numericId) {
                            setErr("Invalid or missing item ID in the URL.");
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, loadItem()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, loadHistory()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 5];
                    case 3:
                        e_2 = _a.sent();
                        console.error("[NonPoApproval] fetch error:", e_2);
                        setErr((e_2 === null || e_2 === void 0 ? void 0 : e_2.message) || "Failed to load item");
                        return [3 /*break*/, 5];
                    case 4:
                        if (!abort)
                            setLoading(false);
                        return [7 /*endfinally*/];
                    case 5: return [2 /*return*/];
                }
            });
        }); })();
        return function () { abort = true; };
    }, [currentSPContext, listTitle, numericId]);
    var handleSave = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, data, e_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    if (!isEdit || !numericId)
                        return [2 /*return*/];
                    return [4 /*yield*/, (0, spcrudops_1.default)(currentSPContext)];
                case 1:
                    spCrudOps = _a.sent();
                    data = { ApprovalRemarks: approvalRemarks !== null && approvalRemarks !== void 0 ? approvalRemarks : "" };
                    return [4 /*yield*/, spCrudOps.updateData(listTitle, numericId, data, { currentSPContext: currentSPContext })];
                case 2:
                    _a.sent();
                    alert("Approval Remarks saved.");
                    return [3 /*break*/, 4];
                case 3:
                    e_3 = _a.sent();
                    alert("Save failed: " + ((e_3 === null || e_3 === void 0 ? void 0 : e_3.message) || e_3));
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var updateStatus = function (newStatus) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, meName, isRM, isHOD, payload, e_4;
        var _a;
        var _b, _c, _d, _e;
        return tslib_1.__generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    if (!numericId)
                        return [2 /*return*/];
                    return [4 /*yield*/, (0, spcrudops_1.default)(currentSPContext)];
                case 1:
                    spCrudOps = _f.sent();
                    meName = ((_c = (_b = currentSPContext === null || currentSPContext === void 0 ? void 0 : currentSPContext.pageContext) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.displayName) ||
                        ((_e = (_d = currentSPContext === null || currentSPContext === void 0 ? void 0 : currentSPContext.pageContext) === null || _d === void 0 ? void 0 : _d.legacyPageContext) === null || _e === void 0 ? void 0 : _e.userDisplayName) ||
                        "";
                    isRM = ci(meName) === ci(rm);
                    isHOD = ci(meName) === ci(hod);
                    payload = { ApprovalRemarks: approvalRemarks !== null && approvalRemarks !== void 0 ? approvalRemarks : "" };
                    if (newStatus === "Rejected") {
                        payload = tslib_1.__assign(tslib_1.__assign({}, payload), { Status: "Rejected" });
                    }
                    else {
                        if (isHOD) {
                            payload = tslib_1.__assign(tslib_1.__assign({}, payload), { Status: "Pending for Acceptance" });
                        }
                        else if (isRM) {
                            payload = tslib_1.__assign(tslib_1.__assign({}, payload), { Status: "Pending for Approval" }); // stays pending for HOD
                        }
                        else {
                            payload = tslib_1.__assign(tslib_1.__assign({}, payload), { Status: "Pending for Approval" });
                        }
                    }
                    return [4 /*yield*/, spCrudOps.updateData(listTitle, numericId, payload, { currentSPContext: currentSPContext })];
                case 2:
                    _f.sent();
                    _f.label = 3;
                case 3:
                    _f.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, spCrudOps.insertData(HISTORY_LIST, (_a = {
                                Title: requestNo || ""
                            },
                            _a[HISTORY_PARENT_FIELD] = numericId,
                            _a.ActionTaken = newStatus === "Approved" ? (isHOD ? "Approved (HOD)" : "Approved (RM)") : "Rejected",
                            _a.Remarks = approvalRemarks !== null && approvalRemarks !== void 0 ? approvalRemarks : "",
                            _a.ActionDate = new Date().toISOString(),
                            _a.ApproverName = meName,
                            _a), { currentSPContext: currentSPContext })];
                case 4:
                    _f.sent();
                    return [3 /*break*/, 6];
                case 5:
                    e_4 = _f.sent();
                    console.warn("[NonPoApproval] history insert skipped/failed]:", e_4);
                    return [3 /*break*/, 6];
                case 6:
                    // 3) Navigate
                    if (newStatus === "Rejected") {
                        navigate("".concat(ROUTE_REJECTED, "?from=approval&status=Rejected"));
                    }
                    else {
                        if (isHOD) {
                            navigate("".concat(ROUTE_APTEAM, "?from=approval&status=Pending%20for%20Acceptance"));
                        }
                        else {
                            navigate("".concat(ROUTE_APPROVED, "?from=approval&status=Approved"));
                        }
                    }
                    return [2 /*return*/];
            }
        });
    }); };
    /** ===== UI ===== */
    return (react_1.default.createElement("div", { className: "approval-root", style: { padding: 20, background: "#f5f5f5" } },
        react_1.default.createElement("h2", { className: "page-title", style: { margin: 0, marginBottom: 10 } },
            title,
            " ",
            requestNo ? "\u2014 ".concat(requestNo) : ""),
        err && react_1.default.createElement("div", { style: { color: "#b91c1c", marginBottom: 8 } }, err),
        loading && react_1.default.createElement("div", { style: { marginBottom: 8 } }, "Loading\u2026"),
        react_1.default.createElement("section", { className: "section-box", style: sectionStyle },
            react_1.default.createElement("h3", { className: "section-title", style: sectionHead }, "Requester Information"),
            react_1.default.createElement("div", { className: "grid-2", style: grid2 },
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Request Date:"),
                    " ",
                    requestDate),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Employee Name:"),
                    " ",
                    employeeName),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Division:"),
                    " ",
                    division),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Email:"),
                    " ",
                    email),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "HOD:"),
                    " ",
                    hod),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Department:"),
                    " ",
                    department),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Employee Status:"),
                    " ",
                    employeeStatus),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Contact No:"),
                    " ",
                    contactNo),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Location:"),
                    " ",
                    locationVal),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "RM:"),
                    " ",
                    rm))),
        react_1.default.createElement("section", { className: "section-box", style: sectionStyle },
            react_1.default.createElement("h3", { className: "section-title", style: sectionHead }, "Invoice Details"),
            react_1.default.createElement("div", { className: "grid-3", style: grid3 },
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Vendor Code*:"),
                    " ",
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: vendorCode, onChange: function (e) { return setVendorCode(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Vendor Name:"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: vendorName, onChange: function (e) { return setVendorName(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Nature of Expenses:"),
                    " ",
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: natureOfExpenses, onChange: function (e) { return setNatureOfExpenses(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Invoice No.*:"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: invoiceNo, onChange: function (e) { return setInvoiceNo(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Invoice Date:"),
                    " ",
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: invoiceDate, onChange: function (e) { return setInvoiceDate(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Basic Amount:"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: basicAmount, onChange: function (e) { return setBasicAmount(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "GST Amount:"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: gst, onChange: function (e) { return setGst(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Other Charges (If any):"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: otherCharges, onChange: function (e) { return setOtherCharges(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("b", null, "Total Amount:"),
                    react_1.default.createElement("br", null),
                    react_1.default.createElement("input", { value: totalAmount, onChange: function (e) { return setTotalAmount(e.target.value); }, disabled: true, style: input })))),
        react_1.default.createElement("section", { className: "section-box", style: sectionStyle },
            react_1.default.createElement("div", { className: "grid-2", style: grid2 },
                react_1.default.createElement("div", null,
                    react_1.default.createElement("p", null,
                        react_1.default.createElement("b", null, "Payment Remarks")),
                    react_1.default.createElement("input", { value: paymentRemarks, onChange: function (e) { return setPaymentRemarks(e.target.value); }, disabled: true, style: input })),
                react_1.default.createElement("div", null,
                    react_1.default.createElement("p", null,
                        react_1.default.createElement("b", null, "Approval Remarks")),
                    react_1.default.createElement("input", { value: approvalRemarks, onChange: function (e) { return setApprovalRemarks(e.target.value); }, disabled: !isEdit, style: input })))),
        react_1.default.createElement("section", { className: "history-box", style: historyBox },
            react_1.default.createElement("h3", { className: "history-title", style: { marginTop: 0, marginBottom: 10, fontWeight: "bold" } }, "Approval History"),
            history.length === 0 ? (react_1.default.createElement("div", { style: { color: "#6b7280" } }, "No history available")) : (history.map(function (h) { return (react_1.default.createElement("div", { key: h.id, className: "history-entry", style: historyEntry },
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Approval By:"),
                    " ",
                    h.approver),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Action Taken:"),
                    " ",
                    h.actionTaken),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Remarks:"),
                    " ",
                    h.remarks),
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Action Date:"),
                    " ",
                    h.actionDate),
                react_1.default.createElement("hr", null))); }))),
        react_1.default.createElement("div", { className: "button-row", style: { display: "flex", gap: 12, marginTop: 10 } },
            isEdit && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement("button", { className: "btn", style: btnApprove, onClick: function () { return updateStatus("Approved"); } }, "Approve"),
                react_1.default.createElement("button", { className: "btn", style: btnReject, onClick: function () { return updateStatus("Rejected"); } }, "Reject"),
                react_1.default.createElement("button", { className: "btn", style: btnExit, onClick: function () { return navigate("/MyApproval"); } }, "Exit"))),
            !isEdit && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement("button", { className: "btn", style: btnExit, onClick: function () { return navigate("/MyApproval"); } }, "Exit"))))));
};
exports.default = NonPoApproval;
/** Tiny styles */
var sectionStyle = { background: "#fff", padding: "18px 20px", borderRadius: 6, marginBottom: 18, border: "1px solid #ddd" };
var sectionHead = { margin: 0, marginBottom: 12, fontSize: 14, fontWeight: 700 };
var grid2 = { display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: "8px 20px" };
var grid3 = { display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "8px 20px" };
var input = { width: "100%", padding: 8, border: "1px solid #ddd", borderRadius: 4 };
var historyBox = { border: "2px solid #cc0000", borderRadius: 6, padding: 16, background: "#fff", marginBottom: 20 };
var historyEntry = { fontSize: 13, lineHeight: 1.4, marginBottom: 8 };
var btnBase = { padding: "8px 20px", borderRadius: 6, border: "none", color: "#fff", fontWeight: 700, cursor: "pointer" };
var btnApprove = tslib_1.__assign(tslib_1.__assign({}, btnBase), { background: "#4CAF50" });
var btnReject = tslib_1.__assign(tslib_1.__assign({}, btnBase), { background: "#c62828" });
var btnExit = tslib_1.__assign(tslib_1.__assign({}, btnBase), { background: "#333" });
var btnPrimary = tslib_1.__assign(tslib_1.__assign({}, btnBase), { background: "#2563eb" });
//# sourceMappingURL=NonPoApprovalold.js.map