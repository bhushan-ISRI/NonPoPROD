"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ViewRequest = void 0;
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/site-users/web");
require("./CSS/NewRequest.scss");
var react_router_dom_2 = require("react-router-dom");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
var ViewRequest = function (props) {
    var navigate = (0, react_router_dom_2.useNavigate)();
    var id = (0, react_router_dom_1.useParams)().id;
    var _a = react_1.default.useState(), RequestDate = _a[0], setRequestDate = _a[1];
    var _b = react_1.default.useState(), EmployeeName = _b[0], setEmployeeName = _b[1];
    var _c = react_1.default.useState(), Divison = _c[0], setDivison = _c[1];
    var _d = react_1.default.useState(), Email = _d[0], setEmail = _d[1];
    var _e = react_1.default.useState(), HOD = _e[0], setHOD = _e[1];
    var _f = react_1.default.useState(), Department = _f[0], setDepartment = _f[1];
    var _g = react_1.default.useState(), EmpStatus = _g[0], setEmpStatus = _g[1];
    var _h = react_1.default.useState(), Status = _h[0], setStatus = _h[1];
    var _j = (0, react_1.useState)(false), isSubmitting = _j[0], setIsSubmitting = _j[1];
    var _k = react_1.default.useState([]), ApprovalMatrixdata = _k[0], setApprovalMatrix = _k[1];
    var _l = react_1.default.useState(null), WorkflowJSX = _l[0], setWorkflowJSX = _l[1];
    var _m = react_1.default.useState(0), Stage = _m[0], setStageData = _m[1];
    var _o = react_1.default.useState([]), WorkflowHistory = _o[0], setWorkflowHistory = _o[1];
    var _p = (0, react_1.useState)(), ItemID = _p[0], setItemID = _p[1];
    var _q = react_1.default.useState(""), Comment = _q[0], setComment = _q[1];
    var _r = (0, react_1.useState)(), requestNo = _r[0], setrequestNo = _r[1]; // useState<string | undefined>(undefined);
    var _s = react_1.default.useState(), contactNo = _s[0], setcontactNo = _s[1];
    var _t = react_1.default.useState(), Location = _t[0], setLocation = _t[1];
    var _u = react_1.default.useState(""), RMVal = _u[0], setRMVal = _u[1];
    var _v = react_1.default.useState(""), VendorCode = _v[0], setVendorCode = _v[1];
    var _w = react_1.default.useState(""), VendorName = _w[0], setVendorName = _w[1];
    var _x = react_1.default.useState(""), NatureExpense = _x[0], setNatureExpense = _x[1];
    var _y = react_1.default.useState(""), InvoiceNo = _y[0], setInvoiceNo = _y[1];
    var _z = react_1.default.useState(""), InvoiceDate = _z[0], setInvoiceDate = _z[1];
    var _0 = react_1.default.useState(""), BasicAmount = _0[0], setBasicAmount = _0[1];
    var _1 = react_1.default.useState(""), PayRemark = _1[0], setPayRemark = _1[1];
    var _2 = react_1.default.useState(""), VouAmount = _2[0], setVouAmount = _2[1];
    var _3 = react_1.default.useState(""), GLCode = _3[0], setGLCode = _3[1];
    var _4 = react_1.default.useState(""), CostCentre = _4[0], setCostCentre = _4[1];
    var _5 = react_1.default.useState(null), GLDescription = _5[0], setGLDescription = _5[1];
    var _6 = react_1.default.useState(null), CostCenterDescription = _6[0], setCostCenterDescription = _6[1];
    var _7 = react_1.default.useState(""), VoucherNumber = _7[0], setVoucherNumber = _7[1];
    var _8 = react_1.default.useState(""), GSTAmt = _8[0], setGSTAmt = _8[1];
    var _9 = react_1.default.useState(""), otherCharges = _9[0], setotherCharges = _9[1];
    var _10 = react_1.default.useState(""), TotalAmount = _10[0], setTotalAmount = _10[1];
    var _11 = (0, react_1.useState)([]), existingFiles = _11[0], setExistingFiles = _11[1];
    var _12 = (0, react_1.useState)(false), loadingExisting = _12[0], setLoadingExisting = _12[1];
    var _13 = (0, react_1.useState)(true), loading = _13[0], setLoading = _13[1];
    (0, react_1.useEffect)(function () {
        if (id) {
            loadItem(Number(id));
        }
    }, [id]);
    react_1.default.useEffect(function () {
        if (ApprovalMatrixdata.length > 0) {
            displayWorkflow();
        }
    }, [ApprovalMatrixdata]);
    var displayWorkflow = function (matrix) {
        var data = matrix || ApprovalMatrixdata;
        var wf = [];
        data.forEach(function (m, i) {
            var isActive = "";
            if ((Status === null || Status === void 0 ? void 0 : Status.trim().toLowerCase()) === "closed") {
                // ✅ All completed when closed
                isActive = "beforeactiveApprover";
            }
            else {
                if (i < Stage) {
                    isActive = "beforeactiveApprover"; // GREEN
                }
                else if (i === Stage) {
                    isActive = "overrideStage"; // YELLOW
                }
                else {
                    isActive = "overrideStage"; // NORMAL
                }
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu", key: i },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
        });
        setWorkflowJSX(wf);
    };
    var displayWorkflow1 = function (matrix) {
        var data = matrix || ApprovalMatrixdata;
        var wf = [];
        var isActive;
        var notActive = false;
        data.forEach(function (m, i) {
            if (!notActive && Stage !== 99) {
                if (Stage === i) {
                    isActive = 'activeApprover';
                    notActive = true;
                }
                else {
                    isActive = 'beforeactiveApprover';
                }
            }
            else {
                isActive = 'overrideStage';
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu", key: i },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
        });
        setWorkflowJSX(wf);
    };
    var displayWorkflownew = function (matrix) {
        var data = matrix || ApprovalMatrixdata;
        var wf = [];
        var isActive;
        var notActive = false;
        data.forEach(function (m, i) {
            // ✅ NEW: If Closed → no active highlight
            if (Status === "Closed") {
                isActive = "overrideStage";
            }
            else {
                if (!notActive && Stage !== 99) {
                    if (Stage === i) {
                        isActive = 'activeApprover';
                        notActive = true;
                    }
                    else {
                        isActive = 'beforeactiveApprover';
                    }
                }
                else {
                    isActive = 'overrideStage';
                }
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu", key: i },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
        });
        setWorkflowJSX(wf);
    };
    var th = {
        textAlign: "left",
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontWeight: 700,
        fontSize: 13,
    };
    var td = {
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontSize: 13,
    };
    var loadItem = function (itemId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, item, invDate, parsedApprovalMatrix, parsedWorkflowHistory, error_1;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    setLoading(true);
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 4, , 5]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("ID,Title,GLDescription,CostCenterDescription,Amount,GLCode,CostCentre,VoucherNumber,RequestDate,EmployeeName,Stage,ApprovalMatrix,WorkflowHistory,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus,ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,Status,PaymentRemarks,ApprovalRemarks,VendorCode/VendorCode,VendorCode/Title,VendorCode/Id,NatureofExpense/Title,NatureofExpense/ExpenseType,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title")
                            .expand("VendorCode,NatureofExpense,CurrentApprover")()];
                case 2:
                    item = _b.sent();
                    console.log(item);
                    // setLoading(false);
                    setItemID(itemId);
                    setrequestNo(item.Title || "");
                    setPayRemark(item.PaymentRemarks || "");
                    setStatus(item.Status || "");
                    setRMVal((_a = item.RM) !== null && _a !== void 0 ? _a : "");
                    setLocation(item.Location || "");
                    setRequestDate(item.RequestDate ? new Date(item.RequestDate).toLocaleDateString("en-GB") : "");
                    setEmployeeName(item.EmployeeName || "");
                    setDivison(item.Division || "");
                    setEmail(item.Email || "");
                    setHOD(item.HOD || "");
                    setDepartment(item.Department || "");
                    setEmpStatus(item.EmployeeStatus || "");
                    setcontactNo(item.ContactNo || "");
                    setVendorCode(item.VendorCode.VendorCode || "");
                    setVendorName(item.VendorName || "");
                    setNatureExpense(item.NatureofExpense.ExpenseType || "");
                    setInvoiceNo(item.InvoiceNumber || "");
                    invDate = new Date(item.InvoiceDate || "").toISOString().split("T")[0];
                    setGLDescription(item.GLDescription || "");
                    setCostCenterDescription(item.CostCenterDescription || "");
                    setInvoiceDate(invDate);
                    setBasicAmount(item.Basicamount || "");
                    setGSTAmt(item.GST || "");
                    setotherCharges(item.OtherCharges || "");
                    setTotalAmount(item.Totalamount || "");
                    setStageData(item.Stage || "");
                    setVouAmount(item.Amount || "");
                    setGLCode(item.GLCode || "");
                    setCostCentre(item.CostCentre || "");
                    setVoucherNumber(item.VoucherNumber || "");
                    parsedApprovalMatrix = [];
                    if (item.ApprovalMatrix) {
                        try {
                            parsedApprovalMatrix = JSON.parse(item.ApprovalMatrix);
                        }
                        catch (parseError) {
                            console.error("Error parsing ApprovalMatrix JSON:", parseError);
                        }
                    }
                    setApprovalMatrix(parsedApprovalMatrix);
                    return [4 /*yield*/, loadFinalNonPoFile(item.Title)];
                case 3:
                    _b.sent();
                    parsedWorkflowHistory = [];
                    if (item.WorkflowHistory) {
                        try {
                            parsedWorkflowHistory = JSON.parse(item.WorkflowHistory);
                        }
                        catch (parseError) {
                            console.error("Error parsing WorkflowHistory JSON:", parseError);
                        }
                    }
                    setWorkflowHistory(parsedWorkflowHistory);
                    setLoading(false);
                    return [3 /*break*/, 5];
                case 4:
                    error_1 = _b.sent();
                    console.error("Error loading item:", error_1);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var toFolderName = function (requestNo) {
        return (requestNo || "NONPO")
            .replace(/[\\#%&*:{?<>|"]/g, "_") // removed /
            .replace(/\//g, "-")
            .trim();
    };
    var loadFinalNonPoFile = function (requestNo) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, origin_1, absUrl, libTitle, libFiles, root, rootUrl, folderPath, files, _i, _a, f, error_2, e_1;
        var _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    _e.trys.push([0, 6, 7, 8]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    origin_1 = window.location.origin;
                    absUrl = ((_d = (_c = (_b = props.currentSPContext) === null || _b === void 0 ? void 0 : _b.pageContext) === null || _c === void 0 ? void 0 : _c.web) === null || _d === void 0 ? void 0 : _d.absoluteUrl) || "";
                    // if (!props.currentSPContext || !requestNo) return;
                    setLoadingExisting(true);
                    libTitle = "NonPODoc";
                    libFiles = [];
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(libTitle).rootFolder()];
                case 2:
                    root = _e.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderPath = "".concat(rootUrl, "/").concat(toFolderName(requestNo));
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.select("Name,ServerRelativeUrl,Length,TimeLastModified")()];
                case 3:
                    files = _e.sent();
                    for (_i = 0, _a = files || []; _i < _a.length; _i++) {
                        f = _a[_i];
                        libFiles.push({
                            name: f.Name,
                            url: "".concat(origin_1).concat(f.ServerRelativeUrl),
                            //  url: `${absUrl}${f.ServerRelativeUrl}`,
                            sizeBytes: Number(f.Length || 0),
                            lastModified: f.TimeLastModified,
                            source: "Library",
                            serverRelativeUrl: f.ServerRelativeUrl,
                        });
                    }
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _e.sent();
                    console.error(error_2);
                    alert("Something went wrong.");
                    return [3 /*break*/, 5];
                case 5:
                    setExistingFiles(tslib_1.__spreadArray([], libFiles, true));
                    return [3 /*break*/, 8];
                case 6:
                    e_1 = _e.sent();
                    console.warn("[APTeamAcceptance] existing docs load failed:", e_1);
                    setExistingFiles([]);
                    return [3 /*break*/, 8];
                case 7:
                    setLoadingExisting(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    var handleOpenFile = function (url) {
        window.open(url, "_blank", "noopener,noreferrer");
    };
    // ✅ UI must return something
    return (react_1.default.createElement("div", null,
        react_1.default.createElement("div", { className: "bordered" },
            react_1.default.createElement("a", null,
                react_1.default.createElement("img", { src: sona_comstarlogo_png_1.default })),
            react_1.default.createElement("h1", null, "Non PO Approval")),
        react_1.default.createElement("div", { className: 'displayWF' }, WorkflowJSX),
        react_1.default.createElement("div", { className: 'borderedbox' },
            react_1.default.createElement("div", { className: "heading1" },
                react_1.default.createElement("label", null, "Requestor Information")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Request Date : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            RequestDate)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Employee Name  : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeName)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Email : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Email))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Contact No : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            contactNo)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Department : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Department)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Division : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Divison))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Location : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Location)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "RM : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            RMVal)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "HOD : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            HOD))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Employee Status : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmpStatus)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Status", className: 'font fontblock' }, "Status : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Status)))),
            react_1.default.createElement("div", { className: "heading1" },
                react_1.default.createElement("label", null, "Invoice Details")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Vendor Code : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            VendorCode)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Name", className: 'font fontblock' }, "Vendor Name  : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            VendorName)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Contact No", className: 'font fontblock' }, "Nature of Expense : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            NatureExpense))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Status", className: 'font fontblock' }, "Invoice No : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            InvoiceNo)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Invoice Date : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            InvoiceDate)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Basic Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            BasicAmount))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "GST Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            GSTAmt)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Other Charges (If any): : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            otherCharges)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Total Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            TotalAmount))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Remarks for NON-PO Expense : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            PayRemark)))),
            Status === "Pending for Vouching" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement("div", { className: "heading1" },
                    react_1.default.createElement("label", null, "AP Performer Updates")),
                react_1.default.createElement("div", { className: 'main-formcontainer' },
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                GLCode)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code Description : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                GLDescription))),
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                CostCentre)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center Description: : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                CostCenterDescription))),
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, " Voucher Number : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                VoucherNumber)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Voucher Amount : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                VouAmount)))))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Attached Documents")),
            react_1.default.createElement("div", { className: 'main-formcontainer' }, loadingExisting ? (react_1.default.createElement("div", { className: "text-muted" }, "Loading documents\u2026")) : existingFiles.length === 0 ? (react_1.default.createElement("div", { style: { color: "#6b7280" } }, "No documents available.")) : (react_1.default.createElement("div", { style: { overflowX: "auto" } },
                react_1.default.createElement("table", { style: { width: "100%", borderCollapse: "collapse" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", { style: { background: "#f8fafc" } },
                            react_1.default.createElement("th", { style: th }, "File"),
                            react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 140 }) }, "Size"),
                            react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 120 }) }, "Action"))),
                    react_1.default.createElement("tbody", null, existingFiles.map(function (f) { return (react_1.default.createElement("tr", { key: "".concat(f.source, "-").concat(f.name) },
                        react_1.default.createElement("td", { style: td },
                            react_1.default.createElement("a", { onClick: function () { return handleOpenFile(f.url); }, style: { color: "#0a66c2" } }, f.name)),
                        react_1.default.createElement("td", { style: tslib_1.__assign({}, td) }, f.sizeBytes ? "".concat((f.sizeBytes / (1024 * 1024)).toFixed(2), " MB") : "—"),
                        react_1.default.createElement("td", { style: td },
                            react_1.default.createElement("a", { className: "btn btn-sm btn-outline-primary", href: f.url, target: "_blank", rel: "noreferrer" }, "Download")))); })))))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Work Flow History")),
            react_1.default.createElement("div", { className: "main-formcontainer" },
                react_1.default.createElement("div", { className: 'Workflowbox' }, WorkflowHistory && WorkflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "workflow-table", style: { width: '100%', borderCollapse: 'collapse' } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Date"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action By"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Taken"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Comment"))),
                    react_1.default.createElement("tbody", null, WorkflowHistory.map(function (h, idx) { return (react_1.default.createElement("tr", { key: idx },
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Date ? new Date(h.Date).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replace(",", "") : ""),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.CurrentApprover || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.ActionTaken || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Comment || ''))); })))) : (react_1.default.createElement("p", null, "No workflow history")))),
            react_1.default.createElement("div", { style: { display: "flex", justifyContent: "center", gap: "5px", margin: "10px 20px" } },
                react_1.default.createElement("button", { className: "reset-btn", onClick: function () { return navigate(-1); } }, "Exit")))));
};
exports.ViewRequest = ViewRequest;
//# sourceMappingURL=ViewRequest.js.map