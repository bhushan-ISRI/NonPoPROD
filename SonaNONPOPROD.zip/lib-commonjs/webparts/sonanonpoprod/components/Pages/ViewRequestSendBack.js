"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ViewRequestSendBack = void 0;
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/site-users/web");
require("./CSS/NewRequest.scss");
var react_2 = require("@fluentui/react");
var antd_1 = require("antd");
var icons_1 = require("@ant-design/icons");
var react_router_dom_2 = require("react-router-dom");
var ViewRequestSendBack = function (props) {
    var _a;
    var navigate = (0, react_router_dom_2.useNavigate)();
    var id = (0, react_router_dom_1.useParams)().id;
    var _b = react_1.default.useState(), RequestDate = _b[0], setRequestDate = _b[1];
    // const [EmployeeName, setEmployeeName] = React.useState<string>();
    var _c = react_1.default.useState(), Divison = _c[0], setDivison = _c[1];
    var _d = react_1.default.useState(), Email = _d[0], setEmail = _d[1];
    // const approverJson = React.useRef<any[]>(null);
    var approverJson = react_1.default.useRef([]);
    // const [Employeemasterdata, setEmployeeMasterdata] = React.useState<any[]>([]);
    var _e = react_1.default.useState([]), ExpenseMasterdata = _e[0], setExpenseMasterdata = _e[1];
    var _f = react_1.default.useState([]), NatureOfExpenseTypeOptions = _f[0], setNatureOfExpenseTypeOptions = _f[1];
    var EmployeeQmadata = react_1.default.useRef([]);
    var currentUserId = react_1.default.useRef(0);
    // let EmployeeQmadata = React.useRef<any[]>(null);
    var _g = react_1.default.useState(), HOD = _g[0], setHOD = _g[1];
    var _h = react_1.default.useState(), EmpStatus = _h[0], setEmpStatus = _h[1];
    var _j = react_1.default.useState(), Status = _j[0], setStatus = _j[1];
    var _k = (0, react_1.useState)(false), isSubmitting = _k[0], setIsSubmitting = _k[1];
    var _l = react_1.default.useState([]), ApprovalMatrixdata = _l[0], setApprovalMatrix = _l[1];
    //const approvalMatrix = React.useState<any[]>([]);// useRef<any[]>(null);
    var approvalMatrix = react_1.default.useRef([]);
    //approvalMatrix.current = approvalMatrixJSON; // ✅ correct
    var _m = react_1.default.useState(null), WorkflowJSX = _m[0], setWorkflowJSX = _m[1];
    var _o = react_1.default.useState(0), Stage = _o[0], setStageData = _o[1];
    var _p = react_1.default.useState([]), WorkflowHistory = _p[0], setWorkflowHistory = _p[1];
    var _q = (0, react_1.useState)(), ItemID = _q[0], setItemID = _q[1];
    var _r = react_1.default.useState(""), Comment = _r[0], setComment = _r[1];
    var _s = react_1.default.useState(""), currentDate = _s[0], setCurrentDate = _s[1];
    var _t = (0, react_1.useState)(), requestNo = _t[0], setrequestNo = _t[1]; // useState<string | undefined>(undefined);
    var _u = react_1.default.useState(), contactNo = _u[0], setcontactNo = _u[1];
    var _v = react_1.default.useState(), Location = _v[0], setLocation = _v[1];
    var _w = react_1.default.useState(""), RMVal = _w[0], setRMVal = _w[1];
    var _x = react_1.default.useState(""), VendorCode = _x[0], setVendorCode = _x[1];
    var _y = react_1.default.useState(""), VendorName = _y[0], setVendorName = _y[1];
    var _z = react_1.default.useState(""), NatureExpense = _z[0], setNatureExpense = _z[1];
    var _0 = react_1.default.useState(""), InvoiceNo = _0[0], setInvoiceNo = _0[1];
    var _1 = react_1.default.useState(""), InvoiceDate = _1[0], setInvoiceDate = _1[1];
    var _2 = react_1.default.useState(""), PayRemark = _2[0], setPayRemark = _2[1];
    var _3 = react_1.default.useState(""), VouAmount = _3[0], setVouAmount = _3[1];
    var _4 = react_1.default.useState(""), GLCode = _4[0], setGLCode = _4[1];
    var _5 = react_1.default.useState(""), CostCentre = _5[0], setCostCentre = _5[1];
    var _6 = react_1.default.useState(""), VoucherNumber = _6[0], setVoucherNumber = _6[1];
    var _7 = (0, react_1.useState)(0), BasicAmount = _7[0], setBasicAmount = _7[1];
    var _8 = (0, react_1.useState)(0), GSTAmt = _8[0], setGSTAmt = _8[1];
    var _9 = (0, react_1.useState)(0), otherCharges = _9[0], setotherCharges = _9[1];
    var _10 = (0, react_1.useState)(0), TotalAmount = _10[0], setTotalAmount = _10[1];
    //const [TotalAmount,setTotalAmount] = React.useState<string>("");
    var _11 = (0, react_1.useState)([]), existingFiles = _11[0], setExistingFiles = _11[1];
    var _12 = (0, react_1.useState)(false), loadingExisting = _12[0], setLoadingExisting = _12[1];
    var _13 = (0, react_1.useState)(null), originalData = _13[0], setOriginalData = _13[1];
    var _14 = react_1.default.useState(), selectedNatureofexpense = _14[0], setSelectedNatureofexpense = _14[1];
    var _15 = react_1.default.useState(null), GLDescription = _15[0], setGLDescription = _15[1];
    var _16 = react_1.default.useState(null), CostCenterDescription = _16[0], setCostCenterDescription = _16[1];
    var _17 = (0, react_1.useState)({
        allFiles: []
    }), POAttachments = _17[0], setPOAttachments = _17[1];
    var _18 = (0, react_1.useState)(null), POTextAttachFile = _18[0], setPOTextAttachFile = _18[1];
    // const [currentDate, setCurrentDate] = React.useState("");
    var _19 = react_1.default.useState([]), Employeemasterdata = _19[0], setEmployeemasterdata = _19[1];
    var _20 = react_1.default.useState(""), EmployeeId = _20[0], setEmployeeId = _20[1];
    var _21 = react_1.default.useState(""), EmployeeName = _21[0], setCurrentUserName = _21[1];
    var _22 = react_1.default.useState(""), EmployeeEmail = _22[0], setCurrentUserEmail = _22[1];
    var _23 = react_1.default.useState(""), EmployeeContactno = _23[0], setEmployeeContactno = _23[1];
    var _24 = react_1.default.useState(""), EmployeeStatus = _24[0], setEmployeeStatus = _24[1];
    var _25 = react_1.default.useState(""), EmployeeDivision = _25[0], setEmployeeDivision = _25[1];
    var _26 = react_1.default.useState(""), Locationdata = _26[0], setLocationdata = _26[1];
    var _27 = react_1.default.useState(""), EmployeeRM = _27[0], setEmployeeRM = _27[1];
    var _28 = react_1.default.useState(""), hoddata = _28[0], sethoddata = _28[1];
    var _29 = react_1.default.useState(), Department = _29[0], setDepartment = _29[1];
    var IntitorID = react_1.default.useRef(null);
    var RMID = react_1.default.useRef(null);
    var HODID = react_1.default.useRef(null);
    var _30 = react_1.default.useState(), CostCenter = _30[0], setCostCenter = _30[1];
    var currentUserEmail = react_1.default.useRef("");
    (0, react_1.useEffect)(function () {
        if (id) {
            loadItem(Number(id));
            setItemID(id);
        }
    }, [id]);
    react_1.default.useEffect(function () {
        var loadCurrentUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var sp, user, today, error_1;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                        return [4 /*yield*/, sp.web.currentUser()];
                    case 1:
                        user = _a.sent();
                        currentUserId.current = user.Id;
                        today = new Date().toISOString().split("T")[0];
                        setCurrentDate(today);
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        console.error("Error fetching current user:", error_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        }); };
        loadCurrentUser();
    }, [props.currentSPContext]);
    var getdata = function (userEmail) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: 
                // await userProfile();
                return [4 /*yield*/, fetchEmployeeDataV2(userEmail)];
                case 1:
                    // await userProfile();
                    _a.sent();
                    return [4 /*yield*/, fetchApprovalMatrix()];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, getapprovalmatrix(userEmail)];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, displayWorkflow()];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); };
    react_1.default.useEffect(function () {
        var loadCurrentUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var sp, user, today, error_2;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                        return [4 /*yield*/, sp.web.currentUser()];
                    case 1:
                        user = _a.sent();
                        currentUserId.current = user.Id;
                        currentUserEmail.current = user.Email;
                        // currentUserEmail.current = "damodar@sonacomstar.com";
                        // Call after email is available
                        return [4 /*yield*/, getdata(user.Email)];
                    case 2:
                        // currentUserEmail.current = "damodar@sonacomstar.com";
                        // Call after email is available
                        _a.sent();
                        today = new Date().toISOString().split("T")[0];
                        setCurrentDate(today);
                        return [3 /*break*/, 4];
                    case 3:
                        error_2 = _a.sent();
                        console.error("Error fetching current user:", error_2);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        loadCurrentUser();
    }, [props.currentSPContext]);
    var fetchEmployeeDataV2 = function (userEmail) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var toTitleCase_1, cleanLocationForDisplay_1, FLOW_URL_1, fetchPage, allEmployees, page, hasMoreData, res, employees, mappedEmployees, emp, sp, IntitorUser, rmUser, HodUser, error_3;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 8, , 9]);
                    toTitleCase_1 = function (str) {
                        if (!str)
                            return "";
                        return str
                            .toLowerCase()
                            .split(" ")
                            .filter(Boolean)
                            .map(function (w) { return w.charAt(0).toUpperCase() + w.slice(1); })
                            .join(" ");
                    };
                    cleanLocationForDisplay_1 = function (location) {
                        if (!location)
                            return "N/A";
                        return location.replace(/^re\s+/i, "").trim();
                    };
                    FLOW_URL_1 = "https://defaultcb1edbfe8080457d9cae51528f3643.3f.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/e2bb522aa41443179a72b701b9613471/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=q8b8ADCtK2eKr2f6p3MX7gxmJymPeJbm0mq2M69Rk8E";
                    fetchPage = function (pageNumber) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                        var response;
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, fetch(FLOW_URL_1, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            PageSize: 500,
                                            PageNumber: pageNumber
                                        })
                                    })];
                                case 1:
                                    response = _a.sent();
                                    if (!response.ok) {
                                        throw new Error("Failed to fetch employee data");
                                    }
                                    return [2 /*return*/, response.json()];
                            }
                        });
                    }); };
                    allEmployees = [];
                    page = 1;
                    hasMoreData = true;
                    _b.label = 1;
                case 1:
                    if (!hasMoreData) return [3 /*break*/, 3];
                    return [4 /*yield*/, fetchPage(page)];
                case 2:
                    res = _b.sent();
                    employees = ((_a = res === null || res === void 0 ? void 0 : res.data) === null || _a === void 0 ? void 0 : _a.employees) || [];
                    allEmployees = tslib_1.__spreadArray(tslib_1.__spreadArray([], allEmployees, true), employees, true);
                    if (employees.length < 500) {
                        return [3 /*break*/, 3];
                    }
                    page++;
                    return [3 /*break*/, 1];
                case 3:
                    mappedEmployees = allEmployees.map(function (item) {
                        var locationAttr = (item.attributes || []).find(function (a) { return a.attributeTypeDescription === "Location"; });
                        var departmentAttr = (item.attributes || []).find(function (a) { var _a; return ((_a = a.attributeTypeDescription) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "department"; });
                        var hodAttr = (item.attributes || []).find(function (a) { var _a; return ((_a = a.attributeTypeDescription) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "hod name"; });
                        var hodemailAttr = (item.attributes || []).find(function (a) { var _a; return ((_a = a.attributeTypeDescription) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "hod_email"; });
                        var CostCenterAttr = (item.attributes || []).find(function (a) { var _a; return ((_a = a.attributeTypeDescription) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "cost center"; });
                        // const user = sp.web.ensureUser(item.email);
                        var today = new Date().toISOString().split("T")[0];
                        setCurrentDate(today);
                        return {
                            EmployeeCode: item.employeeCode || "",
                            EmployeeName: toTitleCase_1(item.employeeName || ""),
                            Email: item.email || "",
                            MobileNo: item.mobileNo || "",
                            EmployeeStatus: item.employeeStatus || "",
                            Department: (departmentAttr === null || departmentAttr === void 0 ? void 0 : departmentAttr.attributeTypeUnitDescription) || "",
                            Location: cleanLocationForDisplay_1(locationAttr === null || locationAttr === void 0 ? void 0 : locationAttr.attributeTypeUnitDescription),
                            CostCenter: (CostCenterAttr === null || CostCenterAttr === void 0 ? void 0 : CostCenterAttr.attributeTypeUnitDescription) || "",
                            RMName: item.reportingManagerName || "",
                            RMEmail: item.reportingManagerEmail || "",
                            HODName: (hodAttr === null || hodAttr === void 0 ? void 0 : hodAttr.attributeTypeUnitDescription) || "",
                            HODEmail: (hodemailAttr === null || hodemailAttr === void 0 ? void 0 : hodemailAttr.attributeTypeUnitDescription) || "",
                            // HODName: item.reportingManagerName2 || "",
                            // HODEmail: item.reportingManagerEmail2 || ""
                        };
                    });
                    // set all employees
                    setEmployeemasterdata(mappedEmployees);
                    EmployeeQmadata.current = mappedEmployees;
                    emp = mappedEmployees.find(function (x) {
                        var _a;
                        return ((_a = x.Email) === null || _a === void 0 ? void 0 : _a.trim().toLowerCase()) ===
                            (userEmail === null || userEmail === void 0 ? void 0 : userEmail.trim().toLowerCase());
                    });
                    if (!emp) return [3 /*break*/, 7];
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    setEmployeeId(emp.EmployeeCode);
                    setCurrentUserName(emp.EmployeeName);
                    setCurrentUserEmail(emp.Email);
                    return [4 /*yield*/, sp.web.ensureUser(emp.Email)];
                case 4:
                    IntitorUser = _b.sent();
                    IntitorID.current = IntitorUser.Id;
                    setEmployeeContactno(emp.MobileNo);
                    setEmployeeStatus(emp.EmployeeStatus);
                    setEmployeeDivision(emp.Department);
                    setLocationdata(emp.Location);
                    setEmployeeRM(emp.RMName);
                    setDepartment(emp.Department);
                    setCostCenter(emp.CostCenter);
                    return [4 /*yield*/, sp.web.ensureUser(emp.RMEmail)];
                case 5:
                    rmUser = _b.sent();
                    RMID.current = rmUser.Id;
                    return [4 /*yield*/, sp.web.ensureUser(emp.HODEmail)];
                case 6:
                    HodUser = _b.sent();
                    HODID.current = HodUser.Id;
                    sethoddata(emp.HODName);
                    _b.label = 7;
                case 7: return [3 /*break*/, 9];
                case 8:
                    error_3 = _b.sent();
                    console.error("fetchEmployeeDataV2 error:", error_3);
                    return [3 /*break*/, 9];
                case 9: return [2 /*return*/];
            }
        });
    }); };
    var fetchApprovalMatrix = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parentItems, approvalMatrixJSON, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NONPOApprovalMatrix")
                            .items
                            .select("*", "Id,ApprovalType,Role/ID,Role/RoleName,Level/ID,Level/Level,Status,Approver/ID,Approver/Title,Approver/EMail")
                            .expand("Role", "Level", "Approver")
                            .filter("Status eq 'Active'")()];
                case 1:
                    parentItems = _a.sent();
                    approvalMatrixJSON = parentItems.map(function (item) {
                        var _a, _b, _c, _d, _e;
                        return ({
                            Role: ((_a = item.Role) === null || _a === void 0 ? void 0 : _a.RoleName) || "",
                            Approver: ((_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title) || "",
                            ApproverID: ((_d = (_c = item.Approver) === null || _c === void 0 ? void 0 : _c.ID) === null || _d === void 0 ? void 0 : _d.toString()) || "",
                            ApproverEmail: ((_e = item.Approver) === null || _e === void 0 ? void 0 : _e.EMail) || ""
                        });
                    });
                    approvalMatrix.current = approvalMatrixJSON;
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.error("Error fetching EmployeeMaster:", error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var getapprovalmatrix = function (userEmail) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var approverArray, matchedEmployee;
        return tslib_1.__generator(this, function (_a) {
            approverArray = [];
            matchedEmployee = EmployeeQmadata.current.find(function (x) {
                var _a;
                return ((_a = x.Email) === null || _a === void 0 ? void 0 : _a.trim().toLowerCase()) ===
                    (userEmail === null || userEmail === void 0 ? void 0 : userEmail.trim().toLowerCase());
            });
            if (!matchedEmployee) {
                console.log("Current user not found");
                return [2 /*return*/, []];
            }
            // Initiator
            approverArray.push({
                Role: "Initiator",
                User: matchedEmployee.EmployeeName,
                UserID: IntitorID.current,
                UserEmail: matchedEmployee.Email,
                Status: "Approved"
            });
            // RM
            approverArray.push({
                Role: "RM",
                User: matchedEmployee.RMName,
                UserID: RMID.current,
                UserEmail: matchedEmployee.RMEmail,
                PendingText: "Pending At RM",
                Status: "Pending"
            });
            // HOD only if different from RM
            if (String(RMID.current) !== String(HODID.current)) {
                approverArray.push({
                    Role: "HOD",
                    User: matchedEmployee.HODName,
                    UserID: HODID.current,
                    UserEmail: matchedEmployee.HODEmail,
                    PendingText: "Pending At HOD",
                    Status: "Waiting"
                });
            }
            // Add other approvers from ApprovalMatrix list
            approvalMatrix.current.forEach(function (item) {
                var _a;
                var role = item.Role || "";
                var approverId = (_a = item.ApproverID) === null || _a === void 0 ? void 0 : _a.toString();
                if (!approverId)
                    return;
                if (role === "RM" || role === "HOD")
                    return;
                var pendingText = "";
                if (role === "CFO")
                    pendingText = "Pending At CFO";
                else if (role === "APPerformer")
                    pendingText = "Pending At AP Performer";
                // Duplicate check
                // const alreadyExists =
                //   approverArray.some(
                //     x => String(x.UserID) === String(approverId)
                //   );
                // if (alreadyExists) return;
                approverArray.push({
                    Role: role,
                    User: item.Approver || "",
                    UserID: approverId,
                    UserEmail: item.ApproverEmail || "",
                    PendingText: pendingText,
                    Status: "Waiting"
                });
            });
            approverJson.current = approverArray;
            return [2 /*return*/];
        });
    }); };
    // let getdata = async () => {
    //     // await userProfile();
    //     await fetchExpenseMaster();
    //     await fetchEmployeeMaster();
    //     await fetchApprovalMatrix();
    //     await getapprovalmatrix();
    //     await displayWorkflow();
    // };
    // React.useEffect(() => {
    //     if (!Email || Employeemasterdata.length === 0) return;
    //     // Match current user email with EmployeeMaster email
    //     const matchedEmployee = Employeemasterdata.find(
    //         emp =>
    //             emp.Employee.Id &&
    //             emp.Employee.Id === currentUserId.current
    //     );
    //     if (matchedEmployee) {
    //         // ✅ ADD THIS LINE (MOST IMPORTANT)
    //         RMID.current = matchedEmployee.ReportingManager?.ID || null;
    //     }
    // }, [Email, Employeemasterdata]);
    var fetchExpenseMaster = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, Expitems, options, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("ExpenseMaster")
                            .items
                            .select("*")
                            .filter("Status eq 'Active'")()
                        // EmployeeQmadata.current = Expitems;
                    ];
                case 1:
                    Expitems = _a.sent();
                    // EmployeeQmadata.current = Expitems;
                    setExpenseMasterdata(Expitems);
                    options = Expitems.map(function (item) { return ({
                        key: item.Id, // ✅ IMPORTANT → Id
                        text: item.ExpenseType // display text
                    }); });
                    setNatureOfExpenseTypeOptions(options);
                    return [3 /*break*/, 3];
                case 2:
                    error_5 = _a.sent();
                    console.error("Error fetching EmployeeMaster:", error_5);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleAmountChange = function (name) {
        return function (e) {
            var value = Number(e.target.value) || 0;
            var newBasic = name === "BasicAmount" ? value : BasicAmount;
            var newGST = name === "GSTAmt" ? value : GSTAmt;
            var newOther = name === "OtherCharges" ? value : otherCharges;
            if (name === "BasicAmount")
                setBasicAmount(value);
            if (name === "GSTAmt")
                setGSTAmt(value);
            if (name === "OtherCharges")
                setotherCharges(value);
            var tot = Number(newBasic) +
                Number(newGST) +
                Number(newOther);
            setTotalAmount(tot);
        };
    };
    // const fetchApprovalMatrix = async () => {
    //     try {
    //         const sp = spfi().using(SPFx(props.currentSPContext));
    //         const parentItems = await sp.web.lists
    //             .getByTitle("NONPOApprovalMatrix")
    //             .items
    //             .select(
    //                 "*",
    //                 "Id,ApprovalType,Role/ID,Role/RoleName,Level/ID,Level/Level,Status,Approver/ID,Approver/Title,Approver/EMail")
    //             .expand("Role", "Level", "Approver")
    //             .filter("Status eq 'Active'")()
    //         const approvalMatrixJSON = parentItems.map((item: any) => ({
    //             Role: item.Role?.RoleName || "",
    //             Approver: item.Approver?.Title || "",
    //             ApproverID: item.Approver?.ID?.toString() || "",
    //             ApproverEmail: item.Approver?.EMail || ""
    //         }));
    //         approvalMatrix.current = approvalMatrixJSON;
    //     } catch (error) {
    //         console.error("Error fetching EmployeeMaster:", error);
    //     }
    // };
    // let getapprovalmatrix = async () => {
    //     const approverArray: any[] = [];
    //     const matchedEmployee = EmployeeQmadata.current.find(
    //         emp => String(emp.EmployeeId) === String(currentUserId.current)
    //     );
    //     // const matchedEmployee = ApprovalMatrixdata.find(
    //     //     emp => String(emp.EmployeeId) === String(currentUserId.current)
    //     // );
    //     approverArray.push({
    //         Role: "Initiator",
    //         User: matchedEmployee.Employee.Title,
    //         UserID: matchedEmployee.Employee.Id,
    //         UserEmail: matchedEmployee.Employee.EMail,
    //         Status: "Approved"
    //     });
    //     approverArray.push({
    //         Role: "RM",
    //         User: matchedEmployee.ReportingManager.Title,
    //         UserID: matchedEmployee.ReportingManager.ID,
    //         UserEmail: matchedEmployee.ReportingManager.EMail,
    //         PendingText: "Pending At RM",
    //         Status: "Pending"
    //     });
    //     approverArray.push({
    //         Role: "HOD",
    //         User: matchedEmployee.HOD.Title,
    //         UserID: matchedEmployee.HOD.ID,
    //         UserEmail: matchedEmployee.HOD.EMail,
    //         PendingText: "Pending At HOD",
    //         Status: "Pending"
    //     });
    //     // Add other approvers from ApprovalMatrix list
    //     approvalMatrix.current.forEach((item: any) => {
    //         const role = item.Role || "";
    //         const approverId = item.ApproverID?.toString();
    //         if (!approverId) return;
    //         if (role === "RM" || role === "HOD") return;
    //         let pendingText = "";
    //         if (role === "CFO")
    //             pendingText = "Pending At CFO ";
    //         else if (role === "APPerformer")
    //             pendingText = "Pending At APPerformer ";
    //         const alreadyExists =
    //             approverArray.some(x => x.ApproverID === approverId);
    //         if (alreadyExists) return;
    //         approverArray.push({
    //             Role: role,
    //             User: item.Approver || "",
    //             UserID: approverId,
    //             UserEmail: item.ApproverEmail || "",
    //             PendingText: pendingText,
    //             Status: "Pending"
    //         });
    //     });
    //     approverJson.current = approverArray;
    // }
    react_1.default.useEffect(function () {
        if (ApprovalMatrixdata.length > 0) {
            displayWorkflow();
        }
    }, [ApprovalMatrixdata]);
    var displayWorkflow = function () {
        var wf = [];
        // const _wf = approverJson.filter((item) => item.required === true);
        var isActive;
        var notActive = false;
        approverJson.current.forEach(function (m, i) {
            //if (m.required === true) {
            if (notActive === false && Stage !== 99) {
                if (Stage === i) {
                    isActive = 'activeApprover';
                    notActive = true;
                }
                else {
                    isActive = 'beforeactiveApprover';
                }
            }
            else {
                isActive = 'overrideStage';
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu" },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
            //}
        });
        setWorkflowJSX(wf);
    };
    var th = {
        textAlign: "left",
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontWeight: 700,
        fontSize: 13,
    };
    var td = {
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontSize: 13,
    };
    var loadItem = function (itemId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, item, invDate, parsedApprovalMatrix, parsedWorkflowHistory, error_6;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 4, , 5]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("ID,Title,GLDescription,CostCenterDescription,RequestDate,Amount,GLCode,CostCentre,VoucherNumber,EmployeeName,Stage,ApprovalMatrix,WorkflowHistory,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus,ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,AttachmentFiles,Status,PaymentRemarks,ApprovalRemarks,VendorCode/VendorCode,VendorCode/Title,VendorCode/Id,NatureofExpense/Title,NatureofExpense/Id,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title")
                            .expand("VendorCode,AttachmentFiles,NatureofExpense,CurrentApprover")()];
                case 1:
                    item = _b.sent();
                    console.log(item);
                    setItemID(itemId);
                    setrequestNo(item.Title || "");
                    setPayRemark(item.PaymentRemarks || "");
                    setStatus(item.Status || "");
                    // setRMVal(item.RM ?? "");
                    // setLocation(item.Location || "");
                    setRequestDate(item.RequestDate ? new Date(item.RequestDate).toLocaleDateString("en-GB") : "");
                    // setEmployeeName(item.EmployeeName || "");
                    // setDivison(item.Division || "");
                    // setEmail(item.Email || "");
                    // setHOD(item.HOD || "");
                    // setDepartment(item.Department || "");
                    // setEmpStatus(item.EmployeeStatus || "");
                    // setcontactNo(item.ContactNo || "");
                    setVendorCode(item.VendorCode.VendorCode || "");
                    setVendorName(item.VendorName || "");
                    //setNatureExpense(item.NatureofExpense.Title || "");
                    // setSelectedNatureofexpense(item.NatureofExpense.Id);
                    setSelectedNatureofexpense((_a = item.NatureofExpense) === null || _a === void 0 ? void 0 : _a.Id);
                    setInvoiceNo(item.InvoiceNumber || "");
                    invDate = new Date(item.InvoiceDate || "").toISOString().split("T")[0];
                    setInvoiceDate(invDate);
                    setBasicAmount(item.Basicamount || "");
                    setGSTAmt(item.GST || "");
                    setotherCharges(item.OtherCharges || "");
                    setTotalAmount(item.Totalamount || "");
                    setStageData(item.Stage || "");
                    setVouAmount(item.Amount || "");
                    setGLCode(item.GLCode || "");
                    setCostCentre(item.CostCentre || "");
                    setVoucherNumber(item.VoucherNumber || "");
                    setGLDescription(item.GLDescription || "");
                    setCostCenterDescription(item.CostCenterDescription || "");
                    setOriginalData({
                        Basicamount: item.Basicamount,
                        GST: item.GST,
                        OtherCharges: item.OtherCharges,
                        Totalamount: item.Totalamount,
                    });
                    parsedApprovalMatrix = [];
                    if (item.ApprovalMatrix) {
                        try {
                            parsedApprovalMatrix = JSON.parse(item.ApprovalMatrix);
                        }
                        catch (parseError) {
                            console.error("Error parsing ApprovalMatrix JSON:", parseError);
                        }
                    }
                    setApprovalMatrix(parsedApprovalMatrix);
                    return [4 /*yield*/, loadFinalNonPoFile(item.Title)];
                case 2:
                    _b.sent();
                    parsedWorkflowHistory = [];
                    if (item.WorkflowHistory) {
                        try {
                            parsedWorkflowHistory = JSON.parse(item.WorkflowHistory);
                        }
                        catch (parseError) {
                            console.error("Error parsing WorkflowHistory JSON:", parseError);
                        }
                    }
                    setWorkflowHistory(parsedWorkflowHistory);
                    // 🔥 Load Final BG attachment from library
                    return [4 /*yield*/, loadFinalPOFile(itemId)];
                case 3:
                    // 🔥 Load Final BG attachment from library
                    _b.sent();
                    return [3 /*break*/, 5];
                case 4:
                    error_6 = _b.sent();
                    console.error("Error loading item:", error_6);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var loadFinalPOFile = function (itemId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, folders, folderPath, files, formattedFiles, error_7;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPoDoc")
                            .items
                            .filter("MainID eq '".concat(itemId, "'"))
                            .select("FileRef", "FileLeafRef")()];
                case 1:
                    folders = _a.sent();
                    if (!folders.length) {
                        return [2 /*return*/];
                    }
                    folderPath = folders[0].FileRef;
                    console.log("Folder Path:", folderPath);
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files()];
                case 2:
                    files = _a.sent();
                    console.log("Files Inside Folder:", files);
                    formattedFiles = files.map(function (file) { return ({
                        FileLeafRef: file.Name,
                        FileRef: file.ServerRelativeUrl
                    }); });
                    setPOAttachments({
                        allFiles: formattedFiles
                    });
                    return [3 /*break*/, 4];
                case 3:
                    error_7 = _a.sent();
                    console.error("Error loading files:", error_7);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var toFolderName = function (requestNo) {
        return (requestNo || "NONPO")
            .replace(/[\\#%&*:{?<>|"]/g, "_") // removed /
            .replace(/\//g, "-")
            .trim();
    };
    var handleUpdate = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, item, stage, approverId, pendingText, Statuschanges, updatedHistory, changed, workflowHistory, lastEntry, lastApproverName, currentUserName, performer, isSentBackByPerformer, performer_1, newHistoryEntry, newHistoryEntry, newHistoryEntry, folderItem, folderPath, folder, existingFiles_2, _i, existingFiles_1, file, fileBuffer, error_8;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    if (!BasicAmount) {
                        alert("Please Enter Basic Amount");
                        return [2 /*return*/];
                    }
                    if (!InvoiceNo) {
                        alert("Please Enter Invoice No");
                        return [2 /*return*/];
                    }
                    if (!InvoiceDate) {
                        alert("Please Select Invoice Date");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 14, , 15]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(ItemID)
                            .select("*")()];
                case 2:
                    item = _a.sent();
                    stage = 1;
                    approverId = RMID.current;
                    pendingText = "Pending At RM";
                    Statuschanges = "Pending for Approval";
                    updatedHistory = void 0;
                    if (!(Status == 'Send Back')) return [3 /*break*/, 13];
                    changed = isDataChanged();
                    workflowHistory = tslib_1.__spreadArray([], WorkflowHistory, true);
                    lastEntry = workflowHistory[workflowHistory.length - 1];
                    lastApproverName = lastEntry === null || lastEntry === void 0 ? void 0 : lastEntry.CurrentApprover;
                    currentUserName = props.currentSPContext.pageContext.user.displayName || props.currentSPContext.pageContext.user.email;
                    performer = approverJson.current.find(function (x) { return x.Role === "APPerformer"; });
                    isSentBackByPerformer = performer && lastApproverName === performer.User;
                    if (!changed) {
                        if (isSentBackByPerformer) {
                            performer_1 = approverJson.current.find(function (x) { return x.Role === "APPerformer"; });
                            if (performer_1) {
                                stage = approverJson.current.findIndex(function (x) { return x.Role === "APPerformer"; });
                                approverId = parseInt(performer_1.UserID);
                                pendingText = performer_1.PendingText || "Pending At AP Performer";
                                Statuschanges = "Pending for Acceptance";
                                newHistoryEntry = {
                                    CurrentApprover: props.currentSPContext.pageContext.user.displayName
                                        || props.currentSPContext.pageContext.user.email
                                        || '',
                                    ActionTaken: 'Request submitted',
                                    Comment: PayRemark,
                                    Date: "".concat(new Date()),
                                    CurrentStatus: Statuschanges
                                };
                                workflowHistory.push(newHistoryEntry);
                                setWorkflowHistory(workflowHistory);
                                updatedHistory = JSON.stringify(workflowHistory);
                            }
                        }
                        else {
                            // 👉 Changed → restart from RM
                            stage = 1;
                            approverId = RMID.current;
                            pendingText = "Pending At RM";
                            Statuschanges = "Pending for Approval";
                            newHistoryEntry = {
                                CurrentApprover: props.currentSPContext.pageContext.user.displayName
                                    || props.currentSPContext.pageContext.user.email
                                    || '',
                                ActionTaken: 'Request submitted',
                                Comment: '',
                                Date: "".concat(new Date()),
                                CurrentStatus: Statuschanges
                            };
                            workflowHistory.push(newHistoryEntry);
                            setWorkflowHistory(workflowHistory);
                            updatedHistory = JSON.stringify(workflowHistory);
                        }
                    }
                    else {
                        // 👉 Changed → restart from RM
                        stage = 1;
                        approverId = RMID.current;
                        pendingText = "Pending At RM";
                        Statuschanges = "Pending for Approval";
                        newHistoryEntry = {
                            CurrentApprover: props.currentSPContext.pageContext.user.displayName
                                || props.currentSPContext.pageContext.user.email
                                || '',
                            ActionTaken: 'Request submitted',
                            Comment: '',
                            Date: "".concat(new Date()),
                            CurrentStatus: Statuschanges
                        };
                        workflowHistory.push(newHistoryEntry);
                        setWorkflowHistory(workflowHistory);
                        updatedHistory = JSON.stringify(workflowHistory);
                    }
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(ItemID)
                            .update({
                            Basicamount: BasicAmount.toString(),
                            GST: GSTAmt.toString(),
                            OtherCharges: otherCharges.toString(),
                            Totalamount: TotalAmount.toString(),
                            ApproverStatus: "Pending",
                            ApprovalMatrix: JSON.stringify(approverJson.current),
                            Status: Statuschanges,
                            WorkflowHistory: updatedHistory,
                            Stage: stage,
                            CurrentApproverId: approverId,
                            PendingAt: pendingText,
                            InvoiceNumber: InvoiceNo.toString(),
                            InvoiceDate: InvoiceDate,
                            PaymentRemarks: PayRemark,
                            NatureofExpenseId: selectedNatureofexpense
                            //  Stage: 1
                        })];
                case 3:
                    _a.sent();
                    if (!POTextAttachFile) return [3 /*break*/, 12];
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPoDoc")
                            .items
                            .filter("MainID eq '".concat(ItemID, "'"))
                            .select("FileRef")
                            .top(1)()];
                case 4:
                    folderItem = _a.sent();
                    if (!(folderItem.length > 0)) return [3 /*break*/, 12];
                    folderPath = folderItem[0].FileRef;
                    folder = sp.web.getFolderByServerRelativePath(folderPath);
                    return [4 /*yield*/, folder.files()];
                case 5:
                    existingFiles_2 = _a.sent();
                    _i = 0, existingFiles_1 = existingFiles_2;
                    _a.label = 6;
                case 6:
                    if (!(_i < existingFiles_1.length)) return [3 /*break*/, 9];
                    file = existingFiles_1[_i];
                    return [4 /*yield*/, sp.web
                            .getFileByServerRelativePath(file.ServerRelativeUrl)
                            .delete()];
                case 7:
                    _a.sent();
                    _a.label = 8;
                case 8:
                    _i++;
                    return [3 /*break*/, 6];
                case 9: return [4 /*yield*/, POTextAttachFile.arrayBuffer()];
                case 10:
                    fileBuffer = _a.sent();
                    return [4 /*yield*/, folder.files.addUsingPath(POTextAttachFile.name, fileBuffer, { Overwrite: true })];
                case 11:
                    _a.sent();
                    _a.label = 12;
                case 12:
                    alert("SendBack request submitted successfully.");
                    navigate('/');
                    _a.label = 13;
                case 13: return [3 /*break*/, 15];
                case 14:
                    error_8 = _a.sent();
                    console.error("Error updating item:", error_8);
                    alert("Update failed. Please try again.");
                    return [3 /*break*/, 15];
                case 15: return [2 /*return*/];
            }
        });
    }); };
    var isDataChanged = function () {
        if (!originalData)
            return true;
        return (originalData.Basicamount !== BasicAmount ||
            originalData.GST !== GSTAmt ||
            originalData.OtherCharges !== otherCharges ||
            originalData.Totalamount !== TotalAmount);
    };
    var loadFinalNonPoFile = function (requestNo) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, absUrl, origin_1, libTitle, libFiles, root, rootUrl, folderPath, files, _i, _a, f, error_9, e_1;
        var _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    _e.trys.push([0, 6, 7, 8]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    absUrl = ((_d = (_c = (_b = props.currentSPContext) === null || _b === void 0 ? void 0 : _b.pageContext) === null || _c === void 0 ? void 0 : _c.web) === null || _d === void 0 ? void 0 : _d.absoluteUrl) || "";
                    origin_1 = window.location.origin;
                    // if (!props.currentSPContext || !requestNo) return;
                    setLoadingExisting(true);
                    libTitle = "NonPODoc";
                    libFiles = [];
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(libTitle).rootFolder()];
                case 2:
                    root = _e.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderPath = "".concat(rootUrl, "/").concat(toFolderName(requestNo));
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.select("Name,ServerRelativeUrl,Length,TimeLastModified")()];
                case 3:
                    files = _e.sent();
                    for (_i = 0, _a = files || []; _i < _a.length; _i++) {
                        f = _a[_i];
                        libFiles.push({
                            name: f.Name,
                            url: "".concat(origin_1).concat(f.ServerRelativeUrl),
                            sizeBytes: Number(f.Length || 0),
                            lastModified: f.TimeLastModified,
                            source: "Library",
                            serverRelativeUrl: f.ServerRelativeUrl,
                        });
                    }
                    return [3 /*break*/, 5];
                case 4:
                    error_9 = _e.sent();
                    console.error(error_9);
                    alert("Something went wrong.");
                    return [3 /*break*/, 5];
                case 5:
                    setExistingFiles(tslib_1.__spreadArray([], libFiles, true));
                    return [3 /*break*/, 8];
                case 6:
                    e_1 = _e.sent();
                    console.warn("[APTeamAcceptance] existing docs load failed:", e_1);
                    setExistingFiles([]);
                    return [3 /*break*/, 8];
                case 7:
                    setLoadingExisting(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    var deleteAttachment = function (file) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, error_10;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!window.confirm("Are you sure you want to delete this file?")) {
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    // Delete file from document library folder
                    return [4 /*yield*/, sp.web
                            .getFileByServerRelativePath(file.FileRef)
                            .delete()];
                case 2:
                    // Delete file from document library folder
                    _a.sent();
                    // Remove from UI
                    setPOAttachments(function (prev) {
                        var _a;
                        return (tslib_1.__assign(tslib_1.__assign({}, prev), { allFiles: ((_a = prev.allFiles) === null || _a === void 0 ? void 0 : _a.filter(function (f) { return f.FileRef !== file.FileRef; })) || [] }));
                    });
                    alert("File deleted successfully");
                    return [3 /*break*/, 4];
                case 3:
                    error_10 = _a.sent();
                    console.error("Delete failed:", error_10);
                    alert("Failed to delete file");
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    // ✅ UI must return something
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement("div", { className: "bordered" },
            react_1.default.createElement("a", null,
                react_1.default.createElement("img", { src: sona_comstarlogo_png_1.default })),
            react_1.default.createElement("h1", null, "Non PO Approval")),
        react_1.default.createElement("div", { className: 'displayWF' }, WorkflowJSX),
        react_1.default.createElement("div", { className: 'borderedbox' },
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Requestor Information")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Request Date "),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            RequestDate)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Employee Name "),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeName)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Employee Email "),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeEmail))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Contact No"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeContactno)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Employee Status"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeStatus)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Division"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeDivision))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Location"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Locationdata)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "RM"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeRM)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "HOD"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            hoddata))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Department"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Department)),
                    react_1.default.createElement("div", { className: 'col-md-4 alignbox' },
                        react_1.default.createElement("label", { className: 'font fontpadd' }, "Status"),
                        " \u00A0 : \u00A0",
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Status)))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Invoice Details")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font' }, "Vendor Code : \u00A0\u00A0"),
                        react_1.default.createElement("input", { value: VendorCode, className: 'form-control readonly' })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font' }, "Vendor Name : \u00A0\u00A0"),
                        react_1.default.createElement("input", { value: VendorName, className: 'form-control readonly' })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font' }, "Nature of Expense : \u00A0\u00A0"),
                        react_1.default.createElement(react_2.Dropdown, { options: NatureOfExpenseTypeOptions, selectedKey: selectedNatureofexpense, onChange: function (e, option) { setSelectedNatureofexpense(option === null || option === void 0 ? void 0 : option.key); } }))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Status", className: 'font fontblock' }, "Invoice No : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "invoiceNo", className: "form-control", value: InvoiceNo, onChange: function (e) { return setInvoiceNo(e.target.value); } })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Invoice Date : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "invoicedate", className: "form-control", value: InvoiceDate, onChange: function (e) { return setInvoiceDate(e.target.value); } })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Basic Amount : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "basicAmt", className: "form-control", type: "number", value: BasicAmount, onChange: handleAmountChange("BasicAmount") }))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "GST Amount : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "gstAmt", className: "form-control", type: "number", value: GSTAmt, onChange: handleAmountChange("GSTAmt") })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Other Charges (If any) : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "othercharge", className: "form-control", type: "number", value: otherCharges, onChange: handleAmountChange("OtherCharges") })),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "RM", className: 'fontfontblock ' }, "Total Amount : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "totAmt", className: "form-control", type: "text", value: TotalAmount }))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Remarks for NON-PO Expense : \u00A0\u00A0"),
                        react_1.default.createElement("input", { id: "othercharge", className: "form-control", type: "text", value: PayRemark, onChange: function (e) { return setPayRemark(e.target.value); } })))),
            Status === "Pending for Vouching" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement("div", { className: "heading1" },
                    react_1.default.createElement("label", null, "AP Performer Updates")),
                react_1.default.createElement("div", { className: 'main-formcontainer' },
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                GLCode)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code Description : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                GLDescription))),
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                CostCentre)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center Description: : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                CostCenterDescription))),
                    react_1.default.createElement("div", { className: 'row mb-20' },
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, " Voucher Number : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                VoucherNumber)),
                        react_1.default.createElement("div", { className: 'col-md-6' },
                            react_1.default.createElement("label", { className: 'font fontblock' }, "Voucher Amount : \u00A0\u00A0 "),
                            react_1.default.createElement("label", { className: 'fonttext' },
                                "  ",
                                VouAmount)))))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Attached Documents")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: "col-md-4" },
                        react_1.default.createElement("label", { className: 'font' }, "Attachment "),
                        react_1.default.createElement("div", null,
                            ((_a = POAttachments.allFiles) === null || _a === void 0 ? void 0 : _a.length) > 0 &&
                                POAttachments.allFiles.map(function (file, index) { return (react_1.default.createElement("div", { key: index, className: "d-flex align-items-center gap-2 mt-1" },
                                    react_1.default.createElement("a", { href: file.FileRef, target: "_blank", rel: "noopener noreferrer" }, file.FileLeafRef),
                                    react_1.default.createElement("span", { style: {
                                            color: "red",
                                            fontWeight: "bold",
                                            cursor: "pointer",
                                            fontSize: "18px"
                                        }, onClick: function () { return deleteAttachment(file); } }, "\u00D7"))); }),
                            react_1.default.createElement(antd_1.Upload, { beforeUpload: function (file) {
                                    setPOTextAttachFile(file);
                                    return false;
                                }, onRemove: function () {
                                    setPOTextAttachFile(null);
                                }, maxCount: 1, className: "upload-full-width" },
                                react_1.default.createElement(antd_1.Button, { className: "upload-btn-full", icon: react_1.default.createElement(icons_1.UploadOutlined, null), iconPosition: "end" })),
                            POTextAttachFile && (react_1.default.createElement("div", { className: "mt-1 text-success" },
                                "Selected: ",
                                POTextAttachFile.name)))))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Work Flow History")),
            react_1.default.createElement("div", { className: "main-formcontainer" },
                react_1.default.createElement("div", { className: 'Workflowbox' }, WorkflowHistory && WorkflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "workflow-table", style: { width: '100%', borderCollapse: 'collapse' } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Date"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action By"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Taken"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Comment"))),
                    react_1.default.createElement("tbody", null, WorkflowHistory.map(function (h, idx) { return (react_1.default.createElement("tr", { key: idx },
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Date ? new Date(h.Date).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replace(",", "") : ""),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.CurrentApprover || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.ActionTaken || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Comment || ''))); })))) : (react_1.default.createElement("p", null, "No workflow history")))),
            react_1.default.createElement("div", { style: { display: "flex", justifyContent: "center", gap: "5px", margin: "10px 20px" } },
                react_1.default.createElement("a", { className: "submit-btn", onClick: function () { return handleUpdate(); } }, "Submit"),
                react_1.default.createElement("a", { className: "reset-btn", onClick: function () { return navigate(-1); } }, "Exit")))));
};
exports.ViewRequestSendBack = ViewRequestSendBack;
//# sourceMappingURL=ViewRequestSendBack.js.map