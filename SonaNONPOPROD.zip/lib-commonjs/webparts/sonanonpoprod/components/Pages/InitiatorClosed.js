"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InitiatorClosed = void 0;
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/site-users/web");
var newspcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/newspcrudops"));
require("./CSS/NewRequest.scss");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
var LeftArrow_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/LeftArrow.png"));
var RightArrow_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/RightArrow.png"));
var Eye_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/Eye.png"));
var react_router_dom_1 = require("react-router-dom");
var react_router_dom_2 = require("react-router-dom");
var InitiatorClosed = function (props) {
    var navigate = (0, react_router_dom_2.useNavigate)();
    var _a = (0, react_1.useState)([]), filteredData = _a[0], setFilteredData = _a[1];
    var _b = (0, react_1.useState)(""), searchTerm = _b[0], setSearchTerm = _b[1];
    var itemsPerPage = 10;
    var _c = (0, react_1.useState)(1), currentPage = _c[0], setCurrentPage = _c[1];
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    var _d = react_1.default.useState([]), ApprovedData = _d[0], setApprovedData = _d[1];
    var _e = (0, react_1.useState)(), ItemID = _e[0], setItemID = _e[1];
    var _f = (0, react_1.useState)(), requestNo = _f[0], setrequestNo = _f[1]; // useState<string | undefined>(undefined);                     
    (0, react_1.useEffect)(function () {
        loadApproveItems();
    }, []);
    var formatDate = function (dateString) {
        if (!dateString)
            return "";
        var date = new Date(dateString);
        return date
            .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
        })
            .replace(/\//g, "-"); // dd-MM-yyyy
    };
    var th = {
        textAlign: "left",
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontWeight: 700,
        fontSize: 13,
    };
    var td = {
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontSize: 13,
    };
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    var sortedData = tslib_1.__spreadArray([], filteredData, true).sort(function (a, b) { return b.ID - a.ID; });
    var paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    var safeNum = function (n) {
        var v = Number((n !== null && n !== void 0 ? n : "").toString().replace(/,/g, "").trim());
        return Number.isFinite(v) ? v : 0;
    };
    (0, react_1.useEffect)(function () {
        if (!searchTerm) {
            setFilteredData(ApprovedData);
            setCurrentPage(1);
            return;
        }
        var lowerSearch = searchTerm.toLowerCase();
        var filtered = ApprovedData.filter(function (item) {
            var _a;
            return Object.values({
                Id: item.Id,
                Title: item.Title,
                RequestDate: formatDate(item.RequestDate),
                EmployeeName: item.EmployeeName,
                VendorName: item.VendorName,
                VendorCode: (_a = item.VendorCode) === null || _a === void 0 ? void 0 : _a.VendorCode,
                InvoiceNumber: item.InvoiceNumber,
                Amount: item.Amount,
                Status: item.Status
            })
                .join(" ")
                .toLowerCase()
                .includes(lowerSearch);
        });
        setFilteredData(filtered);
        setCurrentPage(1);
    }, [searchTerm, ApprovedData]);
    var loadApproveItems = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, sp, currentUser, parentItems;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, newspcrudops_1.default)(props)];
                case 1:
                    spCrudOps = _a.sent();
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 2:
                    currentUser = _a.sent();
                    return [4 /*yield*/, spCrudOps.getData("NonPO", "ID,Title,RequestDate,EmployeeName,ApprovalMatrix,WorkflowHistory,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus,ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,Status,PaymentRemarks,ApprovalRemarks,VendorCode/VendorCode,VendorCode/Id,VendorCode/Title,NatureofExpense/Title,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title", "VendorCode,NatureofExpense,CurrentApprover", "Status eq 'Closed' and Email eq '".concat(props.userEmail, "'"), { column: "ID", isAscending: true })];
                case 3:
                    parentItems = _a.sent();
                    console.log(parentItems);
                    console.log(parentItems);
                    setApprovedData(parentItems);
                    setFilteredData(parentItems);
                    return [2 /*return*/];
            }
        });
    }); };
    // ✅ UI must return something
    return (react_1.default.createElement("div", { className: 'MainUplodForm', style: { margin: "0px" } },
        react_1.default.createElement("div", { className: 'row' },
            react_1.default.createElement("div", { className: 'col-md-12' },
                react_1.default.createElement("div", null,
                    react_1.default.createElement("div", { className: "bordered" },
                        react_1.default.createElement("img", { src: sona_comstarlogo_png_1.default }),
                        react_1.default.createElement("h1", null, "Closed Requests ")),
                    react_1.default.createElement("div", { className: 'col-md-12 px-2 d-flex justify-content-between align-items-center flex-wrap', style: { margin: "5px" } },
                        react_1.default.createElement("div", null,
                            react_1.default.createElement("input", { type: "text", placeholder: "Search...", className: "form-control", style: { width: "250px" }, value: searchTerm, onChange: function (e) { return setSearchTerm(e.target.value); } }))),
                    react_1.default.createElement("div", { style: { padding: "0px 10px" } },
                        react_1.default.createElement("div", { style: { overflowX: "auto" } },
                            react_1.default.createElement("table", { className: "custom-table", style: { width: '100%', borderCollapse: 'collapse' } },
                                react_1.default.createElement("thead", null,
                                    react_1.default.createElement("tr", null,
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "View"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "NonPo Request No"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Request Date"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Requestor Name"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Vendor Name "),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Vendor Code "),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Invoice No"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Amount"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Status"))),
                                react_1.default.createElement("tbody", null, paginatedData.map(function (item, index) { return (react_1.default.createElement("tr", { key: index, className: "border-t" },
                                    react_1.default.createElement("td", { className: "px-4 py-2" },
                                        react_1.default.createElement(react_router_dom_1.Link, { to: "/ViewRequest/".concat(item.Id) },
                                            react_1.default.createElement("img", { src: Eye_png_1.default, width: 15 }))),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.Title),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, formatDate(item.RequestDate)),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.EmployeeName),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.VendorName),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.VendorCode.VendorCode),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.InvoiceNumber),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, (item === null || item === void 0 ? void 0 : item.Totalamount) !== undefined
                                        ? safeNum(item === null || item === void 0 ? void 0 : item.Totalamount)
                                        : safeNum(item === null || item === void 0 ? void 0 : item.Amount)),
                                    react_1.default.createElement("td", { className: "px-4 py-2" }, item.Status))); })))),
                        react_1.default.createElement("div", { className: "flex justify-center mt-6 overflow-x-auto" },
                            react_1.default.createElement("div", { className: "flex space-x-2 flex-nowrap px-4 py-2 bg-#2149d5 rounded shadow", style: { textAlign: "end" } },
                                react_1.default.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1, style: {
                                        backgroundColor: "#fff",
                                        border: "1px solid #000 !important",
                                        marginRight: "5px",
                                        opacity: currentPage === 1 ? 0.5 : 1,
                                    }, className: "px-3 py-1 border rounded" },
                                    react_1.default.createElement("img", { src: LeftArrow_png_1.default, alt: "", width: 15 })),
                                Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                                    .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                                    .map(function (page) { return (react_1.default.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, style: {
                                        backgroundColor: currentPage === page ? "#3c3e45" : "#fff",
                                        color: currentPage === page ? "#fff" : "#000",
                                        fontWeight: currentPage === page ? "bold" : "normal",
                                        margin: currentPage === page ? "5px" : "5px",
                                    }, className: "px-3 py-1 border rounded" }, page)); }),
                                react_1.default.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages, style: {
                                        backgroundColor: "#fff",
                                        border: "1px solid #000 !important",
                                        marginLeft: "5px",
                                        opacity: currentPage === totalPages ? 0.5 : 1,
                                    }, className: "px-3 py-1 border rounded" },
                                    react_1.default.createElement("img", { src: RightArrow_png_1.default, alt: "", width: 15 }))))))))));
};
exports.InitiatorClosed = InitiatorClosed;
//# sourceMappingURL=InitiatorClosed.js.map