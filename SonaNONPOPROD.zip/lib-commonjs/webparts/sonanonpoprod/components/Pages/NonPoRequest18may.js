"use strict";
// // NonPoRequest.tsx
// import * as React from "react";
// import { useEffect, useMemo, useRef, useState } from "react";
// import { Formik, Form, Field, FormikProps } from "formik";
// import useFullscreenForm from "../../hook/useFullscreenForm";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";
// import "@fortawesome/fontawesome-free/css/all.min.css";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
// NonPoRequest.tsx
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var formik_1 = require("formik");
var useFullscreenForm_1 = tslib_1.__importDefault(require("../../hook/useFullscreenForm"));
require("bootstrap/dist/css/bootstrap.min.css");
require("bootstrap/dist/js/bootstrap.bundle.min.js");
require("@fortawesome/fontawesome-free/css/all.min.css");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
// PnPjs 
var sp_1 = require("@pnp/sp");
var spfx_1 = require("@pnp/sp/behaviors/spfx");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/attachments");
require("@pnp/sp/site-users/web");
require("@pnp/sp/folders");
require("@pnp/sp/files");
var react_router_dom_1 = require("react-router-dom");
/** ===================== SITE & LISTS ===================== */
var SITE_ABS_URL = "https://isriglobal.sharepoint.com/sites/SonaNONPO";
var NONPO_LIST_TITLE = "NonPO";
var VENDOR_MASTER = "VendorMaster";
var NOE_MASTER = "ExpenseMaster";
var COUNTRY_MASTER = "CountryMaster";
var EMPLIST = "EmployeeMaster";
/** ===================== ATTACHMENT LIMIT ===================== */
var ATTACH_LIB = "NonPODoc";
var MAX_FILE_SIZE_MB = 25;
var MAX_FILE_SIZE = MAX_FILE_SIZE_MB * 1024 * 1024;
/** ===================== Helpers ===================== */
var toISO = function (d) { return d.toISOString().split("T")[0]; };
var toISOInput = function (d) {
    if (!d)
        return "";
    var dt = new Date(d);
    if (Number.isNaN(dt.getTime()))
        return "";
    return dt.toISOString().split("T")[0];
};
var safeNum = function (s) {
    var n = Number((s || "0").toString().replace(/,/g, "").trim());
    return isNaN(n) ? 0 : n;
};
var fyFromDate = function (d) {
    var y = d.getFullYear();
    var m = d.getMonth() + 1;
    var yy = y % 100;
    if (m >= 4) {
        var next = (yy + 1) % 100;
        return "".concat(String(yy).padStart(2, "0"), "-").concat(String(next).padStart(2, "0"));
    }
    else {
        var prev = (yy - 1 + 100) % 100;
        return "".concat(String(prev).padStart(2, "0"), "-").concat(String(yy).padStart(2, "0"));
    }
};
var tryParseLastNumber = function (title) {
    if (!title)
        return 0;
    var parts = title.split("/");
    var last = parts[parts.length - 1] || "";
    var n = parseInt(last, 10);
    return isNaN(n) ? 0 : n;
};
var buildRequestId = function (fy, seq) {
    return "NON PO/".concat(fy, "/").concat(String(seq).padStart(5, "0"));
};
// const loadApprovalRoles = async (spx: SPFI) => {
//   const rows = await spx.web.lists.getByTitle("NONPOApprovalMatrix")
//     .items.select("Title", "Role", "Approver/Id", "Approver/Title", "Approver/EMail")
//     .expand("Approver")();
//   return rows.map(r => ({
//     Role: r.Role,
//     User: r.Approver?.Title || "",
//     UserID: r.Approver?.Id || null,
//     UserEmail: r.Approver?.EMail || "",
//     PendingText:
//       r.Role === "CFO" ? "Pending At Level 2 CEO" :
//         r.Role === "Performer" ? "Pending Level 3 Performer"
//           : ""
//   }));
// };
// const loadApprovalRoles = async (spx: SPFI) => {
//   const rows = await spx.web.lists.getByTitle("NONPOApprovalMatrix")
//     .items.select(
//       "Id",
//       "Title",
//       "ApprovalType",
//       "Status",
//       "Role/Id",
//       "Role/Title",
//       "Level/Id",
//       "Level/Title",
//       "Approver/Id",
//       "Approver/Title",
//       "Approver/EMail"
//     )
//     .expand("Role", "Level", "Approver")();
//   return rows.map(r => ({
//     Role: r.Role?.Title || "",
//     Level: r.Level?.Title || "",
//     User: r.Approver?.Title || "",
//     UserID: r.Approver?.Id || null,
//     UserEmail: r.Approver?.EMail || "",
//     PendingText:
//       r.Role?.Title === "CFO"
//         ? "Pending At Level 2 CEO"
//         : r.Role?.Title === "APPerformer" || r.Role?.Title === "Performer"
//           ? "Pending Level 3 Performer"
//           : ""
//   }));
// };
// Approval Matrix
// const loadApprovalRoles = async (spx: SPFI) => {
//   const rows = await spx.web.lists
//     .getByTitle("NONPOApprovalMatrix")
//     .items.select(
//       "Id",
//       "Title",
//       "ApprovalType",
//       "Status",
//       "Role/Id",
//       "Role/RoleName",
//       "Approver/Id",
//       "Approver/Title",
//       "Approver/EMail"
//     )
//     .expand("Role", "Approver")
//     .filter("Status eq 'Active'")
//     ();
//   return rows.map(r => {
//     const role = (r.Role?.RoleName || "").toLowerCase();
//     let pendingText = "";
//     if (role.includes("cfo")) {
//       pendingText = "Pending At  CFO";
//     }
//     else if (
//       role.includes("apperformer") ||
//       role.includes("ap performer") ||
//       role.includes("performer")
//     ) {
//       pendingText = "Pending At AP Performer";
//     }
//     return {
//       Role: r.Role?.RoleName || "",
//       User: r.Approver?.Title || "",
//       UserID: r.Approver?.Id || null,
//       UserEmail: r.Approver?.EMail || "",
//       PendingText: pendingText
//     };
//   });
// };
var loadApprovalRoles = function (spx) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var rows;
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, spx.web.lists
                    .getByTitle("NONPOApprovalMatrix")
                    .items
                    .select("Id", "Title", "ApprovalType", "Status", "Role/Id", "Role/RoleName", "Approver/Id", "Approver/Title", "Approver/EMail")
                    .expand("Role", "Approver")
                    .filter("Status eq 'Active'")()];
            case 1:
                rows = _a.sent();
                return [2 /*return*/, rows.map(function (r) {
                        var _a, _b, _c, _d, _e;
                        var role = (((_a = r.Role) === null || _a === void 0 ? void 0 : _a.RoleName) || "").toLowerCase();
                        var pendingText = "";
                        if (role.includes("cfo")) {
                            pendingText = "Pending At CFO";
                        }
                        else if (role.includes("apperformer") ||
                            role.includes("ap performer") ||
                            role.includes("performer")) {
                            pendingText = "Pending At AP Performer";
                        }
                        return {
                            Role: ((_b = r.Role) === null || _b === void 0 ? void 0 : _b.RoleName) || "",
                            User: ((_c = r.Approver) === null || _c === void 0 ? void 0 : _c.Title) || "",
                            UserID: ((_d = r.Approver) === null || _d === void 0 ? void 0 : _d.Id) || null,
                            UserEmail: ((_e = r.Approver) === null || _e === void 0 ? void 0 : _e.EMail) || "",
                            PendingText: pendingText
                        };
                    })];
        }
    });
}); };
var NonPoRequest = function (props) {
    (0, useFullscreenForm_1.default)();
    var navigate = (0, react_router_dom_1.useNavigate)();
    var params = (0, react_router_dom_1.useSearchParams)()[0];
    /** ------------ Router params ------------ */
    var idParam = params.get("id");
    var modeParam = (params.get("mode") || "view").toLowerCase();
    var numericId = (0, react_1.useMemo)(function () {
        var n = Number(idParam);
        return Number.isFinite(n) ? n : undefined;
    }, [idParam]);
    var isNew = modeParam === "new" || !numericId;
    var isEdit = modeParam === "edit" || isNew;
    var modeLabel = isNew ? "New" : isEdit ? "Edit" : "View";
    /** ------------ SP instance ------------ */
    var _a = (0, react_1.useState)(null), sp = _a[0], setSp = _a[1];
    (0, react_1.useEffect)(function () {
        if (!props.currentSPContext)
            return;
        setSp((0, sp_1.spfi)().using((0, spfx_1.SPFx)(props.currentSPContext)));
    }, [props.currentSPContext]);
    /** ------------ Masters & UI ------------ */
    var _b = (0, react_1.useState)([]), vendors = _b[0], setVendors = _b[1];
    var _c = (0, react_1.useState)([]), noeOptions = _c[0], setNoeOptions = _c[1];
    var _d = (0, react_1.useState)([]), ccOptions = _d[0], setCcOptions = _d[1];
    var _e = (0, react_1.useState)(false), loading = _e[0], setLoading = _e[1];
    var _f = (0, react_1.useState)(""), err = _f[0], setErr = _f[1];
    var _g = React.useState(null), WorkflowJSX = _g[0], setWorkflowJSX = _g[1];
    var approverJson = React.useRef([]);
    var _h = React.useState([]), Employeemasterdata = _h[0], setEmployeeMasterdata = _h[1];
    var EmployeeQmadata = React.useRef([]);
    var currentUserId = React.useRef(0);
    // let EmployeeQmadata = React.useRef<any[]>(null);
    var _j = React.useState(), HOD = _j[0], setHOD = _j[1];
    var _k = React.useState(), Department = _k[0], setDepartment = _k[1];
    var _l = React.useState(), EmpStatus = _l[0], setEmpStatus = _l[1];
    var _m = React.useState([]), ApprovalMatrixdata = _m[0], setApprovalMatrix = _m[1];
    //const approvalMatrix = React.useState<any[]>([]);// useRef<any[]>(null);
    var approvalMatrix = React.useRef([]);
    var _o = React.useState(0), Stage = _o[0], setStageData = _o[1];
    /** ------------ Existing documents------------ */
    var _p = (0, react_1.useState)([]), existingFiles = _p[0], setExistingFiles = _p[1];
    var _q = (0, react_1.useState)(false), loadingExisting = _q[0], setLoadingExisting = _q[1];
    /** ------------ Requester defaults------------ */
    var _r = (0, react_1.useState)(false), profileLoaded = _r[0], setProfileLoaded = _r[1];
    // const [reqDefaults, setReqDefaults] = useState({
    //   EmployeeName: props.currentSPContext?.pageContext?.user?.displayName || "",
    //   Email: props.currentSPContext?.pageContext?.user?.email || "",
    //   Department: "",
    //   Division: "",
    //   Location: "",
    //   ContactNo: "",
    //   EmployeeCode: "",
    //   RM: "",
    //   HOD: "",
    //   EmployeeStatus: "Existing",
    // });
    var _s = (0, react_1.useState)({
        EmployeeName: "",
        Email: "",
        Department: "",
        Division: "",
        Location: "",
        ContactNo: "",
        EmployeeCode: "",
        RM: "",
        RMEmail: "",
        HOD: "",
        HODEmail: "",
        EmployeeStatus: "Existing",
    }), reqDefaults = _s[0], setReqDefaults = _s[1];
    //SNEHAL
    var getdata = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: 
                // await userProfile();
                return [4 /*yield*/, fetchEmployeeMaster()];
                case 1:
                    // await userProfile();
                    _a.sent();
                    return [4 /*yield*/, fetchApprovalMatrix()];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, getapprovalmatrix()];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, displayWorkflow()];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        getdata();
    }, []);
    React.useEffect(function () {
        var loadCurrentUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var sp_2, user, error_1;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        sp_2 = (0, sp_1.spfi)().using((0, spfx_1.SPFx)(props.currentSPContext));
                        return [4 /*yield*/, sp_2.web.currentUser()];
                    case 1:
                        user = _a.sent();
                        currentUserId.current = user.Id;
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        console.error("Error fetching current user:", error_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        }); };
        loadCurrentUser();
    }, [props.currentSPContext]);
    var fetchApprovalMatrix = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_3, parentItems, approvalMatrixJSON, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    sp_3 = (0, sp_1.spfi)().using((0, spfx_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp_3.web.lists
                            .getByTitle("NONPOApprovalMatrix")
                            .items
                            .select("*", "Id,ApprovalType,Role/ID,Role/RoleName,Level/ID,Level/Level,Status,Approver/ID,Approver/Title,Approver/EMail")
                            .expand("Role", "Level", "Approver")
                            .filter("Status eq 'Active'")()];
                case 1:
                    parentItems = _a.sent();
                    approvalMatrixJSON = parentItems.map(function (item) {
                        var _a, _b, _c, _d, _e;
                        return ({
                            Role: ((_a = item.Role) === null || _a === void 0 ? void 0 : _a.RoleName) || "",
                            Approver: ((_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title) || "",
                            ApproverID: ((_d = (_c = item.Approver) === null || _c === void 0 ? void 0 : _c.ID) === null || _d === void 0 ? void 0 : _d.toString()) || "",
                            ApproverEmail: ((_e = item.Approver) === null || _e === void 0 ? void 0 : _e.EMail) || ""
                        });
                    });
                    approvalMatrix.current = approvalMatrixJSON;
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching EmployeeMaster:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var getapprovalmatrix = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var approverArray, matchedEmployee;
        return tslib_1.__generator(this, function (_a) {
            approverArray = [];
            matchedEmployee = EmployeeQmadata.current.find(function (emp) { return String(emp.EmployeeId) === String(currentUserId.current); });
            approverArray.push({
                Role: "Initiator",
                User: matchedEmployee.Employee.Title,
                UserID: matchedEmployee.Employee.Id,
                UserEmail: matchedEmployee.Employee.EMail
            });
            approverArray.push({
                Role: "RM",
                User: matchedEmployee.ReportingManager.Title,
                UserID: matchedEmployee.ReportingManager.ID,
                UserEmail: matchedEmployee.ReportingManager.EMail,
                PendingText: "Pending At RM"
            });
            approverArray.push({
                Role: "HOD",
                User: matchedEmployee.HOD.Title,
                UserID: matchedEmployee.HOD.ID,
                UserEmail: matchedEmployee.HOD.EMail,
                PendingText: "Pending At HOD"
            });
            // Add other approvers from ApprovalMatrix list
            approvalMatrix.current.forEach(function (item) {
                var _a;
                var role = item.Role || "";
                var approverId = (_a = item.ApproverID) === null || _a === void 0 ? void 0 : _a.toString();
                if (!approverId)
                    return;
                if (role === "RM" || role === "HOD")
                    return;
                var pendingText = "";
                if (role === "CFO")
                    pendingText = "Pending At CFO ";
                else if (role === "APPerformer")
                    pendingText = "Pending At APPerformer ";
                var alreadyExists = approverArray.some(function (x) { return x.ApproverID === approverId; });
                if (alreadyExists)
                    return;
                approverArray.push({
                    Role: role,
                    User: item.Approver || "",
                    UserID: approverId,
                    UserEmail: item.ApproverEmail || "",
                    PendingText: pendingText
                });
            });
            approverJson.current = approverArray;
            return [2 /*return*/];
        });
    }); };
    var fetchEmployeeMaster = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_4, Empitems, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    sp_4 = (0, sp_1.spfi)().using((0, spfx_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp_4.web.lists
                            .getByTitle("EmployeeMaster")
                            .items
                            .select("*", "Employee/Title", "Employee/Id", "Employee/EMail", "ReportingManager/ID", "ReportingManager/Title", "ReportingManager/EMail", "HOD/ID", "HOD/Title", "HOD/EMail", "EmployeeEmail")
                            .expand("Employee", "ReportingManager", "HOD")()];
                case 1:
                    Empitems = _a.sent();
                    EmployeeQmadata.current = Empitems;
                    setEmployeeMasterdata(Empitems);
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.error("Error fetching EmployeeMaster:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var displayWorkflow = function () {
        var wf = [];
        // const _wf = approverJson.filter((item) => item.required === true);
        var isActive;
        var notActive = false;
        approverJson.current.forEach(function (m, i) {
            //if (m.required === true) {
            if (notActive === false && Stage !== 99) {
                if (Stage === i) {
                    isActive = 'activeApprover';
                    notActive = true;
                }
                else {
                    isActive = 'beforeactiveApprover';
                }
            }
            else {
                isActive = 'overrideStage';
            }
            wf.push(React.createElement("ul", { className: "main-menu" },
                React.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
            //}
        });
        setWorkflowJSX(wf);
    };
    (0, react_1.useEffect)(function () {
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var me, myId, myEmail, items, Error_1, esc, Error_2, row_1, Error_3;
            var _a, _b, _c;
            return tslib_1.__generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        if (!sp)
                            return [2 /*return*/];
                        _d.label = 1;
                    case 1:
                        _d.trys.push([1, 12, 13, 14]);
                        return [4 /*yield*/, sp.web.currentUser()];
                    case 2:
                        me = _d.sent();
                        myId = me === null || me === void 0 ? void 0 : me.Id;
                        myEmail = ((me === null || me === void 0 ? void 0 : me.Email) || ((_c = (_b = (_a = props.currentSPContext) === null || _a === void 0 ? void 0 : _a.pageContext) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.email) || "").trim().toLowerCase();
                        items = [];
                        _d.label = 3;
                    case 3:
                        _d.trys.push([3, 6, , 7]);
                        if (!myId) return [3 /*break*/, 5];
                        return [4 /*yield*/, sp.web.lists
                                .getByTitle(EMPLIST)
                                .items.select("ID", "Title", "EmployeeName", "EmployeeEmail", "ContactNo", "EmployeeStatus", "Division", "Location", "Department", "EmployeeCode", "Status", "ReportingManager/Title", "ReportingManager/EMail", "HOD/Title", "HOD/EMail")
                                .expand("ReportingManager", "HOD")
                                .filter("EmployeeId eq ".concat(myId))
                                .top(5)()];
                    case 4:
                        items = _d.sent();
                        _d.label = 5;
                    case 5: return [3 /*break*/, 7];
                    case 6:
                        Error_1 = _d.sent();
                        alert("Error");
                        return [3 /*break*/, 7];
                    case 7:
                        if (!!(items === null || items === void 0 ? void 0 : items.length)) return [3 /*break*/, 11];
                        _d.label = 8;
                    case 8:
                        _d.trys.push([8, 10, , 11]);
                        esc = function (s) { return s.replace(/'/g, "''"); };
                        return [4 /*yield*/, sp.web.lists
                                .getByTitle(EMPLIST)
                                .items.select("ID", "Title", "EmployeeName", "EmployeeEmail", "ContactNo", "EmployeeStatus", "Division", "Location", "Department", "EmployeeCode", "Status", "ReportingManager/Title", "ReportingManager/EMail", "HOD/Title", "HOD/EMail")
                                .expand("ReportingManager", "HOD")
                                .filter("EmployeeEmail eq '".concat(esc(myEmail), "'"))
                                .top(5)()];
                    case 9:
                        items = _d.sent();
                        return [3 /*break*/, 11];
                    case 10:
                        Error_2 = _d.sent();
                        alert("Error");
                        return [3 /*break*/, 11];
                    case 11:
                        row_1 = items === null || items === void 0 ? void 0 : items[0];
                        if (row_1) {
                            setReqDefaults(function (prev) {
                                var _a, _b, _c, _d;
                                return (tslib_1.__assign(tslib_1.__assign({}, prev), { EmployeeName: row_1.EmployeeName || row_1.Title || prev.EmployeeName, Email: (row_1.EmployeeEmail || prev.Email || "").toLowerCase(), ContactNo: row_1.ContactNo || "", EmployeeStatus: row_1.EmployeeStatus || "Existing", Division: row_1.Division || "", Location: row_1.Location || "", Department: row_1.Department || "", EmployeeCode: row_1.EmployeeCode || "", RM: ((_a = row_1 === null || row_1 === void 0 ? void 0 : row_1.ReportingManager) === null || _a === void 0 ? void 0 : _a.Title) || "", RMEmail: ((_b = row_1 === null || row_1 === void 0 ? void 0 : row_1.ReportingManager) === null || _b === void 0 ? void 0 : _b.EMail) || "", HOD: ((_c = row_1 === null || row_1 === void 0 ? void 0 : row_1.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "", HODEmail: ((_d = row_1 === null || row_1 === void 0 ? void 0 : row_1.HOD) === null || _d === void 0 ? void 0 : _d.EMail) || "" }));
                            });
                        }
                        return [3 /*break*/, 14];
                    case 12:
                        Error_3 = _d.sent();
                        alert("Error");
                        return [3 /*break*/, 14];
                    case 13:
                        setProfileLoaded(true);
                        return [7 /*endfinally*/];
                    case 14: return [2 /*return*/];
                }
            });
        }); })();
    }, [sp, props.currentSPContext]);
    /** ------------ Base initial values (used in new mode) ------------ */
    var baseInitialValues = (0, react_1.useMemo)(function () { return ({
        Title: "NON-PO Request",
        RequestDate: toISO(new Date()),
        EmployeeCode: reqDefaults.EmployeeCode,
        EmployeeName: reqDefaults.EmployeeName,
        Email: reqDefaults.Email,
        ContactNo: reqDefaults.ContactNo,
        Division: reqDefaults.Division,
        Department: reqDefaults.Department,
        Location: reqDefaults.Location,
        RM: reqDefaults.RM,
        HOD: reqDefaults.HOD,
        EmployeeStatus: reqDefaults.EmployeeStatus,
        VendorCode: null,
        VendorName: "",
        NatureofExpense: null,
        InvoiceNumber: "",
        InvoiceDate: "",
        Basicamount: "",
        GST: "",
        OtherCharges: "",
        Totalamount: "",
        PaymentRemarks: "",
        ApprovalRemarks: "",
        GLCode: "",
        VoucherNumber: "",
        Amount: "",
        attachments: [],
        // NEW
        Status: "",
    }); }, [reqDefaults]);
    var _t = (0, react_1.useState)(baseInitialValues), initialValues = _t[0], setInitialValues = _t[1];
    (0, react_1.useEffect)(function () {
        if (!numericId)
            setInitialValues(baseInitialValues);
    }, [baseInitialValues, numericId]);
    /** ------------ Masters ------------ */
    (0, react_1.useEffect)(function () {
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var vItems, opts, _a, nItems, _b, cItems, _c;
            return tslib_1.__generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        if (!sp)
                            return [2 /*return*/];
                        _d.label = 1;
                    case 1:
                        _d.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, sp.web.lists
                                .getByTitle(VENDOR_MASTER)
                                .items.select("ID,Title,VendorCode,VendorName,Status")
                                .filter("(Status eq 'Active') or (Status eq 'active')")
                                .top(5000)()];
                    case 2:
                        vItems = _d.sent();
                        opts = (vItems || []).map(function (v) {
                            var code = v.VendorCode || v.Title || "";
                            // const code = v.VendorCode;
                            var VendorName = v.VendorName || v.Title || "";
                            // const display = [code, VendorName].filter(Boolean).join(" — ");
                            var display = [code];
                            return { id: v.ID, vendorCode: code, VendorName: VendorName, title: v.Title, display: display || "#".concat(v.ID) };
                        });
                        setVendors(opts);
                        return [3 /*break*/, 4];
                    case 3:
                        _a = _d.sent();
                        setVendors([]);
                        return [3 /*break*/, 4];
                    case 4:
                        if (!NOE_MASTER) return [3 /*break*/, 8];
                        _d.label = 5;
                    case 5:
                        _d.trys.push([5, 7, , 8]);
                        return [4 /*yield*/, sp.web.lists.getByTitle(NOE_MASTER)
                                .items.select("ID,Title,Status,ExpenseType")
                                .filter("(Status eq 'Active') or (Status eq 'active')").top(5000)()];
                    case 6:
                        nItems = _d.sent();
                        setNoeOptions((nItems || []).map(function (x) { return ({ id: x.ID, title: x.ExpenseType }); }));
                        return [3 /*break*/, 8];
                    case 7:
                        _b = _d.sent();
                        setNoeOptions([]);
                        return [3 /*break*/, 8];
                    case 8:
                        if (!COUNTRY_MASTER) return [3 /*break*/, 12];
                        _d.label = 9;
                    case 9:
                        _d.trys.push([9, 11, , 12]);
                        return [4 /*yield*/, sp.web.lists.getByTitle(COUNTRY_MASTER)
                                .items.select("ID,Title,Status")
                                .filter("(Status eq 'Active') or (Status eq 'active')").top(5000)()];
                    case 10:
                        cItems = _d.sent();
                        setCcOptions((cItems || []).map(function (x) { return ({ id: x.ID, title: x.Title }); }));
                        return [3 /*break*/, 12];
                    case 11:
                        _c = _d.sent();
                        setCcOptions([]);
                        return [3 /*break*/, 12];
                    case 12: return [2 /*return*/];
                }
            });
        }); })();
    }, [sp]);
    /** ------------ prefill  item ------------ */
    (0, react_1.useEffect)(function () {
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var it_1, e_1;
            var _a, _b, _c, _d;
            return tslib_1.__generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        if (!sp || !numericId)
                            return [2 /*return*/];
                        _e.label = 1;
                    case 1:
                        _e.trys.push([1, 3, 4, 5]);
                        setLoading(true);
                        setErr("");
                        return [4 /*yield*/, sp.web.lists.getByTitle(NONPO_LIST_TITLE).items
                                .getById(numericId)
                                .select("Id,Title,RequestDate,EmployeeCode,EmployeeName,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus," +
                                "VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,PaymentRemarks,ApprovalRemarks,GLCode," +
                                "VoucherNumber,Amount,Status," +
                                "VendorCode/Id,VendorCode/Title,NatureofExpense/Id,NatureofExpense/Title")
                                .expand("VendorCode", "NatureofExpense")()];
                    case 2:
                        it_1 = _e.sent();
                        setInitialValues({
                            Title: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Title) || "NON-PO Request",
                            RequestDate: toISOInput(it_1 === null || it_1 === void 0 ? void 0 : it_1.RequestDate) || toISO(new Date()),
                            EmployeeCode: (it_1 === null || it_1 === void 0 ? void 0 : it_1.EmployeeCode) || "",
                            EmployeeName: (it_1 === null || it_1 === void 0 ? void 0 : it_1.EmployeeName) || "",
                            Email: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Email) || "",
                            ContactNo: (it_1 === null || it_1 === void 0 ? void 0 : it_1.ContactNo) || "",
                            Division: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Division) || "",
                            Department: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Department) || "",
                            Location: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Location) || "",
                            RM: (it_1 === null || it_1 === void 0 ? void 0 : it_1.RM) || "",
                            HOD: (it_1 === null || it_1 === void 0 ? void 0 : it_1.HOD) || "",
                            EmployeeStatus: (it_1 === null || it_1 === void 0 ? void 0 : it_1.EmployeeStatus) || "Existing",
                            VendorCode: (_b = (_a = it_1 === null || it_1 === void 0 ? void 0 : it_1.VendorCode) === null || _a === void 0 ? void 0 : _a.Id) !== null && _b !== void 0 ? _b : null,
                            VendorName: (it_1 === null || it_1 === void 0 ? void 0 : it_1.VendorName) || "",
                            NatureofExpense: (_d = (_c = it_1 === null || it_1 === void 0 ? void 0 : it_1.NatureofExpense) === null || _c === void 0 ? void 0 : _c.Id) !== null && _d !== void 0 ? _d : null,
                            InvoiceNumber: (it_1 === null || it_1 === void 0 ? void 0 : it_1.InvoiceNumber) || "",
                            InvoiceDate: toISOInput(it_1 === null || it_1 === void 0 ? void 0 : it_1.InvoiceDate) || "",
                            Basicamount: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Basicamount) || "",
                            GST: (it_1 === null || it_1 === void 0 ? void 0 : it_1.GST) || "",
                            OtherCharges: (it_1 === null || it_1 === void 0 ? void 0 : it_1.OtherCharges) || "",
                            Totalamount: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Totalamount) || "",
                            PaymentRemarks: (it_1 === null || it_1 === void 0 ? void 0 : it_1.PaymentRemarks) || "",
                            ApprovalRemarks: (it_1 === null || it_1 === void 0 ? void 0 : it_1.ApprovalRemarks) || "",
                            GLCode: (it_1 === null || it_1 === void 0 ? void 0 : it_1.GLCode) || "",
                            VoucherNumber: (it_1 === null || it_1 === void 0 ? void 0 : it_1.VoucherNumber) || "",
                            Amount: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Amount) || (it_1 === null || it_1 === void 0 ? void 0 : it_1.Totalamount) || "",
                            attachments: [],
                            // NEW
                            Status: (it_1 === null || it_1 === void 0 ? void 0 : it_1.Status) || "",
                        });
                        return [3 /*break*/, 5];
                    case 3:
                        e_1 = _e.sent();
                        console.error("[NonPoRequest] prefill fetch failed:", e_1);
                        setErr((e_1 === null || e_1 === void 0 ? void 0 : e_1.message) || "Failed to load item");
                        return [3 /*break*/, 5];
                    case 4:
                        setLoading(false);
                        return [7 /*endfinally*/];
                    case 5: return [2 /*return*/];
                }
            });
        }); })();
    }, [sp, numericId]);
    /** ------------ Load existing documents ------------ */
    var toFolderName = function (requestNo) {
        return (requestNo || "NONPO")
            .replace(/[\\#%&*:{?<>|"]/g, "_") // removed /
            .replace(/\//g, "-")
            .trim();
    };
    var getLibraryFolderPathForRequest = function (spx, libTitle, requestNo) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var root, rootUrl, folderName, folderPath;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spx.web.lists.getByTitle(libTitle).rootFolder()];
                case 1:
                    root = _a.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderName = toFolderName(requestNo);
                    folderPath = "".concat(rootUrl, "/").concat(folderName);
                    return [2 /*return*/, { folderPath: folderPath, folderName: folderName }];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var meta, reqNo, libFiles, folderPath, files, _i, _a, f, url, Error_4, e_2;
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!sp || !numericId)
                            return [2 /*return*/];
                        setLoadingExisting(true);
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 8, 9, 10]);
                        return [4 /*yield*/, sp.web.lists.getByTitle(NONPO_LIST_TITLE)
                                .items.getById(numericId)
                                .select("Title")()];
                    case 2:
                        meta = _b.sent();
                        reqNo = (meta === null || meta === void 0 ? void 0 : meta.Title) || "NONPO";
                        libFiles = [];
                        _b.label = 3;
                    case 3:
                        _b.trys.push([3, 6, , 7]);
                        return [4 /*yield*/, getLibraryFolderPathForRequest(sp, ATTACH_LIB, reqNo)];
                    case 4:
                        folderPath = (_b.sent()).folderPath;
                        return [4 /*yield*/, sp.web.getFolderByServerRelativePath(folderPath)
                                .files.select("Name,ServerRelativeUrl,Length,TimeLastModified")()];
                    case 5:
                        files = _b.sent();
                        for (_i = 0, _a = files || []; _i < _a.length; _i++) {
                            f = _a[_i];
                            url = "".concat(SITE_ABS_URL).concat(f.ServerRelativeUrl);
                            libFiles.push({
                                name: f.Name,
                                url: url,
                                sizeBytes: Number(f.Length || 0),
                                lastModified: f.TimeLastModified,
                                source: "Library",
                                serverRelativeUrl: f.ServerRelativeUrl,
                            });
                        }
                        return [3 /*break*/, 7];
                    case 6:
                        Error_4 = _b.sent();
                        alert("Error");
                        return [3 /*break*/, 7];
                    case 7:
                        setExistingFiles(tslib_1.__spreadArray([], libFiles, true));
                        return [3 /*break*/, 10];
                    case 8:
                        e_2 = _b.sent();
                        console.warn("[NONPO] load existing docs failed:", e_2);
                        setExistingFiles([]);
                        return [3 /*break*/, 10];
                    case 9:
                        setLoadingExisting(false);
                        return [7 /*endfinally*/];
                    case 10: return [2 /*return*/];
                }
            });
        }); })();
    }, [sp, numericId]);
    /** ------------ Form helpers ------------ */
    var formikRef = (0, react_1.useRef)(null);
    var updateTotals = function () {
        var f = formikRef.current;
        if (!f)
            return;
        var total = safeNum(f.values.Basicamount) + safeNum(f.values.GST) + safeNum(f.values.OtherCharges);
        f.setFieldValue("Totalamount", total.toString());
        f.setFieldValue("Amount", total.toString());
    };
    var onVendorChange = function (e) {
        var sel = Number(e.target.value) || null;
        var f = formikRef.current;
        if (!f)
            return;
        f.setFieldValue("VendorCode", sel);
        var chosen = vendors.find(function (v) { return v.id === sel; });
        f.setFieldValue("VendorName", (chosen === null || chosen === void 0 ? void 0 : chosen.VendorName) || (chosen === null || chosen === void 0 ? void 0 : chosen.title) || "");
    };
    var onNoeChange = function (e) { var _a; return (_a = formikRef.current) === null || _a === void 0 ? void 0 : _a.setFieldValue("NatureofExpense", Number(e.target.value) || null); };
    var getCurrentUserId = function (spx) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var me, _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, spx.web.currentUser()];
                case 1:
                    me = _b.sent();
                    return [2 /*return*/, me === null || me === void 0 ? void 0 : me.Id];
                case 2:
                    _a = _b.sent();
                    return [2 /*return*/, undefined];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var ensureRequestFolder = function (spx, libTitle, requestNo, mainId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var root, rootUrl, folderName, folderPath, Error_5, folderItem;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spx.web.lists.getByTitle(libTitle).rootFolder()];
                case 1:
                    root = _a.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderName = toFolderName(requestNo);
                    folderPath = "".concat(rootUrl, "/").concat(folderName);
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, spx.web.folders.addUsingPath(folderPath)];
                case 3:
                    _a.sent();
                    return [3 /*break*/, 5];
                case 4:
                    Error_5 = _a.sent();
                    alert("Error");
                    return [3 /*break*/, 5];
                case 5: return [4 /*yield*/, spx.web
                        .getFolderByServerRelativePath(folderPath)
                        .getItem()];
                case 6:
                    folderItem = _a.sent();
                    return [4 /*yield*/, folderItem.update({
                            MainID: mainId.toString()
                        })];
                case 7:
                    _a.sent();
                    return [2 /*return*/, { folderPath: folderPath, folderName: folderName }];
            }
        });
    }); };
    var uploadAttachmentsToLibrary = function (spx_1, libTitle_1, requestNo_1, itemId_1, files_1) {
        var args_1 = [];
        for (var _i = 5; _i < arguments.length; _i++) {
            args_1[_i - 5] = arguments[_i];
        }
        return tslib_1.__awaiter(void 0, tslib_1.__spreadArray([spx_1, libTitle_1, requestNo_1, itemId_1, files_1], args_1, true), void 0, function (spx, libTitle, requestNo, itemId, files, uploaderRole) {
            var folderPath, userId, _a, files_2, file, uploaded, item, e_3;
            if (uploaderRole === void 0) { uploaderRole = "Requester"; }
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!(files === null || files === void 0 ? void 0 : files.length))
                            return [2 /*return*/];
                        return [4 /*yield*/, ensureRequestFolder(spx, libTitle, requestNo, itemId)];
                    case 1:
                        folderPath = (_b.sent()).folderPath;
                        return [4 /*yield*/, getCurrentUserId(spx)];
                    case 2:
                        userId = _b.sent();
                        _a = 0, files_2 = files;
                        _b.label = 3;
                    case 3:
                        if (!(_a < files_2.length)) return [3 /*break*/, 11];
                        file = files_2[_a];
                        return [4 /*yield*/, spx.web.getFolderByServerRelativePath(folderPath).files.addChunked(file.name, file, undefined)];
                    case 4:
                        _b.sent();
                        _b.label = 5;
                    case 5:
                        _b.trys.push([5, 9, , 10]);
                        return [4 /*yield*/, spx.web.getFileByServerRelativePath("".concat(folderPath, "/").concat(file.name))];
                    case 6:
                        uploaded = _b.sent();
                        return [4 /*yield*/, uploaded.getItem()];
                    case 7:
                        item = _b.sent();
                        return [4 /*yield*/, item.update({
                                RequestNo: requestNo,
                                NonPOItemId: itemId,
                                MainID: itemId.toString(),
                                DocUploadedByRole: uploaderRole,
                            })];
                    case 8:
                        _b.sent();
                        return [3 /*break*/, 10];
                    case 9:
                        e_3 = _b.sent();
                        console.warn("[NonPO] file metadata update skipped:", e_3);
                        return [3 /*break*/, 10];
                    case 10:
                        _a++;
                        return [3 /*break*/, 3];
                    case 11: return [2 /*return*/];
                }
            });
        });
    };
    var blockMinusAndAlpha = function (e) {
        var badKeys = ["-", "e", "E", "+"];
        if (badKeys.includes(e.key)) {
            e.preventDefault();
        }
    };
    var onAmountPaste = function (e) {
        var _a, _b;
        var txt = e.clipboardData.getData("text");
        if (!txt)
            return;
        var trimmed = txt.trim();
        if (trimmed === "-" || /^-/.test(trimmed)) {
            e.preventDefault();
            alert("Minus ( - ) not allowed. Please enter a non-negative amount.");
            return;
        }
        var cleaned = trimmed.replace(/[^\d.]/g, "");
        if (cleaned !== trimmed) {
            e.preventDefault();
            var input = e.target;
            var start = (_a = input.selectionStart) !== null && _a !== void 0 ? _a : input.value.length;
            var end = (_b = input.selectionEnd) !== null && _b !== void 0 ? _b : input.value.length;
            var old = input.value;
            var next = old.slice(0, start) + cleaned + old.slice(end);
            input.value = next;
            input.dispatchEvent(new Event("input", { bubbles: true }));
            var newCaret = start + cleaned.length;
            input.setSelectionRange(newCaret, newCaret);
        }
    };
    var recalcTotal = function (vals, overrides) {
        var _a, _b, _c;
        var basic = safeNum(((_a = overrides === null || overrides === void 0 ? void 0 : overrides.Basicamount) !== null && _a !== void 0 ? _a : vals.Basicamount));
        var gst = safeNum(((_b = overrides === null || overrides === void 0 ? void 0 : overrides.GST) !== null && _b !== void 0 ? _b : vals.GST));
        var other = safeNum(((_c = overrides === null || overrides === void 0 ? void 0 : overrides.OtherCharges) !== null && _c !== void 0 ? _c : vals.OtherCharges));
        return String(basic + gst + other);
    };
    var handleAmountChange = function (name) {
        return function (e) {
            var _a, _b;
            var _c;
            var f = formikRef.current;
            if (!f)
                return;
            var raw = ((_c = e.target.value) !== null && _c !== void 0 ? _c : "").toString().trim();
            if (raw === "-" || /^-/.test(raw)) {
                alert("Minus ( - ) not allowed . Please enter a non-negative amount.");
                f.setFieldValue(name, "", false);
                var nextTotal_1 = recalcTotal(f.values, (_a = {}, _a[name] = "", _a));
                f.setFieldValue("Totalamount", nextTotal_1, false);
                f.setFieldValue("Amount", nextTotal_1, false);
                return;
            }
            var cleaned = raw.replace(/[^\d.]/g, "");
            var parts = cleaned.split(".");
            var normalized = parts.length > 2 ? "".concat(parts[0], ".").concat(parts.slice(1).join("")) : cleaned;
            f.setFieldValue(name, normalized, false);
            var nextTotal = recalcTotal(f.values, (_b = {}, _b[name] = normalized, _b));
            f.setFieldValue("Totalamount", nextTotal, false);
            f.setFieldValue("Amount", nextTotal, false);
        };
    };
    var blockNonDigitForInvoice = function (e) {
        var badKeys = ["-", "e", "E", "+", "."];
        if (badKeys.includes(e.key)) {
            e.preventDefault();
        }
    };
    var onInvoicePaste = function (e) {
        var _a, _b;
        var txt = e.clipboardData.getData("text");
        if (!txt)
            return;
        var trimmed = txt.trim();
        if (trimmed === "-" || /^-/.test(trimmed)) {
            e.preventDefault();
            alert("Invoice No. me minus ( - ) not allowed . Only positive values are allowed.");
            return;
        }
        var cleaned = trimmed.replace(/\D/g, "");
        if (cleaned !== trimmed) {
            e.preventDefault();
            var input = e.target;
            var start = (_a = input.selectionStart) !== null && _a !== void 0 ? _a : input.value.length;
            var end = (_b = input.selectionEnd) !== null && _b !== void 0 ? _b : input.value.length;
            var next = input.value.slice(0, start) + cleaned + input.value.slice(end);
            input.value = next;
            input.dispatchEvent(new Event("input", { bubbles: true }));
            var newCaret = start + cleaned.length;
            input.setSelectionRange(newCaret, newCaret);
        }
    };
    var handleInvoiceChange = function (e) {
        var _a;
        var f = formikRef.current;
        if (!f)
            return;
        var val = ((_a = e.target.value) !== null && _a !== void 0 ? _a : "").toString().trim();
        if (val === "-" || /^-/.test(val)) {
            alert("Invoice No. no minus ( - ) not allowed .only positive values are allowed.");
            f.setFieldValue("InvoiceNumber", "");
            return;
        }
        var digitsOnly = val.replace(/\D/g, "");
        f.setFieldValue("InvoiceNumber", digitsOnly);
    };
    var ALLOWED_TYPES = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "image/png",
        "image/jpeg"
    ];
    var onAttachPick = function (files) {
        var f = formikRef.current;
        if (!f || !files)
            return;
        var tooLarge = [];
        var invalidType = [];
        var valid = [];
        Array.from(files).forEach(function (file) {
            // ✅ 1. Size check
            if (file.size > MAX_FILE_SIZE) {
                tooLarge.push("".concat(file.name, " (").concat((file.size / 1048576).toFixed(2), " MB)"));
                return;
            }
            // ✅ 2. Type check (ADD HERE 👇)
            if (!ALLOWED_TYPES.includes(file.type) && !hasValidExtension(file.name)) {
                invalidType.push(file.name);
                return;
            }
            // ✅ Valid file
            valid.push(file);
        });
        if (tooLarge.length) {
            alert("File size must be \u2264 ".concat(MAX_FILE_SIZE_MB, " MB:\n") + tooLarge.join("\n"));
        }
        if (invalidType.length) {
            alert("Only PDF, Word, Excel, Image files allowed:\n" + invalidType.join("\n"));
        }
        f.setFieldValue("attachments", tslib_1.__spreadArray(tslib_1.__spreadArray([], (f.values.attachments || []), true), valid, true));
    };
    var onAttachPick2 = function (files) {
        var f = formikRef.current;
        if (!f || !files)
            return;
        var tooLarge = [];
        var invalidType = [];
        var valid = [];
        Array.from(files).forEach(function (file) {
            // ✅ Size check (25 MB)
            if (file.size > MAX_FILE_SIZE) {
                tooLarge.push("".concat(file.name, " (").concat((file.size / 1048576).toFixed(2), " MB)"));
                return;
            }
            // ✅ Type check
            if (!ALLOWED_TYPES.includes(file.type)) {
                invalidType.push(file.name);
                return;
            }
            valid.push(file);
        });
        if (tooLarge.length) {
            alert("File size must be \u2264 ".concat(MAX_FILE_SIZE_MB, " MB:\n") + tooLarge.join("\n"));
        }
        if (invalidType.length) {
            alert("Only PDF, Word, Excel, Image files allowed:\n" + invalidType.join("\n"));
        }
        f.setFieldValue("attachments", tslib_1.__spreadArray(tslib_1.__spreadArray([], (f.values.attachments || []), true), valid, true));
    };
    var ALLOWED_EXT = [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".png", ".jpg", ".jpeg"];
    var hasValidExtension = function (fileName) {
        return ALLOWED_EXT.some(function (ext) { return fileName.toLowerCase().endsWith(ext); });
    };
    var onAttachPick1 = function (files) {
        var f = formikRef.current;
        if (!f || !files)
            return;
        var tooLarge = [];
        var valid = [];
        Array.from(files).forEach(function (file) {
            if (file.size > MAX_FILE_SIZE)
                tooLarge.push("".concat(file.name, " (").concat((file.size / 1048576).toFixed(2), " MB)"));
            else
                valid.push(file);
        });
        if (tooLarge.length)
            alert("File size must be \u2264 ".concat(MAX_FILE_SIZE_MB, " MB:\n") + tooLarge.join("\n"));
        f.setFieldValue("attachments", tslib_1.__spreadArray(tslib_1.__spreadArray([], (f.values.attachments || []), true), valid, true));
    };
    var removeAttachmentAt = function (idx) {
        var f = formikRef.current;
        if (!f)
            return;
        var next = tslib_1.__spreadArray([], f.values.attachments, true);
        next.splice(idx, 1);
        f.setFieldValue("attachments", next);
    };
    /** ------------ Validation  ------------ */
    var validate = function (v) {
        var _a, _b;
        if (!isEdit)
            return {};
        var e = {};
        if (!v.VendorCode)
            e.VendorCode = "Vendor Code is required";
        if (NOE_MASTER && noeOptions.length > 0 && !v.NatureofExpense)
            e.NatureofExpense = "Nature of Expense is required";
        if (!((_a = v.InvoiceNumber) === null || _a === void 0 ? void 0 : _a.trim()))
            e.InvoiceNumber = "Invoice Number is required";
        if (!((_b = v.Basicamount) === null || _b === void 0 ? void 0 : _b.trim()))
            e.Basicamount = "Basic Amount is required";
        if (!v.InvoiceDate)
            e.InvoiceDate = "Invoice Date is required";
        var isMinus = function (s) {
            var t = (s !== null && s !== void 0 ? s : "").trim();
            return t === "-" || /^-/.test(t);
        };
        if (isMinus(v.Basicamount))
            e.Basicamount = "Minus not allowed";
        if (isMinus(v.GST))
            e.GST = "Minus not allowed";
        if (isMinus(v.OtherCharges))
            e.OtherCharges = "Minus not allowed";
        return e;
    };
    /** ------------ Create NEW item ------------ */
    var createNew = function (values) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var list, rmUser, hodUser, rmEmail, hodEmail, Error_6, Error_7, approvalList, _a, _b, matrixRows, workflowHistory, payload, addRes, itemId, found, reqDt, fy, prefix, getLastSeqForFY, MAX_RETRIES, setOk, i, nextSeq, newTitle, e_4, msg, lastSeq, att, _i, _c, file;
        var _d;
        var _e, _f, _g;
        return tslib_1.__generator(this, function (_h) {
            switch (_h.label) {
                case 0:
                    list = sp.web.lists.getByTitle(NONPO_LIST_TITLE);
                    rmUser = null;
                    hodUser = null;
                    rmEmail = reqDefaults.RMEmail || "";
                    hodEmail = reqDefaults.HODEmail || "";
                    _h.label = 1;
                case 1:
                    _h.trys.push([1, 4, , 5]);
                    if (!rmEmail) return [3 /*break*/, 3];
                    return [4 /*yield*/, sp.web.siteUsers.getByEmail(rmEmail)()];
                case 2:
                    rmUser = _h.sent();
                    _h.label = 3;
                case 3: return [3 /*break*/, 5];
                case 4:
                    Error_6 = _h.sent();
                    alert("Error");
                    return [3 /*break*/, 5];
                case 5:
                    _h.trys.push([5, 8, , 9]);
                    if (!hodEmail) return [3 /*break*/, 7];
                    return [4 /*yield*/, sp.web.siteUsers.getByEmail(hodEmail)()];
                case 6:
                    hodUser = _h.sent();
                    _h.label = 7;
                case 7: return [3 /*break*/, 9];
                case 8:
                    Error_7 = _h.sent();
                    alert("Error");
                    return [3 /*break*/, 9];
                case 9:
                    approvalList = [];
                    // Initiator
                    _b = (_a = approvalList).push;
                    _d = {
                        Role: "Initiator",
                        User: values.EmployeeName
                    };
                    return [4 /*yield*/, getCurrentUserId(sp)];
                case 10:
                    // Initiator
                    _b.apply(_a, [(_d.UserID = _h.sent(),
                            _d.UserEmail = values.Email,
                            _d)]);
                    //  RM
                    approvalList.push({
                        Role: "RM",
                        User: reqDefaults.RM,
                        UserID: (rmUser === null || rmUser === void 0 ? void 0 : rmUser.Id) || null,
                        UserEmail: reqDefaults.RMEmail,
                        PendingText: "Pending At RM"
                    });
                    //  HOD
                    approvalList.push({
                        Role: "HOD",
                        User: reqDefaults.HOD,
                        UserID: (hodUser === null || hodUser === void 0 ? void 0 : hodUser.Id) || null,
                        UserEmail: reqDefaults.HODEmail,
                        PendingText: "Pending At HOD"
                    });
                    return [4 /*yield*/, loadApprovalRoles(sp)];
                case 11:
                    matrixRows = _h.sent();
                    matrixRows.forEach(function (m) { return approvalList.push(m); });
                    workflowHistory = [
                        {
                            CurrentApprover: values.EmployeeName,
                            ActionTaken: "Request submitted",
                            Comment: values.PaymentRemarks,
                            Date: new Date().toISOString(),
                            CurrentStatus: "Submitted to RM",
                        }
                    ];
                    payload = {
                        Title: "TMP-".concat(Date.now(), "-").concat(Math.random().toString(36).slice(2, 8)),
                        RequestDate: values.RequestDate ? new Date(values.RequestDate) : null,
                        EmployeeCode: values.EmployeeCode || "",
                        EmployeeName: values.EmployeeName || "",
                        Email: values.Email || "",
                        ContactNo: values.ContactNo || "",
                        Division: values.Division || "",
                        Department: values.Department || "",
                        Location: values.Location || "",
                        RM: values.RM || "",
                        HOD: values.HOD || "",
                        EmployeeStatus: values.EmployeeStatus || "",
                        VendorCodeId: values.VendorCode,
                        VendorName: values.VendorName || "",
                        NatureofExpenseId: values.NatureofExpense,
                        InvoiceNumber: values.InvoiceNumber || "",
                        InvoiceDate: values.InvoiceDate ? new Date(values.InvoiceDate) : null,
                        Basicamount: (values.Basicamount || "").toString(),
                        GST: (values.GST || "").toString(),
                        OtherCharges: (values.OtherCharges || "").toString(),
                        Totalamount: (values.Totalamount || "").toString(),
                        PaymentRemarks: values.PaymentRemarks || "",
                        ApprovalRemarks: values.ApprovalRemarks || "",
                        GLCode: values.GLCode || "",
                        VoucherNumber: values.VoucherNumber || "",
                        //   Amount: (values.Amount || "").toString(),
                        //  FIELDS ON SUBMIT
                        PendingAt: "Pending At RM",
                        ApproverStatus: "Pending",
                        Stage: 1,
                        Status: "Pending for Approval",
                        CurrentApproverId: (rmUser === null || rmUser === void 0 ? void 0 : rmUser.Id) || null,
                        ApprovalMatrix: JSON.stringify(approvalList),
                        WorkflowHistory: JSON.stringify(workflowHistory),
                    };
                    return [4 /*yield*/, list.items.add(payload)];
                case 12:
                    addRes = _h.sent();
                    itemId = ((_e = addRes === null || addRes === void 0 ? void 0 : addRes.data) === null || _e === void 0 ? void 0 : _e.Id) || ((_f = addRes === null || addRes === void 0 ? void 0 : addRes.data) === null || _f === void 0 ? void 0 : _f.ID);
                    if (!!itemId) return [3 /*break*/, 14];
                    return [4 /*yield*/, list.items.select("Id", "Title").filter("Title eq '".concat(payload.Title.replace(/'/g, "''"), "'")).top(1)()];
                case 13:
                    found = _h.sent();
                    if (found === null || found === void 0 ? void 0 : found.length)
                        itemId = found[0].Id;
                    _h.label = 14;
                case 14:
                    if (!itemId)
                        throw new Error("Item not created (no Id returned).");
                    reqDt = values.RequestDate ? new Date(values.RequestDate) : new Date();
                    fy = fyFromDate(reqDt);
                    prefix = "NON PO/".concat(fy, "/");
                    getLastSeqForFY = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                        var rows, maxSeq, _i, _a, r;
                        return tslib_1.__generator(this, function (_b) {
                            switch (_b.label) {
                                case 0: return [4 /*yield*/, list.items
                                        .select("Id", "Title")
                                        .filter("startswith(Title, '".concat(prefix.replace(/'/g, "''"), "')"))
                                        .orderBy("Id", false)
                                        .top(5)()];
                                case 1:
                                    rows = _b.sent();
                                    maxSeq = 0;
                                    for (_i = 0, _a = rows || []; _i < _a.length; _i++) {
                                        r = _a[_i];
                                        maxSeq = Math.max(maxSeq, tryParseLastNumber(r.Title || ""));
                                    }
                                    return [2 /*return*/, maxSeq];
                            }
                        });
                    }); };
                    MAX_RETRIES = 6;
                    setOk = false;
                    i = 0;
                    _h.label = 15;
                case 15:
                    if (!(i < MAX_RETRIES)) return [3 /*break*/, 24];
                    return [4 /*yield*/, getLastSeqForFY()];
                case 16:
                    nextSeq = (_h.sent()) + 1;
                    newTitle = buildRequestId(fy, nextSeq);
                    _h.label = 17;
                case 17:
                    _h.trys.push([17, 19, , 23]);
                    return [4 /*yield*/, list.items.getById(itemId).update({ Title: newTitle })];
                case 18:
                    _h.sent();
                    setOk = true;
                    return [3 /*break*/, 24];
                case 19:
                    e_4 = _h.sent();
                    msg = ((e_4 === null || e_4 === void 0 ? void 0 : e_4.message) || "").toLowerCase();
                    if (!((e_4 === null || e_4 === void 0 ? void 0 : e_4.status) === 409 || msg.includes("unique") || msg.includes("duplicate") || msg.includes("exists"))) return [3 /*break*/, 21];
                    return [4 /*yield*/, new Promise(function (r) { return setTimeout(r, 120 + Math.random() * 160); })];
                case 20:
                    _h.sent();
                    return [3 /*break*/, 23];
                case 21: throw e_4;
                case 22: return [3 /*break*/, 23];
                case 23:
                    i++;
                    return [3 /*break*/, 15];
                case 24:
                    if (!!setOk) return [3 /*break*/, 27];
                    return [4 /*yield*/, getLastSeqForFY()];
                case 25:
                    lastSeq = _h.sent();
                    return [4 /*yield*/, list.items.getById(itemId).update({ Title: buildRequestId(fy, lastSeq + 1) })];
                case 26:
                    _h.sent();
                    _h.label = 27;
                case 27:
                    if (!((_g = values.attachments) === null || _g === void 0 ? void 0 : _g.length)) return [3 /*break*/, 31];
                    att = list.items.getById(itemId).attachmentFiles;
                    _i = 0, _c = values.attachments;
                    _h.label = 28;
                case 28:
                    if (!(_i < _c.length)) return [3 /*break*/, 31];
                    file = _c[_i];
                    return [4 /*yield*/, att.add(file.name, file)];
                case 29:
                    _h.sent();
                    _h.label = 30;
                case 30:
                    _i++;
                    return [3 /*break*/, 28];
                case 31: return [2 /*return*/, itemId];
            }
        });
    }); };
    /** ------------ Submit (create or update) ------------ */
    var onSubmit = function (values) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var itemId, reqNoFinal, meta, Error_8, payload, reqNo, meta, Error_9, err_1, msg, body, parsed;
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return tslib_1.__generator(this, function (_j) {
            switch (_j.label) {
                case 0:
                    if (!sp) {
                        alert("SharePoint context not ready.");
                        return [2 /*return*/];
                    }
                    _j.label = 1;
                case 1:
                    _j.trys.push([1, 17, 18, 19]);
                    setLoading(true);
                    if (!isNew) return [3 /*break*/, 8];
                    return [4 /*yield*/, createNew(values)];
                case 2:
                    itemId = _j.sent();
                    alert("NON-PO Request created successfully.");
                    reqNoFinal = "NONPO";
                    _j.label = 3;
                case 3:
                    _j.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(NONPO_LIST_TITLE)
                            .items.getById(itemId).select("Title")()];
                case 4:
                    meta = _j.sent();
                    reqNoFinal = (meta === null || meta === void 0 ? void 0 : meta.Title) || reqNoFinal;
                    return [3 /*break*/, 6];
                case 5:
                    Error_8 = _j.sent();
                    alert("Error");
                    return [3 /*break*/, 6];
                case 6: return [4 /*yield*/, uploadAttachmentsToLibrary(sp, ATTACH_LIB, reqNoFinal, itemId, values.attachments || [], "Requester")];
                case 7:
                    _j.sent();
                    navigate("/InitiatorLanding");
                    return [2 /*return*/];
                case 8:
                    if (!numericId) return [3 /*break*/, 16];
                    payload = {
                        VendorCodeId: values.VendorCode,
                        VendorName: values.VendorName || "",
                        NatureofExpenseId: values.NatureofExpense,
                        InvoiceNumber: values.InvoiceNumber || "",
                        InvoiceDate: values.InvoiceDate ? new Date(values.InvoiceDate) : null,
                        Basicamount: (values.Basicamount || "").toString(),
                        GST: (values.GST || "").toString(),
                        OtherCharges: (values.OtherCharges || "").toString(),
                        Totalamount: (values.Totalamount || "").toString(),
                        PaymentRemarks: values.PaymentRemarks || "",
                        ApprovalRemarks: values.ApprovalRemarks || "",
                        GLCode: values.GLCode || "",
                        VoucherNumber: values.VoucherNumber || "",
                        //Amount: (values.Amount || "").toString(),
                    };
                    return [4 /*yield*/, sp.web.lists.getByTitle(NONPO_LIST_TITLE).items.getById(numericId).update(payload)];
                case 9:
                    _j.sent();
                    if (!((_a = values.attachments) === null || _a === void 0 ? void 0 : _a.length)) return [3 /*break*/, 15];
                    reqNo = "NONPO";
                    _j.label = 10;
                case 10:
                    _j.trys.push([10, 12, , 13]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(NONPO_LIST_TITLE)
                            .items.getById(numericId)
                            .select("Title")()];
                case 11:
                    meta = _j.sent();
                    reqNo = (meta === null || meta === void 0 ? void 0 : meta.Title) || reqNo;
                    return [3 /*break*/, 13];
                case 12:
                    Error_9 = _j.sent();
                    alert("Error");
                    return [3 /*break*/, 13];
                case 13: return [4 /*yield*/, uploadAttachmentsToLibrary(sp, ATTACH_LIB, reqNo, numericId, values.attachments)];
                case 14:
                    _j.sent();
                    _j.label = 15;
                case 15:
                    alert("NON-PO Request updated successfully.");
                    return [2 /*return*/];
                case 16: return [3 /*break*/, 19];
                case 17:
                    err_1 = _j.sent();
                    console.error("Submit error:", err_1);
                    msg = (err_1 === null || err_1 === void 0 ? void 0 : err_1.message) || "Failed to submit";
                    try {
                        body = ((_b = err_1 === null || err_1 === void 0 ? void 0 : err_1.data) === null || _b === void 0 ? void 0 : _b.responseBody) || ((_d = (_c = err_1 === null || err_1 === void 0 ? void 0 : err_1.data) === null || _c === void 0 ? void 0 : _c.error) === null || _d === void 0 ? void 0 : _d.message) || (err_1 === null || err_1 === void 0 ? void 0 : err_1.responseBody);
                        if (body) {
                            parsed = typeof body === "string" ? JSON.parse(body) : body;
                            msg = ((_f = (_e = parsed === null || parsed === void 0 ? void 0 : parsed["odata.error"]) === null || _e === void 0 ? void 0 : _e.message) === null || _f === void 0 ? void 0 : _f.value) || ((_h = (_g = parsed === null || parsed === void 0 ? void 0 : parsed.error) === null || _g === void 0 ? void 0 : _g.message) === null || _h === void 0 ? void 0 : _h.value) || msg;
                        }
                    }
                    catch (Error) {
                        alert(msg);
                    }
                    alert(msg);
                    return [3 /*break*/, 19];
                case 18:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 19: return [2 /*return*/];
            }
        });
    }); };
    /** ------------ UI ------------ */
    if (!profileLoaded || !sp) {
        return (React.createElement("div", { className: "p-3" },
            React.createElement("div", { className: "alert alert-secondary mb-0" }, "Loading\u2026")));
    }
    return (React.createElement(formik_1.Formik, { initialValues: initialValues, innerRef: formikRef, enableReinitialize: true, validate: validate, onSubmit: onSubmit }, function (_a) {
        var _b, _c, _d, _e;
        var values = _a.values, errors = _a.errors, touched = _a.touched, validateForm = _a.validateForm, submitForm = _a.submitForm, setTouched = _a.setTouched;
        return (React.createElement(formik_1.Form, null,
            React.createElement("div", { className: 'MainUplodForm', style: { margin: "0px" } },
                React.createElement("div", { className: 'row' },
                    React.createElement("div", { className: 'col-md-12' },
                        React.createElement("div", { className: 'Main-Boxpoup' },
                            React.createElement("div", { className: "bordered" },
                                React.createElement("img", { src: sona_comstarlogo_png_1.default }),
                                React.createElement("h1", null, "NON PO Request ")),
                            React.createElement("div", { className: 'displayWF' }, WorkflowJSX),
                            React.createElement("div", { className: 'borderedbox' },
                                React.createElement("div", { className: "heading1" },
                                    React.createElement("label", null, "Requester Information")),
                                React.createElement("div", { className: 'main-formcontainer' },
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Request Date "),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { type: "date", readOnly: true, name: "RequestDate", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Employee Name "),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "EmployeeName", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Employee Email "),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "Email", className: "fonttext" }))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Contact No"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "ContactNo", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Employee Status"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "EmployeeStatus", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Division"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "Division", className: "fonttext" }))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Location"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "Location", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "RM"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "RM", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "HOD"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "HOD", className: "fonttext" }))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Department"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "Department", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Employee Code"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "EmployeeCode", className: "fonttext" })),
                                        React.createElement("div", { className: 'col-md-4 alignbox' },
                                            React.createElement("label", { className: 'font fontpadd' }, "Status"),
                                            " \u00A0 : \u00A0",
                                            React.createElement(formik_1.Field, { readOnly: true, name: "Status", className: "fonttext" })))),
                                React.createElement("div", { className: "heading1" },
                                    React.createElement("label", null, "Invoice Details")),
                                React.createElement("div", { className: 'main-formcontainer' },
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Vendor Code ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement("select", { className: "form-select ".concat(touched.VendorCode && errors.VendorCode ? "is-invalid" : ""), value: values.VendorCode || "", onChange: onVendorChange, disabled: !isEdit },
                                                React.createElement("option", { value: "" }, "Select vendor"),
                                                vendors.map(function (v) { return (React.createElement("option", { key: v.id, value: v.id }, v.display)); })),
                                            touched.VendorCode && errors.VendorCode && React.createElement("div", { className: "invalid-feedback" }, "".concat(errors.VendorCode))),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Vendor Name ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement(formik_1.Field, { name: "VendorName", className: "form-control readonly", placeholder: "Auto from Vendor" })),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Nature of Expenses ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement("select", { className: "form-select ".concat(touched.NatureofExpense && errors.NatureofExpense ? "is-invalid" : ""), value: values.NatureofExpense || "", onChange: onNoeChange, disabled: !isEdit || !NOE_MASTER || noeOptions.length === 0 },
                                                React.createElement("option", { value: "" }, NOE_MASTER ? "Select nature" : "Master not configured"),
                                                noeOptions.map(function (n) { return (React.createElement("option", { key: n.id, value: n.id }, n.title)); })),
                                            touched.NatureofExpense && errors.NatureofExpense && React.createElement("div", { className: "invalid-feedback" }, "".concat(errors.NatureofExpense)))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Invoice No. ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement(formik_1.Field, { name: "InvoiceNumber", className: "form-control ".concat(touched.InvoiceNumber && errors.InvoiceNumber ? "is-invalid" : ""), placeholder: "Enter invoice number", disabled: !isEdit }),
                                            touched.InvoiceNumber && errors.InvoiceNumber && React.createElement("div", { className: "invalid-feedback" }, "".concat(errors.InvoiceNumber))),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Invoice Date ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement(formik_1.Field, { name: "InvoiceDate", type: "date", className: "form-control ".concat(touched.InvoiceDate && errors.InvoiceDate ? "is-invalid" : ""), disabled: !isEdit }),
                                            touched.InvoiceDate && errors.InvoiceDate && React.createElement("div", { className: "invalid-feedback" }, "".concat(errors.InvoiceDate))),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' },
                                                "Basic Amount ",
                                                React.createElement("span", { className: 'Mantorystar' }, "*")),
                                            React.createElement(formik_1.Field, { name: "Basicamount" }, function () { return (React.createElement("input", { type: "text", className: "form-control ".concat(touched.Basicamount && errors.Basicamount ? "is-invalid" : ""), value: values.Basicamount, onChange: handleAmountChange("Basicamount"), onKeyDown: blockMinusAndAlpha, onPaste: onAmountPaste, placeholder: "0", disabled: !isEdit, inputMode: "decimal" })); }),
                                            touched.Basicamount && errors.Basicamount && (React.createElement("div", { className: "invalid-feedback" }, String(errors.Basicamount))))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' }, "GST Amount "),
                                            React.createElement(formik_1.Field, { name: "GST" }, function () { return (React.createElement("input", { type: "text", className: "form-control ".concat(touched.GST && errors.GST ? "is-invalid" : ""), value: values.GST, onChange: handleAmountChange("GST"), onKeyDown: blockMinusAndAlpha, onPaste: onAmountPaste, placeholder: "0", disabled: !isEdit, inputMode: "decimal" })); }),
                                            touched.GST && errors.GST && (React.createElement("div", { className: "invalid-feedback" }, String(errors.GST)))),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' }, "Other Charges (if any) "),
                                            React.createElement(formik_1.Field, { name: "OtherCharges" }, function () { return (React.createElement("input", { type: "text", className: "form-control ".concat(touched.OtherCharges && errors.OtherCharges ? "is-invalid" : ""), value: values.OtherCharges, onChange: handleAmountChange("OtherCharges"), onKeyDown: blockMinusAndAlpha, onPaste: onAmountPaste, placeholder: "0", disabled: !isEdit, inputMode: "decimal" })); }),
                                            touched.OtherCharges && errors.OtherCharges && (React.createElement("div", { className: "invalid-feedback" }, String(errors.OtherCharges)))),
                                        React.createElement("div", { className: 'col-md-4' },
                                            React.createElement("label", { className: 'font' }, "Total Amount : Basic + GST + Other Charges "),
                                            React.createElement(formik_1.Field, { name: "Totalamount", className: "form-control readonly" }))),
                                    React.createElement("div", { className: 'row mb-20' },
                                        React.createElement("div", { className: 'col-md-6' },
                                            React.createElement("label", { className: 'font' }, "Remarks for NON-PO Expense"),
                                            React.createElement(formik_1.Field, { name: "PaymentRemarks", className: "form-control", type: "text", disabled: !isEdit })))),
                                React.createElement("div", { className: "heading1" },
                                    React.createElement("label", null, "Upload Documents")),
                                React.createElement("div", { className: 'main-formcontainer' },
                                    React.createElement("div", { className: "row mb-20" },
                                        React.createElement("div", { className: "col-md-4" },
                                            React.createElement("label", { className: "font" }, "Attach"),
                                            React.createElement("div", { className: "d-flex align-items-center gap-2" },
                                                React.createElement("label", { className: "btn btn-".concat(isEdit ? "outline-dark" : "secondary", " btn-sm mb-0 ").concat(!isEdit && "disabled") },
                                                    React.createElement("i", { className: "fas fa-paperclip me-2" }),
                                                    "Select files",
                                                    React.createElement("input", { type: "file", multiple: true, disabled: !isEdit, accept: ".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg", style: { display: "none" }, onChange: function (e) { return onAttachPick(e.target.files); } })),
                                                React.createElement("small", { className: "text-".concat(values.attachments.length ? "muted" : "secondary") }, values.attachments.length ? "".concat(values.attachments.length, " file(s) selected") : "Optional")),
                                            values.attachments.length > 0 && (React.createElement("div", { className: "mt-2" },
                                                React.createElement("div", { className: "table-responsive" },
                                                    React.createElement("table", { className: "table table-sm table-bordered mb-0" },
                                                        React.createElement("thead", { className: "table-light" },
                                                            React.createElement("tr", null,
                                                                React.createElement("th", null, "File"),
                                                                React.createElement("th", { style: { width: 140 } }, "Size"),
                                                                React.createElement("th", { style: { width: 90 } }, "Action"))),
                                                        React.createElement("tbody", null, values.attachments.map(function (f, idx) { return (React.createElement("tr", { key: "".concat(f.name, "-").concat(idx) },
                                                            React.createElement("td", null, f.name),
                                                            React.createElement("td", null,
                                                                (f.size / (1024 * 1024)).toFixed(2),
                                                                " MB"),
                                                            React.createElement("td", null,
                                                                React.createElement("button", { type: "button", className: "btn btn-sm btn-outline-danger", onClick: function () { return removeAttachmentAt(idx); }, disabled: !isEdit }, "Remove")))); }))))))))),
                                React.createElement("div", { className: "heading1" },
                                    React.createElement("label", null, "Existing Documents")),
                                React.createElement("div", { className: 'main-formcontainer' },
                                    React.createElement("div", { className: "row mb-20" },
                                        React.createElement("div", { className: "col-md-12" }, loadingExisting ? (React.createElement("div", { className: "text-muted" }, "Loading documents\u2026")) : existingFiles.length === 0 ? (React.createElement("div", { className: "text-secondary" }, "No documents available.")) : (React.createElement("div", { className: "table-responsive" },
                                            React.createElement("table", { className: "table table-sm table-bordered mb-0" },
                                                React.createElement("thead", { className: "table-light" },
                                                    React.createElement("tr", null,
                                                        React.createElement("th", null, "File"),
                                                        React.createElement("th", { style: { width: 140 } }, "Size"),
                                                        React.createElement("th", { style: { width: 120 } }, "Action"))),
                                                React.createElement("tbody", null, existingFiles.map(function (f) { return (React.createElement("tr", { key: "".concat(f.source, "-").concat(f.name) },
                                                    React.createElement("td", null,
                                                        React.createElement("a", { href: f.url, target: "_blank", rel: "noreferrer" }, f.name)),
                                                    React.createElement("td", null, f.sizeBytes ? "".concat((f.sizeBytes / (1024 * 1024)).toFixed(2), " MB") : "-"),
                                                    React.createElement("td", null,
                                                        React.createElement("a", { className: "btn btn-sm btn-outline-primary", href: f.url, target: "_blank", rel: "noreferrer" }, "Download")))); })))))))),
                                React.createElement("div", { className: 'row my-3' },
                                    React.createElement("div", { className: 'col-md-12' },
                                        React.createElement("div", { style: { display: "flex", justifyContent: "center", gap: "5px" } },
                                            isEdit && (
                                            // <a onClick={async () => {
                                            //   const f = formikRef.current; if (!f) return;
                                            //   await Promise.all([
                                            //     f.setFieldTouched("VendorCode", true, true),
                                            //     f.setFieldTouched("NatureofExpense", true, true),
                                            //     f.setFieldTouched("InvoiceNumber", true, true),
                                            //     f.setFieldTouched("InvoiceDate", true, true),
                                            //   ]);
                                            //   const errs = await f.validateForm();
                                            //   if (Object.keys(errs || {}).length > 0) return;
                                            //   f.submitForm();
                                            // }} className="Submit-btn">
                                            //   {isNew ? "Submit" : "Save"}
                                            // </a>
                                            React.createElement("a", { onClick: function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                                                    var f, errs;
                                                    return tslib_1.__generator(this, function (_a) {
                                                        switch (_a.label) {
                                                            case 0:
                                                                f = formikRef.current;
                                                                if (!f || f.isSubmitting)
                                                                    return [2 /*return*/]; // 🚫 रोक दो multiple clicks
                                                                return [4 /*yield*/, Promise.all([
                                                                        f.setFieldTouched("VendorCode", true, true),
                                                                        f.setFieldTouched("NatureofExpense", true, true),
                                                                        f.setFieldTouched("InvoiceNumber", true, true),
                                                                        f.setFieldTouched("InvoiceDate", true, true),
                                                                        f.setFieldTouched("Basicamount", true, true),
                                                                    ])];
                                                            case 1:
                                                                _a.sent();
                                                                return [4 /*yield*/, f.validateForm()];
                                                            case 2:
                                                                errs = _a.sent();
                                                                if (Object.keys(errs || {}).length > 0)
                                                                    return [2 /*return*/];
                                                                return [4 /*yield*/, f.submitForm()];
                                                            case 3:
                                                                _a.sent();
                                                                return [2 /*return*/];
                                                        }
                                                    });
                                                }); }, className: "Submit-btn ".concat(((_b = formikRef.current) === null || _b === void 0 ? void 0 : _b.isSubmitting) ? "disabled" : ""), style: { pointerEvents: ((_c = formikRef.current) === null || _c === void 0 ? void 0 : _c.isSubmitting) ? "none" : "auto", opacity: ((_d = formikRef.current) === null || _d === void 0 ? void 0 : _d.isSubmitting) ? 0.6 : 1 } }, ((_e = formikRef.current) === null || _e === void 0 ? void 0 : _e.isSubmitting) ? "Submitting..." : (isNew ? "Submit" : "Save"))),
                                            React.createElement("a", { onClick: function () { return navigate("/InitiatorLanding"); }, className: "Exit-btn" }, "Exit")))))))))));
    }));
};
exports.default = NonPoRequest;
//# sourceMappingURL=NonPoRequest18may.js.map