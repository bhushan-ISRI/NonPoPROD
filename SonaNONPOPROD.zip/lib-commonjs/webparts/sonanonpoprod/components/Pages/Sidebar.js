"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
require("../Pages/CSS/Sidebar.scss");
require("@fortawesome/fontawesome-free/css/all.min.css");
var SonaPNGLogo_png_1 = tslib_1.__importDefault(require("../../assets/SonaPNGLogo.png"));
// ✅ PnPJS v3 Imports
var sp_1 = require("@pnp/sp");
var spfx_1 = require("@pnp/sp/behaviors/spfx");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/site-users/web");
var Sidebar = function (props) {
    var location = (0, react_router_dom_1.useLocation)();
    var _a = React.useState([]), tabs = _a[0], setTabs = _a[1];
    var _b = React.useState(""), selectedTabUrl = _b[0], setSelectedTabUrl = _b[1];
    var username = props.userDisplayName;
    // ✅ UseRef for SP instance (best practice)
    var spRef = React.useRef(null);
    /** ---------------------------------------------------------
     * Initialize PnPJS
     * --------------------------------------------------------- */
    React.useEffect(function () {
        spRef.current = (0, sp_1.spfi)().using((0, spfx_1.SPFx)(props.context));
    }, [props.context]);
    /** ---------------------------------------------------------
     * Load tabs with access control
     * --------------------------------------------------------- */
    var loadTabsWithAccess = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var userGroups, userGroupIds_1, items, allowedTabs, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    if (!spRef.current)
                        return [2 /*return*/];
                    return [4 /*yield*/, spRef.current.web.currentUser.groups()];
                case 1:
                    userGroups = _a.sent();
                    userGroupIds_1 = userGroups.map(function (g) { return g.Id; });
                    return [4 /*yield*/, spRef.current.web.lists
                            .getByTitle("NONPOTabbing")
                            .items.select("Id", "Title", "SeqNo", "PageUrl", "TabingViewGroup/Id", "TabingViewGroup/Title")
                            .expand("TabingViewGroup")()];
                case 2:
                    items = _a.sent();
                    allowedTabs = items
                        .filter(function (tab) {
                        var groups = tab.TabingViewGroup || [];
                        // ✅ Public tab (no group assigned)
                        if (groups.length === 0)
                            return true;
                        // ✅ User belongs to group
                        return groups.some(function (g) { return userGroupIds_1.includes(g.Id); });
                    })
                        .map(function (tab) { return ({
                        id: tab.Id,
                        title: tab.Title,
                        seq: tab.SeqNo || 999,
                        url: tab.PageUrl ? tab.PageUrl.replace(/\s+/g, "") : "",
                    }); })
                        .sort(function (a, b) { return a.seq - b.seq; });
                    setTabs(allowedTabs);
                    if (allowedTabs.length > 0) {
                        setSelectedTabUrl(allowedTabs[0].url);
                    }
                    return [3 /*break*/, 4];
                case 3:
                    err_1 = _a.sent();
                    console.error("Load Tabs Error:", err_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    /** ---------------------------------------------------------
     * Get active class
     * --------------------------------------------------------- */
    var getActiveClass = function (tabUrl) {
        var currentRoute = window.location.hash.replace("#", "") || "/InitiatorLanding";
        var tabRoute = tabUrl.split("#")[1] || "/InitiatorLanding";
        return currentRoute === tabRoute ? "active" : "";
    };
    /** ---------------------------------------------------------
     * Initial Load
     * --------------------------------------------------------- */
    React.useEffect(function () {
        loadTabsWithAccess();
    }, []);
    return (React.createElement("div", { className: "sidebar" },
        React.createElement("div", { className: "sidehead" },
            React.createElement("div", { className: "logo" },
                React.createElement("img", { src: SonaPNGLogo_png_1.default, width: "25px", height: "25px", alt: "logo" })),
            React.createElement("div", { className: "sidehead-right" }, "SONA COMSTAR")),
        React.createElement("div", { className: "sidehead-user" },
            React.createElement("i", { className: "fas fa-user", style: { marginLeft: "20px", marginRight: "15px" } }),
            username),
        React.createElement("ul", { className: "nav" }, tabs.map(function (tab) { return (React.createElement("li", { className: "nav-item", key: tab.id },
            React.createElement("a", { href: tab.url, className: "nav-link ".concat(getActiveClass(tab.url)), style: { cursor: "pointer" } }, tab.title))); }))));
};
exports.default = Sidebar;
//# sourceMappingURL=Sidebar.js.map