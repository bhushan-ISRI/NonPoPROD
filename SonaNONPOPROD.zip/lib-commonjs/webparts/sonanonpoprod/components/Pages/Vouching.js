"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Vouching = void 0;
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/site-users/web");
var newspcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/newspcrudops"));
require("./CSS/NewRequest.scss");
var react_router_dom_2 = require("react-router-dom");
var Vouching = function (props) {
    var navigate = (0, react_router_dom_2.useNavigate)();
    var id = (0, react_router_dom_1.useParams)().id;
    var _a = react_1.default.useState(), RequestDate = _a[0], setRequestDate = _a[1];
    var _b = react_1.default.useState(), EmployeeName = _b[0], setEmployeeName = _b[1];
    var _c = react_1.default.useState(), Divison = _c[0], setDivison = _c[1];
    var _d = react_1.default.useState(), Email = _d[0], setEmail = _d[1];
    var _e = react_1.default.useState(), HOD = _e[0], setHOD = _e[1];
    var _f = react_1.default.useState(), Department = _f[0], setDepartment = _f[1];
    var _g = react_1.default.useState(), EmpStatus = _g[0], setEmpStatus = _g[1];
    var _h = react_1.default.useState(), Status = _h[0], setStatus = _h[1];
    var _j = (0, react_1.useState)(false), isSubmitting = _j[0], setIsSubmitting = _j[1];
    var _k = react_1.default.useState([]), ApprovalMatrixdata = _k[0], setApprovalMatrix = _k[1];
    var _l = react_1.default.useState([]), WorkflowHistory = _l[0], setWorkflowHistory = _l[1];
    var _m = (0, react_1.useState)(), ItemID = _m[0], setItemID = _m[1];
    var _o = react_1.default.useState(""), Comment = _o[0], setComment = _o[1];
    var _p = react_1.default.useState(""), VoucherNo = _p[0], setVoucherNo = _p[1];
    var _q = react_1.default.useState(""), VoucherDate = _q[0], setVoucherDate = _q[1];
    var _r = react_1.default.useState(null), WorkflowJSX = _r[0], setWorkflowJSX = _r[1];
    var _s = react_1.default.useState(0), Stage = _s[0], setStageData = _s[1];
    var _t = (0, react_1.useState)(), requestNo = _t[0], setrequestNo = _t[1]; // useState<string | undefined>(undefined);
    var _u = react_1.default.useState(), contactNo = _u[0], setcontactNo = _u[1];
    var _v = react_1.default.useState(), CostCenterText = _v[0], setCostCenterText = _v[1];
    var _w = react_1.default.useState(), GLCodeText = _w[0], setGLCodeText = _w[1];
    var _x = react_1.default.useState(), Location = _x[0], setLocation = _x[1];
    var _y = react_1.default.useState(""), RMVal = _y[0], setRMVal = _y[1];
    var _z = react_1.default.useState(""), VendorCode = _z[0], setVendorCode = _z[1];
    var _0 = react_1.default.useState(""), VendorName = _0[0], setVendorName = _0[1];
    var _1 = react_1.default.useState(""), NatureExpense = _1[0], setNatureExpense = _1[1];
    var _2 = react_1.default.useState(""), InvoiceNo = _2[0], setInvoiceNo = _2[1];
    var _3 = react_1.default.useState(""), InvoiceDate = _3[0], setInvoiceDate = _3[1];
    var _4 = react_1.default.useState(""), BasicAmount = _4[0], setBasicAmount = _4[1];
    var _5 = react_1.default.useState(""), PayRemark = _5[0], setPayRemark = _5[1];
    var _6 = react_1.default.useState(""), GSTAmt = _6[0], setGSTAmt = _6[1];
    var _7 = react_1.default.useState(""), otherCharges = _7[0], setotherCharges = _7[1];
    var _8 = react_1.default.useState(""), TotalAmount = _8[0], setTotalAmount = _8[1];
    var _9 = (0, react_1.useState)([]), existingFiles = _9[0], setExistingFiles = _9[1];
    var _10 = (0, react_1.useState)(false), loadingExisting = _10[0], setLoadingExisting = _10[1];
    var _11 = react_1.default.useState(""), VouAmount = _11[0], setVouAmount = _11[1];
    var _12 = react_1.default.useState(null), GLDescription = _12[0], setGLDescription = _12[1];
    var _13 = react_1.default.useState(null), CostCenterDescription = _13[0], setCostCenterDescription = _13[1];
    (0, react_1.useEffect)(function () {
        if (id) {
            loadItem(Number(id));
        }
    }, [id]);
    react_1.default.useEffect(function () {
        if (ApprovalMatrixdata.length > 0) {
            displayWorkflow();
        }
    }, [ApprovalMatrixdata]);
    var displayWorkflow = function (matrix) {
        var data = matrix || ApprovalMatrixdata;
        var wf = [];
        var isActive;
        var notActive = false;
        data.forEach(function (m, i) {
            if (!notActive && Stage !== 99) {
                if (Stage === i) {
                    isActive = 'activeApprover';
                    notActive = true;
                }
                else {
                    isActive = 'beforeactiveApprover';
                }
            }
            else {
                isActive = 'overrideStage';
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu", key: i },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
        });
        setWorkflowJSX(wf);
    };
    var th = {
        textAlign: "left",
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontWeight: 700,
        fontSize: 13,
    };
    var td = {
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontSize: 13,
    };
    var loadItem = function (itemId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, item, parsedApprovalMatrix, parsedWorkflowHistory, error_1;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 3, , 4]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("ID,GLDescription,CostCenterDescription,Title,GLCode,CostCentre,Stage,RequestDate,EmployeeName,ApprovalMatrix,NatureofExpense/ExpenseType,WorkflowHistory,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus,ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,Status,PaymentRemarks,ApprovalRemarks,VendorCode/VendorCode,VendorCode/Id,VendorCode/Title,NatureofExpense/Title,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title")
                            .expand("VendorCode,NatureofExpense,CurrentApprover")()];
                case 1:
                    item = _b.sent();
                    console.log(item);
                    setItemID(itemId);
                    setStageData(item.Stage || "");
                    setrequestNo(item.Title || "");
                    setPayRemark(item.PaymentRemarks || "");
                    setGLCodeText(item.GLCode || "");
                    setCostCenterText(item.CostCentre || "");
                    setStatus(item.Status || "");
                    setRMVal((_a = item.RM) !== null && _a !== void 0 ? _a : "");
                    setLocation(item.Location || "");
                    setRequestDate(item.RequestDate ? new Date(item.RequestDate).toLocaleDateString("en-GB") : "");
                    setEmployeeName(item.EmployeeName || "");
                    setDivison(item.Division || "");
                    setEmail(item.Email || "");
                    setHOD(item.HOD || "");
                    setDepartment(item.Department || "");
                    setEmpStatus(item.EmployeeStatus || "");
                    setcontactNo(item.ContactNo || "");
                    setVendorCode(item.VendorCode.VendorCode || "");
                    setVendorName(item.VendorName || "");
                    setNatureExpense(item.NatureofExpense.ExpenseType || "");
                    setInvoiceNo(item.InvoiceNumber || "");
                    setInvoiceDate(item.InvoiceDate || "");
                    setBasicAmount(item.Basicamount || "");
                    setGSTAmt(item.GST || "");
                    setotherCharges(item.OtherCharges || "");
                    setTotalAmount(item.Totalamount || "");
                    setGLDescription(item.GLDescription || "");
                    setCostCenterDescription(item.CostCenterDescription || "");
                    parsedApprovalMatrix = [];
                    if (item.ApprovalMatrix) {
                        try {
                            parsedApprovalMatrix = JSON.parse(item.ApprovalMatrix);
                        }
                        catch (parseError) {
                            console.error("Error parsing ApprovalMatrix JSON:", parseError);
                        }
                    }
                    setApprovalMatrix(parsedApprovalMatrix);
                    return [4 /*yield*/, loadFinalNonPoFile(item.Title)];
                case 2:
                    _b.sent();
                    parsedWorkflowHistory = [];
                    if (item.WorkflowHistory) {
                        try {
                            parsedWorkflowHistory = JSON.parse(item.WorkflowHistory);
                        }
                        catch (parseError) {
                            console.error("Error parsing WorkflowHistory JSON:", parseError);
                        }
                    }
                    setWorkflowHistory(parsedWorkflowHistory);
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _b.sent();
                    console.error("Error loading item:", error_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var toFolderName = function (requestNo) {
        return (requestNo || "NONPO")
            .replace(/[\\#%&*:{?<>|"]/g, "_") // removed /
            .replace(/\//g, "-")
            .trim();
    };
    var loadFinalNonPoFile = function (requestNo) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, origin_1, absUrl, libTitle, libFiles, root, rootUrl, folderPath, files, _i, _a, f, Error_1, e_1;
        var _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    _e.trys.push([0, 6, 7, 8]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    origin_1 = window.location.origin;
                    absUrl = ((_d = (_c = (_b = props.currentSPContext) === null || _b === void 0 ? void 0 : _b.pageContext) === null || _c === void 0 ? void 0 : _c.web) === null || _d === void 0 ? void 0 : _d.absoluteUrl) || "";
                    // if (!props.currentSPContext || !requestNo) return;
                    setLoadingExisting(true);
                    libTitle = "NonPODoc";
                    libFiles = [];
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(libTitle).rootFolder()];
                case 2:
                    root = _e.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderPath = "".concat(rootUrl, "/").concat(toFolderName(requestNo));
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.select("Name,ServerRelativeUrl,Length,TimeLastModified")()];
                case 3:
                    files = _e.sent();
                    for (_i = 0, _a = files || []; _i < _a.length; _i++) {
                        f = _a[_i];
                        libFiles.push({
                            name: f.Name,
                            url: "".concat(origin_1).concat(f.ServerRelativeUrl),
                            sizeBytes: Number(f.Length || 0),
                            lastModified: f.TimeLastModified,
                            source: "Library",
                            serverRelativeUrl: f.ServerRelativeUrl,
                        });
                    }
                    return [3 /*break*/, 5];
                case 4:
                    Error_1 = _e.sent();
                    alert("Error");
                    return [3 /*break*/, 5];
                case 5:
                    setExistingFiles(tslib_1.__spreadArray([], libFiles, true));
                    return [3 /*break*/, 8];
                case 6:
                    e_1 = _e.sent();
                    console.warn("[APTeamAcceptance] existing docs load failed:", e_1);
                    setExistingFiles([]);
                    return [3 /*break*/, 8];
                case 7:
                    setLoadingExisting(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    var handleClose = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var itemId, spCrudOps, sp, currentUser, formattedDateed, now, formattedDate, workflowHistory, newHistoryEntry, updatedHistory, updateFields, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 4, 5, 6]);
                    itemId = Number(id);
                    if (!VouAmount || isNaN(Number(VouAmount)) || Number(VouAmount) <= 0) {
                        alert("Please enter the Amount");
                        return [2 /*return*/];
                    }
                    if (Number(VouAmount) > Number(TotalAmount)) {
                        alert("Voucher Amount should not be greater than Total Amount");
                        return [2 /*return*/];
                    }
                    if (Number(VouAmount) < Number(TotalAmount)) {
                        alert("Voucher Amount should not be less than Total Amount");
                        return [2 /*return*/];
                    }
                    if (!VoucherNo || VoucherNo.trim() === "") {
                        alert("Please enter a Voucher No");
                        return [2 /*return*/];
                    }
                    if (!VoucherDate || VoucherDate.trim() === "") {
                        alert("Please enter a Voucher Date");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, (0, newspcrudops_1.default)(props)];
                case 1:
                    spCrudOps = _a.sent();
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 2:
                    currentUser = _a.sent();
                    formattedDateed = new Date().toISOString();
                    now = new Date();
                    formattedDate = new Date().toISOString();
                    workflowHistory = tslib_1.__spreadArray([], WorkflowHistory, true);
                    newHistoryEntry = {
                        CurrentApprover: currentUser.Title,
                        ActionTaken: 'Closed',
                        Date: formattedDate,
                        CurrentStatus: 'Closed'
                    };
                    workflowHistory.push(newHistoryEntry);
                    setWorkflowHistory(workflowHistory);
                    updatedHistory = JSON.stringify(workflowHistory);
                    updateFields = {};
                    updateFields = {
                        Status: "Closed",
                        PendingAt: currentUser.Title,
                        ApproverStatus: "Closed",
                        //Stage: updatedIndex + 1,
                        CurrentApproverId: currentUser.Id,
                        WorkflowHistory: updatedHistory,
                        VoucherNumber: VoucherNo,
                        VoucherDate: VoucherDate,
                        Amount: VouAmount
                    };
                    // =====================================
                    // UPDATE SHAREPOINT ITEM
                    // =====================================
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .update(updateFields)];
                case 3:
                    // =====================================
                    // UPDATE SHAREPOINT ITEM
                    // =====================================
                    _a.sent();
                    // =====================================
                    // SUCCESS
                    // =====================================
                    alert("Request Closed");
                    setComment("");
                    navigate('/APTeam');
                    return [3 /*break*/, 6];
                case 4:
                    error_2 = _a.sent();
                    console.error(error_2);
                    alert("Closed request failed");
                    return [3 /*break*/, 6];
                case 5:
                    setIsSubmitting(false);
                    return [7 /*endfinally*/];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    var handleOpenFile = function (url) {
        window.open(url, "_blank", "noopener,noreferrer");
    };
    // ✅ UI must return something
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement("div", { className: "bordered" },
            react_1.default.createElement("a", null,
                react_1.default.createElement("img", { src: sona_comstarlogo_png_1.default })),
            react_1.default.createElement("h1", null, "AP Team - Vouching Details Entry")),
        react_1.default.createElement("div", { className: 'displayWF' }, WorkflowJSX),
        react_1.default.createElement("div", { className: 'borderedbox' },
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Requestor Information")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Request Date : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            RequestDate)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Employee Name  : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmployeeName)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Email : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Email))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Contact No : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            contactNo)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Department : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Department)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Division : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Divison))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Location : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Location)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "RM : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            RMVal)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "HOD : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            HOD))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Employee Status : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            EmpStatus)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Status", className: 'font fontblock' }, "Status : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            Status)))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Invoice Details")),
            react_1.default.createElement("div", { className: 'main-formcontainer' },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Vendor Code : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            VendorCode)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Name", className: 'font fontblock' }, "Vendor Name  : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            VendorName)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Contact No", className: 'font fontblock' }, "Nature of Expense : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            NatureExpense))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Employee Status", className: 'font fontblock' }, "Invoice No : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            InvoiceNo)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Invoice Date : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            InvoiceDate)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Basic Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            BasicAmount))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "GST Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            GSTAmt)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Other Charges (If any): : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            otherCharges)),
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Total Amount : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            TotalAmount))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-4' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Remarks for NON-PO Expense : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            PayRemark)))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Attached Documents")),
            react_1.default.createElement("div", { className: 'main-formcontainer' }, loadingExisting ? (react_1.default.createElement("div", { className: "text-muted" }, "Loading documents\u2026")) : existingFiles.length === 0 ? (react_1.default.createElement("div", { style: { color: "#6b7280" } }, "No documents available.")) : (react_1.default.createElement("div", { style: { overflowX: "auto" } },
                react_1.default.createElement("table", { style: { width: "100%", borderCollapse: "collapse" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", { style: { background: "#f8fafc" } },
                            react_1.default.createElement("th", { style: th }, "File"),
                            react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 140 }) }, "Size"),
                            react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 120 }) }, "Action"))),
                    react_1.default.createElement("tbody", null, existingFiles.map(function (f) { return (react_1.default.createElement("tr", { key: "".concat(f.source, "-").concat(f.name) },
                        react_1.default.createElement("td", { style: td },
                            react_1.default.createElement("a", { onClick: function () { return handleOpenFile(f.url); }, style: { color: "#0a66c2" } }, f.name)),
                        react_1.default.createElement("td", { style: tslib_1.__assign({}, td) }, f.sizeBytes ? "".concat((f.sizeBytes / (1024 * 1024)).toFixed(2), " MB") : "—"),
                        react_1.default.createElement("td", { style: td },
                            react_1.default.createElement("a", { className: "btn btn-sm btn-outline-primary", href: f.url, target: "_blank", rel: "noreferrer" }, "Download")))); })))))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Work Flow History")),
            react_1.default.createElement("div", { className: "main-formcontainer" },
                react_1.default.createElement("div", { className: 'Workflowbox' }, WorkflowHistory && WorkflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "workflow-table", style: { width: '100%', borderCollapse: 'collapse' } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action By"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Taken"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Date"),
                            react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Comment"))),
                    react_1.default.createElement("tbody", null, WorkflowHistory.map(function (h, idx) { return (react_1.default.createElement("tr", { key: idx },
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.CurrentApprover || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.ActionTaken || ''),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Date ? new Date(h.Date).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replace(",", "") : ""),
                        react_1.default.createElement("td", { style: { padding: '8px' } }, h.Comment || ''))); })))) : (react_1.default.createElement("p", null, "No workflow history")))),
            react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                react_1.default.createElement("label", null, "Remark Section")),
            react_1.default.createElement("div", { className: "main-formcontainer" },
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            GLCodeText)),
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "GL Code Description : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            GLDescription))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            CostCenterText)),
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center Description: : \u00A0\u00A0 "),
                        react_1.default.createElement("label", { className: 'fonttext' },
                            "  ",
                            CostCenterDescription))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font' },
                            "Voucher No ",
                            react_1.default.createElement("span", { className: 'Mantorystar' }, "*")),
                        react_1.default.createElement("input", { type: "text", className: 'form-control', value: VoucherNo, onChange: function (e) { return setVoucherNo(e.target.value); } })),
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font' },
                            "Amount ",
                            react_1.default.createElement("span", { className: 'Mantorystar' }, "*")),
                        react_1.default.createElement("input", { type: 'text', className: 'form-control', onKeyPress: function (e) { if (!/[0-9]/.test(e.key)) {
                                e.preventDefault();
                            } }, onChange: function (e) { var value = e.target.value.replace(/[^0-9]/g, ""); setVouAmount(value); } }),
                        react_1.default.createElement("label", { className: 'fonttext' }, "  "))),
                react_1.default.createElement("div", { className: 'row mb-20' },
                    react_1.default.createElement("div", { className: 'col-md-6' },
                        react_1.default.createElement("label", { className: 'font' },
                            "Voucher Date ",
                            react_1.default.createElement("span", { className: 'Mantorystar' }, "*")),
                        react_1.default.createElement("input", { type: "date", value: VoucherDate, className: "form-control", onChange: function (e) { return setVoucherDate(e.target.value); } })))),
            react_1.default.createElement("div", { style: { display: "flex", justifyContent: "center", gap: "5px", margin: "10px 20px" } },
                react_1.default.createElement("button", { className: "submit-btn", onClick: function () { return handleClose(); } }, "Close Request"),
                react_1.default.createElement("button", { className: "reset-btn", onClick: function () { return navigate("/APTeam"); } }, "Exit")))));
};
exports.Vouching = Vouching;
//# sourceMappingURL=Vouching.js.map