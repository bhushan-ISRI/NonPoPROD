"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var react_router_dom_2 = require("react-router-dom");
var spcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/spcrudops"));
var useFullscreenForm_1 = tslib_1.__importDefault(require("../../hook/useFullscreenForm"));
var Pencil_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/Pencil.png"));
var Eye_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/Eye.png"));
var fmtDate = function (d) {
    if (!d)
        return "";
    var dt = new Date(d);
    if (Number.isNaN(dt.getTime()))
        return "";
    var dd = dt.getDate().toString().padStart(2, "0");
    var mm = (dt.getMonth() + 1).toString().padStart(2, "0");
    var yyyy = dt.getFullYear();
    return "".concat(dd, "/").concat(mm, "/").concat(yyyy);
};
var safeNum = function (n) {
    var v = Number((n !== null && n !== void 0 ? n : "").toString().replace(/,/g, "").trim());
    return Number.isFinite(v) ? v : 0;
};
var APTeam = function (_a) {
    var currentSPContext = _a.currentSPContext, _b = _a.listTitle, listTitle = _b === void 0 ? "NonPO" : _b, _c = _a.title, title = _c === void 0 ? "NON PO Acceptance Dashboard" : _c, 
    //onView,
    props = tslib_1.__rest(_a, ["currentSPContext", "listTitle", "title"]);
    (0, useFullscreenForm_1.default)();
    var navigate = (0, react_router_dom_1.useNavigate)();
    var _d = (0, react_1.useState)(""), query = _d[0], setQuery = _d[1];
    var _e = (0, react_1.useState)([]), rows = _e[0], setRows = _e[1];
    var _f = (0, react_1.useState)(false), loading = _f[0], setLoading = _f[1];
    var _g = (0, react_1.useState)(""), error = _g[0], setError = _g[1];
    /** ---------- Pagination (10 per page) ---------- **/
    var PAGE_SIZE = 10;
    var _h = (0, react_1.useState)(1), currentPage = _h[0], setCurrentPage = _h[1];
    (0, react_1.useEffect)(function () {
        var abort = false;
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var spCrudOps, select, expand, orderBy, filter, items, mapped, filteredmapped, e_1;
            var _a;
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 3, 4, 5]);
                        setLoading(true);
                        setError("");
                        return [4 /*yield*/, (0, spcrudops_1.default)(currentSPContext)];
                    case 1:
                        spCrudOps = _b.sent();
                        select = "Id,Title,RequestDate,EmployeeName,VendorCode/VendorCode,VendorCode/Id,VendorName,InvoiceNumber,Totalamount,Amount,Status,VendorCode/Title,CurrentApprover/Id,CurrentApprover/EMail,CurrentApprover/Title";
                        expand = "VendorCode,CurrentApprover";
                        orderBy = { column: "Id", isAscending: false };
                        filter = "Status eq 'Pending for Acceptance'";
                        return [4 /*yield*/, spCrudOps.getRootData(listTitle, select, expand, filter, orderBy, { currentSPContext: currentSPContext })];
                    case 2:
                        items = (_a = (_b.sent())) !== null && _a !== void 0 ? _a : [];
                        if (abort)
                            return [2 /*return*/];
                        mapped = items.map(function (it) {
                            var _a, _b;
                            return ({
                                _spId: it === null || it === void 0 ? void 0 : it.Id,
                                requestNo: (it === null || it === void 0 ? void 0 : it.Title) || "",
                                requestDate: fmtDate(it === null || it === void 0 ? void 0 : it.RequestDate),
                                buyerName: (it === null || it === void 0 ? void 0 : it.EmployeeName) || "",
                                vendorCode: ((_a = it === null || it === void 0 ? void 0 : it.VendorCode) === null || _a === void 0 ? void 0 : _a.VendorCode) || "",
                                vendorName: (it === null || it === void 0 ? void 0 : it.VendorName) || "",
                                invoiceNo: (it === null || it === void 0 ? void 0 : it.InvoiceNumber) || "",
                                CurrentApproverEmail: (_b = it === null || it === void 0 ? void 0 : it.CurrentApprover) === null || _b === void 0 ? void 0 : _b.EMail,
                                amount: (it === null || it === void 0 ? void 0 : it.Totalamount) !== undefined && (it === null || it === void 0 ? void 0 : it.Totalamount) !== null && (it === null || it === void 0 ? void 0 : it.Totalamount) !== ""
                                    ? safeNum(it === null || it === void 0 ? void 0 : it.Totalamount)
                                    : safeNum(it === null || it === void 0 ? void 0 : it.Amount),
                                status: (it === null || it === void 0 ? void 0 : it.Status) || "",
                            });
                        });
                        filteredmapped = mapped.filter(function (m) { return (m.CurrentApproverEmail === props.userEmail); });
                        setRows(filteredmapped);
                        return [3 /*break*/, 5];
                    case 3:
                        e_1 = _b.sent();
                        console.error("[APTeam] fetch error:", e_1);
                        setError((e_1 === null || e_1 === void 0 ? void 0 : e_1.message) || "Failed to load AP Team data");
                        return [3 /*break*/, 5];
                    case 4:
                        if (!abort)
                            setLoading(false);
                        return [7 /*endfinally*/];
                    case 5: return [2 /*return*/];
                }
            });
        }); })();
        return function () { abort = true; };
    }, [listTitle, currentSPContext]);
    /** ---------- Search ---------- **/
    var filtered = (0, react_1.useMemo)(function () {
        var onlyPendingForAcceptance = rows.filter(function (r) { return (r.status || "").trim() === "Pending for Acceptance"; });
        if (!query.trim())
            return onlyPendingForAcceptance;
        var q = query.toLowerCase();
        return onlyPendingForAcceptance.filter(function (row) {
            return [
                row.requestNo,
                row.requestDate,
                row.buyerName,
                row.vendorCode,
                row.vendorName,
                row.invoiceNo,
                String(row.amount),
                row.status || "",
            ]
                .join(" ")
                .toLowerCase()
                .includes(q);
        });
    }, [rows, query]);
    /** ---------- Reset page on data/search change ---------- **/
    (0, react_1.useEffect)(function () {
        setCurrentPage(1);
    }, [rows, query]);
    /** ---------- Pagination derived values ---------- **/
    var totalItems = filtered.length;
    var totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
    var page = Math.min(currentPage, totalPages);
    var startIdx = (page - 1) * PAGE_SIZE;
    var endIdx = Math.min(startIdx + PAGE_SIZE, totalItems);
    var paged = filtered.slice(startIdx, endIdx);
    /**  View / Edit navigate to APTeamAcceptance */
    var handleView = function (row) {
        if (!(row === null || row === void 0 ? void 0 : row._spId)) {
            alert("Item ID missing for this row.");
            return;
        }
        navigate("/APTeamAcceptance?id=".concat(row._spId, "&mode=view"), { state: { from: "/APTeam", fullscreen: true } });
    };
    var handleEdit = function (row) {
        if (!(row === null || row === void 0 ? void 0 : row._spId)) {
            alert("Item ID missing for this row.");
            return;
        }
        navigate("/APTeamAcceptance?id=".concat(row._spId, "&mode=edit"), { state: { from: "/APTeam", fullscreen: true } });
    };
    return (react_1.default.createElement("div", null,
        react_1.default.createElement("div", { className: "header" },
            react_1.default.createElement("div", { className: "left-banner" },
                react_1.default.createElement("div", { className: "logo-text" },
                    react_1.default.createElement("h2", null,
                        " ",
                        title,
                        " ")))),
        react_1.default.createElement("div", { className: 'col-md-12 px-2 d-flex justify-content-between align-items-center flex-wrap', style: { margin: "5px" } },
            react_1.default.createElement("div", null,
                react_1.default.createElement("input", { type: "text", placeholder: "Search", className: "form-control", style: { width: "250px" }, value: query, onChange: function (e) { return setQuery(e.target.value); } }))),
        error && react_1.default.createElement("div", { className: "alert" }, error),
        loading && react_1.default.createElement("div", { className: "alert" }, "Loading..."),
        react_1.default.createElement("main", { className: "Main-Dash mx-2" },
            react_1.default.createElement("div", { className: "overflow-x-auto" },
                react_1.default.createElement("div", { className: "table-vert-scroll" },
                    react_1.default.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                        react_1.default.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "View"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Request No."),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Request Date"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Request Name"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Vendor Name"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Vendor Code "),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Invoice No."),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Amount"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Status"))),
                        react_1.default.createElement("tbody", null, !loading && totalItems === 0 ? (react_1.default.createElement("tr", null,
                            react_1.default.createElement("td", { colSpan: 9, className: "empty" }, "No matching records"))) : (paged.map(function (row) {
                            var _a;
                            return (react_1.default.createElement("tr", { key: (_a = row._spId) !== null && _a !== void 0 ? _a : "".concat(row.requestNo, "-").concat(row.invoiceNo) },
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement(react_router_dom_2.Link, { to: "/APTeamAcceptance/".concat(row._spId) },
                                        react_1.default.createElement("img", { src: Pencil_png_1.default, width: 15 })),
                                    "\u00A0\u00A0",
                                    react_1.default.createElement(react_router_dom_2.Link, { to: "/ViewRequest/".concat(row._spId) },
                                        react_1.default.createElement("img", { src: Eye_png_1.default, width: 15 }))),
                                react_1.default.createElement("td", null, row.requestNo),
                                react_1.default.createElement("td", null, row.requestDate),
                                react_1.default.createElement("td", null, row.buyerName),
                                react_1.default.createElement("td", null, row.vendorName),
                                react_1.default.createElement("td", null, row.vendorCode),
                                react_1.default.createElement("td", null, row.invoiceNo),
                                react_1.default.createElement("td", { className: "num" }, row.amount.toLocaleString("en-IN")),
                                react_1.default.createElement("td", null, "Pending for Acceptance"),
                                " "));
                        }))))))),
        react_1.default.createElement("div", { className: "myApproval-paginationRow", role: "navigation", "aria-label": "Pagination" },
            react_1.default.createElement("div", { className: "myApproval-pageInfo" }, totalItems > 0 ? (react_1.default.createElement(react_1.default.Fragment, null,
                "Showing ",
                react_1.default.createElement("b", null, startIdx + 1),
                "\u2013",
                react_1.default.createElement("b", null, endIdx),
                " of ",
                react_1.default.createElement("b", null, totalItems))) : (react_1.default.createElement(react_1.default.Fragment, null, "Showing 0 of 0"))),
            react_1.default.createElement("div", { className: "myApproval-pagerButtons" },
                react_1.default.createElement("button", { className: "btnPager", onClick: function () { return setCurrentPage(function (p) { return Math.max(1, p - 1); }); }, disabled: page <= 1, "aria-label": "Previous page" }, "\u2190 Prev"),
                react_1.default.createElement("span", { className: "myApproval-pageCurrent" },
                    "Page ",
                    page,
                    " / ",
                    totalPages),
                react_1.default.createElement("button", { className: "btnPager", onClick: function () { return setCurrentPage(function (p) { return Math.min(totalPages, p + 1); }); }, disabled: page >= totalPages, "aria-label": "Next page" }, "Next \u2192"))),
        react_1.default.createElement("style", null, css)));
};
/** ======================= CSS ======================== **/
var css = "\n.myApproval-root{padding:12px}\n.myApproval-titleRow{padding:4px 2px 8px;border-bottom:1px solid #e5e7eb;margin-bottom:8px;display:flex;align-items:center}\n.myApproval-title{margin:0;font-weight:700}\n.myApproval-searchRow{margin:10px 0}\n.myApproval-searchWrap{position:relative;width:260px}\n.myApproval-searchWrap input{width:100%;padding:8px 30px;border:1px solid #e5e7eb;border-radius:8px}\n.myApproval-searchIcon{position:absolute;left:8px;top:6px}\n.myApproval-tableWrap{border:1px solid #e5e7eb;border-radius:10px;overflow:auto}\n.myApproval-grid{width:100%;min-width:900px;border-collapse:separate}\n.myApproval-grid thead th {\n  background: #000 !important;\n  color: #fff !important;\n  font-weight: 700;\n}\n.myApproval-grid tbody td{padding:10px;border-bottom:1px solid #e5e7eb}\n.num{text-align:right}\n.empty{text-align:center;padding:20px}\n.myApproval-paginationRow{display:flex;align-items:center;gap:12px;justify-content:space-between;margin:10px}\n.myApproval-pageInfo{color:#374151}\n.myApproval-pagerButtons{display:flex;align-items:center;gap:10px}\n.btnPager{padding:6px 10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;color:#111827;cursor:pointer}\n.btnPager:disabled{opacity:0.5;cursor:not-allowed}\n.myApproval-pageCurrent{color:#4b5563}\n";
exports.default = APTeam;
//# sourceMappingURL=APTeam.js.map