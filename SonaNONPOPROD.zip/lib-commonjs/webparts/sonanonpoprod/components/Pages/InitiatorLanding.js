"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var spcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/spcrudops"));
var Pencil_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/Pencil.png"));
var Eye_png_1 = tslib_1.__importDefault(require("../../components/Pages/Image/Eye.png"));
require("./CSS/Sidebar.scss");
require("./CSS/Landing.scss");
require("./CSS/NewRequest.scss");
require("./CSS/Sidebar.module.scss");
var react_router_dom_2 = require("react-router-dom");
function resolveCurrentUserId(ctx) {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var legacyId, spfi, SPFx, sp, me, Error_1, loginName, spfi, SPFx, sp, ensured, ensuredId, Error_2;
        var _a, _b, _c, _d, _e;
        return tslib_1.__generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    legacyId = (_b = (_a = ctx === null || ctx === void 0 ? void 0 : ctx.pageContext) === null || _a === void 0 ? void 0 : _a.legacyPageContext) === null || _b === void 0 ? void 0 : _b.userId;
                    if (legacyId)
                        return [2 /*return*/, legacyId];
                    _f.label = 1;
                case 1:
                    _f.trys.push([1, 5, , 6]);
                    return [4 /*yield*/, Promise.resolve().then(function () { return tslib_1.__importStar(require("@pnp/sp")); })];
                case 2:
                    spfi = (_f.sent()).spfi;
                    return [4 /*yield*/, Promise.resolve().then(function () { return tslib_1.__importStar(require("@pnp/sp/behaviors/spfx")); })];
                case 3:
                    SPFx = (_f.sent()).SPFx;
                    sp = spfi().using(SPFx(ctx));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 4:
                    me = _f.sent();
                    if (me === null || me === void 0 ? void 0 : me.Id)
                        return [2 /*return*/, me.Id];
                    return [3 /*break*/, 6];
                case 5:
                    Error_1 = _f.sent();
                    alert("Error");
                    return [3 /*break*/, 6];
                case 6:
                    _f.trys.push([6, 11, , 12]);
                    loginName = (_d = (_c = ctx === null || ctx === void 0 ? void 0 : ctx.pageContext) === null || _c === void 0 ? void 0 : _c.user) === null || _d === void 0 ? void 0 : _d.loginName;
                    if (!loginName) return [3 /*break*/, 10];
                    return [4 /*yield*/, Promise.resolve().then(function () { return tslib_1.__importStar(require("@pnp/sp")); })];
                case 7:
                    spfi = (_f.sent()).spfi;
                    return [4 /*yield*/, Promise.resolve().then(function () { return tslib_1.__importStar(require("@pnp/sp/behaviors/spfx")); })];
                case 8:
                    SPFx = (_f.sent()).SPFx;
                    sp = spfi().using(SPFx(ctx));
                    return [4 /*yield*/, sp.web.ensureUser(loginName)];
                case 9:
                    ensured = _f.sent();
                    ensuredId = (_e = ensured === null || ensured === void 0 ? void 0 : ensured.data) === null || _e === void 0 ? void 0 : _e.Id;
                    if (ensuredId)
                        return [2 /*return*/, ensuredId];
                    _f.label = 10;
                case 10: return [3 /*break*/, 12];
                case 11:
                    Error_2 = _f.sent();
                    alert("Error");
                    return [3 /*break*/, 12];
                case 12: return [2 /*return*/, undefined];
            }
        });
    });
}
var InitiatorLanding = function (_a) {
    var _b = _a.listTitle, listTitle = _b === void 0 ? "NonPO" : _b, onAddNon = _a.onAddNon, onViewRow = _a.onViewRow, _c = _a.title, title = _c === void 0 ? "NON PO Initiator" : _c, props = tslib_1.__rest(_a, ["listTitle", "onAddNon", "onViewRow", "title"]);
    var navigate = (0, react_router_dom_1.useNavigate)();
    var _d = (0, react_1.useState)(""), query = _d[0], setQuery = _d[1];
    var _e = (0, react_1.useState)([]), rows = _e[0], setRows = _e[1];
    var _f = (0, react_1.useState)(false), loading = _f[0], setLoading = _f[1];
    var _g = (0, react_1.useState)(""), error = _g[0], setError = _g[1];
    // ⬇ NEW: Pagination state (fixed 10 per page)
    var PAGE_SIZE = 10;
    var _h = (0, react_1.useState)(1), currentPage = _h[0], setCurrentPage = _h[1];
    var fmtDate = function (d) {
        if (!d)
            return "";
        var dt = new Date(d);
        if (Number.isNaN(dt.getTime()))
            return "";
        var dd = dt.getDate().toString().padStart(2, "0");
        var mm = (dt.getMonth() + 1).toString().padStart(2, "0");
        var yyyy = dt.getFullYear();
        return "".concat(dd, "/").concat(mm, "/").concat(yyyy);
    };
    var safeNum = function (n) {
        var v = Number((n !== null && n !== void 0 ? n : "").toString().replace(/,/g, "").trim());
        return Number.isFinite(v) ? v : 0;
    };
    (0, react_1.useEffect)(function () {
        var abort = false;
        (function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var spCrudOps, userId, select, expand, filter, orderBy, items, mapped, e_1;
            var _a;
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 4, 5, 6]);
                        setLoading(true);
                        setError("");
                        return [4 /*yield*/, (0, spcrudops_1.default)(props.currentSPContext)];
                    case 1:
                        spCrudOps = _b.sent();
                        return [4 /*yield*/, resolveCurrentUserId(props.currentSPContext)];
                    case 2:
                        userId = _b.sent();
                        if (!userId) {
                            throw new Error("User context not found. Hosted workbench (/ _layouts /15 /workbench.aspx).");
                        }
                        select = "Id,Title,RequestDate,VendorName,InvoiceNumber,Totalamount,Amount,Status,VendorCode/VendorCode,VendorCode/Id,VendorCode/Title";
                        expand = "VendorCode";
                        filter = "AuthorId eq ".concat(userId);
                        orderBy = { column: "Id", isAscending: false };
                        return [4 /*yield*/, spCrudOps.getRootData(listTitle, select, expand, filter, orderBy, props)];
                    case 3:
                        items = (_a = (_b.sent())) !== null && _a !== void 0 ? _a : [];
                        if (abort)
                            return [2 /*return*/];
                        mapped = items.map(function (it) {
                            var _a;
                            return ({
                                _spId: it === null || it === void 0 ? void 0 : it.Id,
                                requestNo: (it === null || it === void 0 ? void 0 : it.Title) || "",
                                requestDate: fmtDate(it === null || it === void 0 ? void 0 : it.RequestDate),
                                vendorCode: ((_a = it === null || it === void 0 ? void 0 : it.VendorCode) === null || _a === void 0 ? void 0 : _a.VendorCode) || "",
                                vendorName: (it === null || it === void 0 ? void 0 : it.VendorName) || "",
                                invoiceNo: (it === null || it === void 0 ? void 0 : it.InvoiceNumber) || "",
                                amount: (it === null || it === void 0 ? void 0 : it.Totalamount) !== undefined
                                    ? safeNum(it === null || it === void 0 ? void 0 : it.Totalamount)
                                    : safeNum(it === null || it === void 0 ? void 0 : it.Amount),
                                status: it === null || it === void 0 ? void 0 : it.Status,
                            });
                        });
                        setRows(mapped);
                        return [3 /*break*/, 6];
                    case 4:
                        e_1 = _b.sent();
                        console.error("NonPO fetch error:", e_1);
                        setError((e_1 === null || e_1 === void 0 ? void 0 : e_1.message) || "Failed to load data");
                        return [3 /*break*/, 6];
                    case 5:
                        if (!abort)
                            setLoading(false);
                        return [7 /*endfinally*/];
                    case 6: return [2 /*return*/];
                }
            });
        }); })();
        return function () {
            abort = true;
        };
    }, [listTitle]);
    var filtered = (0, react_1.useMemo)(function () {
        if (!query.trim())
            return rows;
        var q = query.toLowerCase();
        return rows.filter(function (r) {
            return [
                r.requestNo,
                r.requestDate,
                r.vendorCode,
                r.vendorName,
                r.invoiceNo,
                String(r.amount),
                r.status,
            ]
                .join(" ")
                .toLowerCase()
                .includes(q);
        });
    }, [rows, query]);
    (0, react_1.useEffect)(function () {
        setCurrentPage(1);
    }, [query, rows]);
    var totalItems = filtered.length;
    var totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
    var page = Math.min(currentPage, totalPages);
    var startIdx = (page - 1) * PAGE_SIZE;
    var endIdx = Math.min(startIdx + PAGE_SIZE, totalItems);
    var paged = filtered.slice(startIdx, endIdx);
    var handleAddNon = function () {
        if (onAddNon)
            onAddNon();
        else
            navigate("/NonPoRequest?mode=new"); // create mode
    };
    var handleView = function (row) {
        if (onViewRow)
            return onViewRow(row);
        if (!(row === null || row === void 0 ? void 0 : row._spId))
            return;
        navigate("/NonPoRequest?id=".concat(row._spId, "&mode=view"), { state: { from: "/InitiatorLanding", fullscreen: true } });
    };
    var handleEdit = function (row) {
        if (!(row === null || row === void 0 ? void 0 : row._spId))
            return;
        navigate("/NonPoRequest?id=".concat(row._spId, "&mode=edit"), { state: { from: "/InitiatorLanding", fullscreen: true } });
    };
    //   Pager handlers
    var goPrev = function () { return setCurrentPage(function (p) { return Math.max(1, p - 1); }); };
    var goNext = function () { return setCurrentPage(function (p) { return Math.min(totalPages, p + 1); }); };
    return (react_1.default.createElement("div", null,
        react_1.default.createElement("div", { className: "header" },
            react_1.default.createElement("div", { className: "left-banner" },
                react_1.default.createElement("div", { className: "logo-text" },
                    react_1.default.createElement("h2", null,
                        " ",
                        title,
                        " ")))),
        react_1.default.createElement("div", { className: 'col-md-12 px-2 d-flex justify-content-between align-items-center flex-wrap', style: { margin: "5px" } },
            react_1.default.createElement("div", null,
                react_1.default.createElement("input", { type: "text", placeholder: "Search", className: "form-control", style: { width: "250px" }, value: query, onChange: function (e) { return setQuery(e.target.value); } })),
            react_1.default.createElement("div", { className: 'Dashbaordcreatebutton', style: { paddingRight: "10px" } },
                react_1.default.createElement("a", { className: 'create-button', onClick: handleAddNon }, "Add Request"))),
        error && react_1.default.createElement("div", { className: "alert" }, error),
        loading && react_1.default.createElement("div", { className: "alert" }, "Loading..."),
        react_1.default.createElement("main", { className: "Main-Dash mx-2" },
            react_1.default.createElement("div", { className: "overflow-x-auto" },
                react_1.default.createElement("div", { className: "table-vert-scroll" },
                    react_1.default.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                        react_1.default.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "View"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Request No."),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Request Date"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Vendor Code"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Vendor Name "),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Invoice No."),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Amount"),
                                react_1.default.createElement("th", { className: "px-4 py-2" }, "Status"))),
                        react_1.default.createElement("tbody", null, !loading && totalItems === 0 ? (react_1.default.createElement("tr", null,
                            react_1.default.createElement("td", { colSpan: 8, className: "empty" }, "No records found"))) : (paged.map(function (row) {
                            var _a;
                            return (react_1.default.createElement("tr", { key: (_a = row._spId) !== null && _a !== void 0 ? _a : "".concat(row.requestNo, "-").concat(row.invoiceNo) },
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("div", { style: { display: "flex", gap: 8, border: "0px solid #f8f3f3" } },
                                        react_1.default.createElement(react_router_dom_2.Link, { to: "/ViewRequest/".concat(row._spId) },
                                            react_1.default.createElement("img", { src: Eye_png_1.default, width: 15 })),
                                        row.status === "Send Back" && (react_1.default.createElement(react_router_dom_2.Link, { to: "/ViewRequestSendBack/".concat(row._spId) },
                                            react_1.default.createElement("img", { src: Pencil_png_1.default, width: 15 }))))),
                                react_1.default.createElement("td", null, row.requestNo),
                                react_1.default.createElement("td", null, row.requestDate),
                                react_1.default.createElement("td", null, row.vendorCode),
                                react_1.default.createElement("td", null, row.vendorName),
                                react_1.default.createElement("td", null, row.invoiceNo),
                                react_1.default.createElement("td", { className: "num" }, row.amount.toLocaleString("en-IN")),
                                react_1.default.createElement("td", null, row.status)));
                        }))))))),
        react_1.default.createElement("div", { className: "myApproval-paginationRow", role: "navigation", "aria-label": "Pagination" },
            react_1.default.createElement("div", { className: "myApproval-pageInfo" }, totalItems > 0 ? (react_1.default.createElement(react_1.default.Fragment, null,
                "Showing ",
                react_1.default.createElement("b", null, startIdx + 1),
                "\u2013",
                react_1.default.createElement("b", null, endIdx),
                " of ",
                react_1.default.createElement("b", null, totalItems))) : (react_1.default.createElement(react_1.default.Fragment, null, "Showing 0 of 0"))),
            react_1.default.createElement("div", { className: "myApproval-pagerButtons" },
                react_1.default.createElement("button", { className: "btnPager", onClick: goPrev, disabled: page <= 1, "aria-label": "Previous page" }, "\u2190 Prev"),
                react_1.default.createElement("span", { className: "myApproval-pageCurrent" },
                    "Page ",
                    page,
                    " / ",
                    totalPages),
                react_1.default.createElement("button", { className: "btnPager", onClick: goNext, disabled: page >= totalPages, "aria-label": "Next page" }, "Next \u2192"))),
        react_1.default.createElement("style", null, css)));
};
/** ======================= CSS  ======================== **/
var css = "\n        .myApproval-root{padding:12px}\n        .myApproval-titleRow{padding:4px 2px 8px;border-bottom:1px solid #e5e7eb;margin-bottom:8px;display:flex;align-items:center;gap:10px}\n        .myApproval-title{margin:0;font-weight:700}\n        .myApproval-searchRow{margin:10px 0}\n        .myApproval-searchWrap{position:relative;width:260px}\n        .myApproval-searchWrap input{width:100%;padding:8px 30px;border:1px solid #e5e7eb;border-radius:8px}\n        .myApproval-searchIcon{position:absolute;left:8px;top:6px}\n        .myApproval-tableWrap{border:1px solid #e5e7eb;border-radius:10px;overflow:auto}\n        .myApproval-grid{width:100%;min-width:900px;border-collapse:separate}\n        .myApproval-grid thead th {\n          background: #000 !important;\n        color: #fff !important;\n        font-weight: 700;\n        padding:9px;\n}\n// .myApproval-grid thead th{background:#f8fafc;padding:10px;font-weight:700;position:sticky;top:0}\n        .myApproval-grid tbody td{padding:10px;border-bottom:1px solid #e5e7eb}\n        .num{text - align:right}\n        .empty{text - align:center;padding:20px}\n        .btnPrimary{padding:8px 14px;border:0;border-radius:8px;background:#111827;color:#fff;font-weight:700;cursor:pointer}\n\n        /* ===== NEW: Pagination styles (minimal, matching your look) ===== */\n        .myApproval-paginationRow{display:flex;align-items:center;gap:12px;justify-content:space-between;margin:10px}\n        .myApproval-pageInfo{color:#374151}\n        .myApproval-pagerButtons{display:flex;align-items:center;gap:10px}\n        .btnPager{padding:6px 10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;color:#111827;cursor:pointer}\n        .btnPager:disabled{opacity:0.5;cursor:not-allowed}\n        .myApproval-pageCurrent{color:#4b5563}\n        ";
exports.default = InitiatorLanding;
//# sourceMappingURL=InitiatorLanding.js.map