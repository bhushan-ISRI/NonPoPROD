"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.APTeamAcceptance = void 0;
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var sp_1 = require("@pnp/sp");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/site-users/web");
var newspcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/newspcrudops"));
require("./CSS/NewRequest.scss");
var sona_comstarlogo_png_1 = tslib_1.__importDefault(require("../../assets/sona-comstarlogo.png"));
var react_2 = require("@fluentui/react");
var react_router_dom_2 = require("react-router-dom");
var APTeamAcceptance = function (props) {
    var navigate = (0, react_router_dom_2.useNavigate)();
    var id = (0, react_router_dom_1.useParams)().id;
    var _a = react_1.default.useState(), RequestDate = _a[0], setRequestDate = _a[1];
    var _b = react_1.default.useState(), EmployeeName = _b[0], setEmployeeName = _b[1];
    var _c = react_1.default.useState(), Divison = _c[0], setDivison = _c[1];
    var _d = react_1.default.useState(), Email = _d[0], setEmail = _d[1];
    var _e = react_1.default.useState(), HOD = _e[0], setHOD = _e[1];
    var _f = react_1.default.useState(), Department = _f[0], setDepartment = _f[1];
    var _g = react_1.default.useState(), EmpStatus = _g[0], setEmpStatus = _g[1];
    var _h = react_1.default.useState(), Status = _h[0], setStatus = _h[1];
    var _j = (0, react_1.useState)(false), isSubmitting = _j[0], setIsSubmitting = _j[1];
    var _k = react_1.default.useState([]), ApprovalMatrixdata = _k[0], setApprovalMatrix = _k[1];
    var _l = react_1.default.useState([]), WorkflowHistory = _l[0], setWorkflowHistory = _l[1];
    var _m = react_1.default.useState(null), GLDescription = _m[0], setGLDescription = _m[1];
    var _o = react_1.default.useState(null), CostCenterDescription = _o[0], setCostCenterDescription = _o[1];
    var _p = react_1.default.useState(null), NatureOfExpItems = _p[0], setNatureOfExpItems = _p[1];
    var _q = react_1.default.useState(null), CostCenterMaster = _q[0], setCostCenterMaster = _q[1];
    //const [NatureOfExpItems, setNatureOfExpItems] = React.useState<any[]>([]);
    var _r = (0, react_1.useState)(), ItemID = _r[0], setItemID = _r[1];
    var _s = (0, react_1.useState)(), ExpItem = _s[0], setExpItem = _s[1];
    //   (item.NatureofExpense.Id);
    var _t = react_1.default.useState(""), Comment = _t[0], setComment = _t[1];
    var _u = react_1.default.useState([]), GLCodeItems = _u[0], setGLCodeItems = _u[1];
    var _v = react_1.default.useState([]), masterItems = _v[0], setmasterItems = _v[1];
    var _w = react_1.default.useState([]), GLCodeOptions = _w[0], setGLCodeOptions = _w[1];
    //const [selectedGLCode, setSelectedGLCode] =
    var _x = react_1.default.useState(""), selectedGLCode = _x[0], setSelectedGLCode = _x[1];
    // const [selectedGLCode, setSelectedGLCode] = React.useState<string | number>();
    var _y = react_1.default.useState([]), CostCenterOptions = _y[0], setCostCenterOptions = _y[1];
    //const [selectedCostCenter, setSelectedCostCenter] = React.useState<string | number>();
    var _z = (0, react_1.useState)(), selectedCostCenter = _z[0], setSelectedCostCenter = _z[1];
    var _0 = react_1.default.useState(null), WorkflowJSX = _0[0], setWorkflowJSX = _0[1];
    var _1 = react_1.default.useState(0), Stage = _1[0], setStageData = _1[1];
    //const [GLCodeValue, setGLCodeValue] = React.useState<any[]>([]);
    var _2 = react_1.default.useState(""), GLCodeValue = _2[0], setGLCodeValue = _2[1];
    var _3 = react_1.default.useState(""), CostCenterValue = _3[0], setCostCenterValue = _3[1];
    var _4 = react_1.default.useState([]), ExpenseTypemMastervalues = _4[0], setExpenseTypemMastervalues = _4[1];
    var _5 = (0, react_1.useState)(), requestNo = _5[0], setrequestNo = _5[1]; // useState<string | undefined>(undefined);
    var _6 = react_1.default.useState(), contactNo = _6[0], setcontactNo = _6[1];
    var _7 = react_1.default.useState(), Location = _7[0], setLocation = _7[1];
    var _8 = react_1.default.useState(""), RMVal = _8[0], setRMVal = _8[1];
    var _9 = react_1.default.useState(""), VendorCode = _9[0], setVendorCode = _9[1];
    var _10 = react_1.default.useState(""), VendorName = _10[0], setVendorName = _10[1];
    var _11 = react_1.default.useState(""), NatureExpense = _11[0], setNatureExpense = _11[1];
    var _12 = react_1.default.useState(""), InvoiceNo = _12[0], setInvoiceNo = _12[1];
    var _13 = react_1.default.useState(""), InvoiceDate = _13[0], setInvoiceDate = _13[1];
    var _14 = react_1.default.useState(""), BasicAmount = _14[0], setBasicAmount = _14[1];
    var _15 = react_1.default.useState(""), PayRemark = _15[0], setPayRemark = _15[1];
    var _16 = react_1.default.useState(""), GSTAmt = _16[0], setGSTAmt = _16[1];
    var _17 = react_1.default.useState(""), otherCharges = _17[0], setotherCharges = _17[1];
    var _18 = react_1.default.useState(""), TotalAmount = _18[0], setTotalAmount = _18[1];
    var _19 = (0, react_1.useState)([]), existingFiles = _19[0], setExistingFiles = _19[1];
    var _20 = (0, react_1.useState)(false), loadingExisting = _20[0], setLoadingExisting = _20[1];
    // useEffect(() => {
    //     if (id) {
    //         loadItem(Number(id));
    //     }
    // }, [id]);
    react_1.default.useEffect(function () {
        if (ApprovalMatrixdata.length > 0) {
            displayWorkflow();
        }
    }, [ApprovalMatrixdata]);
    var displayWorkflow = function (matrix) {
        var data = matrix || ApprovalMatrixdata;
        var wf = [];
        var isActive;
        var notActive = false;
        data.forEach(function (m, i) {
            if (!notActive && Stage !== 99) {
                if (Stage === i) {
                    isActive = 'activeApprover';
                    notActive = true;
                }
                else {
                    isActive = 'beforeactiveApprover';
                }
            }
            else {
                isActive = 'overrideStage';
            }
            wf.push(react_1.default.createElement("ul", { className: "main-menu", key: i },
                react_1.default.createElement("li", { className: "".concat(m.Role, " ").concat(isActive).trim() }, m.User)));
        });
        setWorkflowJSX(wf);
    };
    function getData() {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                        return [4 /*yield*/, sp.web.lists
                                .getByTitle("ExpenseMaster")
                                .items
                                .select("ID", "Title", "GLCode", "CostCenter", "Status", "ExpenseType", "GLDescription")
                                .top(100)()];
                    case 1:
                        items = _a.sent();
                        console.log(items);
                        setExpenseTypemMastervalues(items);
                        // IMPORTANT
                        return [2 /*return*/, items];
                }
            });
        });
    }
    // useEffect(() => {
    //     getData();
    // }, []);
    (0, react_1.useEffect)(function () {
        loadInitialData();
    }, []);
    var loadInitialData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var expenseMasterData;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getData()];
                case 1:
                    expenseMasterData = _a.sent();
                    if (!id) return [3 /*break*/, 3];
                    return [4 /*yield*/, loadItem(Number(id), expenseMasterData)];
                case 2:
                    _a.sent();
                    _a.label = 3;
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var th = {
        textAlign: "left",
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontWeight: 700,
        fontSize: 13,
    };
    var td = {
        padding: "8px 10px",
        borderBottom: "1px solid #e5e7eb",
        fontSize: 13,
    };
    var loadItem = function (itemId, expenseMasterData) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, item_1, Empitems, emp, EmpId, invDate, parsedApprovalMatrix, parsedWorkflowHistory, filteredGLCode, options, costCenteritems, options1, error_1;
        var _a, _b, _c;
        return tslib_1.__generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    _d.trys.push([0, 5, , 6]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("ID,Title,GLDescription,CostCenterDescription,RequestDate,CostCentre,Stage,EmployeeName,ApprovalMatrix,WorkflowHistory,Email,ContactNo,Division,Department,Location,RM,HOD,EmployeeStatus,ApprovalMatrix,VendorName,InvoiceNumber,InvoiceDate,Basicamount,GST,OtherCharges,Totalamount,WorkflowHistory,Status,PaymentRemarks,ApprovalRemarks,VendorCode/VendorCode,VendorCode/Id,VendorCode/Title,NatureofExpense/Title,NatureofExpense/ExpenseType,NatureofExpense/Id,CurrentApprover/ID,CurrentApprover/EMail,CurrentApprover/Title")
                            .expand("VendorCode,NatureofExpense,CurrentApprover")()];
                case 1:
                    item_1 = _d.sent();
                    console.log(item_1);
                    setItemID(itemId);
                    setrequestNo(item_1.Title || "");
                    setPayRemark(item_1.PaymentRemarks || "");
                    setExpItem(item_1.NatureofExpense.Id);
                    setStageData(item_1.Stage || "");
                    setStatus(item_1.Status || "");
                    setRMVal((_a = item_1.RM) !== null && _a !== void 0 ? _a : "");
                    setLocation(item_1.Location || "");
                    setRequestDate(item_1.RequestDate ? new Date(item_1.RequestDate).toLocaleDateString("en-GB") : "");
                    setEmployeeName(item_1.EmployeeName || "");
                    setDivison(item_1.Division || "");
                    setEmail(item_1.Email || "");
                    setHOD(item_1.HOD || "");
                    setCostCenterValue(item_1.CostCentre || "");
                    setDepartment(item_1.Department || "");
                    setEmpStatus(item_1.EmployeeStatus || "");
                    setcontactNo(item_1.ContactNo || "");
                    setVendorCode(item_1.VendorCode.VendorCode || "");
                    setVendorName(item_1.VendorName || "");
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items
                            .filter("EmployeeName eq '".concat(item_1.EmployeeName, "'"))
                            .select("*,Employee/Title,Employee/Id")
                            .expand("Employee")()];
                case 2:
                    Empitems = _d.sent();
                    emp = Empitems[0];
                    EmpId = ((_b = emp === null || emp === void 0 ? void 0 : emp.Employee) === null || _b === void 0 ? void 0 : _b.Id) || "";
                    //  setCostCenterValue(Empitems[0].CostCenter);
                    //  setCostCenterDescription(Empitems[0].CostCenterDescription)
                    setInvoiceNo(item_1.InvoiceNumber || "");
                    invDate = new Date(item_1.InvoiceDate || "").toISOString().split("T")[0];
                    setInvoiceDate(invDate);
                    setBasicAmount(item_1.Basicamount || "");
                    setGSTAmt(item_1.GST || "");
                    setotherCharges(item_1.OtherCharges || "");
                    setTotalAmount(item_1.Totalamount || "");
                    parsedApprovalMatrix = [];
                    if (item_1.ApprovalMatrix) {
                        try {
                            parsedApprovalMatrix = JSON.parse(item_1.ApprovalMatrix);
                        }
                        catch (parseError) {
                            console.error("Error parsing ApprovalMatrix JSON:", parseError);
                        }
                    }
                    setApprovalMatrix(parsedApprovalMatrix);
                    return [4 /*yield*/, loadFinalNonPoFile(item_1.Title)];
                case 3:
                    _d.sent();
                    parsedWorkflowHistory = [];
                    if (item_1.WorkflowHistory) {
                        try {
                            parsedWorkflowHistory = JSON.parse(item_1.WorkflowHistory);
                        }
                        catch (parseError) {
                            console.error("Error parsing WorkflowHistory JSON:", parseError);
                        }
                    }
                    setWorkflowHistory(parsedWorkflowHistory);
                    // GL code :dropdown
                    setNatureExpense(((_c = item_1.NatureofExpense) === null || _c === void 0 ? void 0 : _c.ExpenseType) || "");
                    filteredGLCode = expenseMasterData.filter(function (m) {
                        var _a;
                        return m.ExpenseType ===
                            ((_a = item_1.NatureofExpense) === null || _a === void 0 ? void 0 : _a.ExpenseType);
                    });
                    console.log("FILTERED", filteredGLCode);
                    options = expenseMasterData.map(function (x) { return ({
                        key: x.GLCode,
                        text: x.GLCode
                    }); });
                    setGLCodeOptions(options);
                    // // Bind selected value
                    setSelectedGLCode(filteredGLCode[0].GLCode);
                    setGLDescription(filteredGLCode[0].GLDescription);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CostCentreMaster")
                            .items
                            .select("ID", "CostCentre", "CostCentreDescription")()];
                case 4:
                    costCenteritems = _d.sent();
                    setCostCenterMaster(costCenteritems);
                    options1 = costCenteritems.map(function (x) { return ({
                        key: x.CostCentre,
                        text: x.CostCentre
                    }); });
                    setCostCenterOptions(options1);
                    return [3 /*break*/, 6];
                case 5:
                    error_1 = _d.sent();
                    console.log(error_1);
                    return [3 /*break*/, 6];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    var toFolderName = function (requestNo) {
        return (requestNo || "NONPO")
            .replace(/[\\#%&*:{?<>|"]/g, "_") // removed /
            .replace(/\//g, "-")
            .trim();
    };
    var loadFinalNonPoFile = function (requestNo) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, origin_1, absUrl, libTitle, libFiles, root, rootUrl, folderPath, files, _i, _a, f, error_2, e_1;
        var _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    _e.trys.push([0, 6, 7, 8]);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    origin_1 = window.location.origin;
                    absUrl = ((_d = (_c = (_b = props.currentSPContext) === null || _b === void 0 ? void 0 : _b.pageContext) === null || _c === void 0 ? void 0 : _c.web) === null || _d === void 0 ? void 0 : _d.absoluteUrl) || "";
                    // if (!props.currentSPContext || !requestNo) return;
                    setLoadingExisting(true);
                    libTitle = "NonPODoc";
                    libFiles = [];
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists.getByTitle(libTitle).rootFolder()];
                case 2:
                    root = _e.sent();
                    rootUrl = root.ServerRelativeUrl;
                    folderPath = "".concat(rootUrl, "/").concat(toFolderName(requestNo));
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.select("Name,ServerRelativeUrl,Length,TimeLastModified")()];
                case 3:
                    files = _e.sent();
                    for (_i = 0, _a = files || []; _i < _a.length; _i++) {
                        f = _a[_i];
                        libFiles.push({
                            name: f.Name,
                            url: "".concat(origin_1).concat(f.ServerRelativeUrl),
                            sizeBytes: Number(f.Length || 0),
                            lastModified: f.TimeLastModified,
                            source: "Library",
                            serverRelativeUrl: f.ServerRelativeUrl,
                        });
                    }
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _e.sent();
                    alert("error");
                    return [3 /*break*/, 5];
                case 5:
                    setExistingFiles(tslib_1.__spreadArray([], libFiles, true));
                    return [3 /*break*/, 8];
                case 6:
                    e_1 = _e.sent();
                    console.warn("[APTeamAcceptance] existing docs load failed:", e_1);
                    setExistingFiles([]);
                    return [3 /*break*/, 8];
                case 7:
                    setLoadingExisting(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    var handleSendback = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var itemId, spCrudOps, sp, currentUser_1, item, approvalMatrix, updatedIndex, currentItem, currentRole, currentLevel, normalizeId, formattedDateed, updatedApprovalMatrix, now, formattedDate, workflowHistory, newHistoryEntry, updatedHistory, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 5, 6, 7]);
                    if (!Comment || Comment.trim() === "") {
                        alert("Please enter a comment before sending back.");
                        return [2 /*return*/];
                    }
                    setIsSubmitting(true);
                    if (!id)
                        return [2 /*return*/];
                    itemId = Number(id);
                    return [4 /*yield*/, (0, newspcrudops_1.default)(props)];
                case 1:
                    spCrudOps = _a.sent();
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 2:
                    currentUser_1 = _a.sent();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("*")()];
                case 3:
                    item = _a.sent();
                    approvalMatrix = [];
                    approvalMatrix = JSON.parse(item.ApprovalMatrix || "[]");
                    updatedIndex = approvalMatrix.findIndex(function (x) {
                        return parseInt(x.UserID) === currentUser_1.Id && x.Role === "APPerformer";
                    });
                    currentItem = approvalMatrix.find(function (x) {
                        return String(x.UserID) === String(currentUser_1.Id) && x.Role === "APPerformer";
                    });
                    currentRole = currentItem.Role;
                    currentLevel = currentItem.Level;
                    normalizeId = function (id) { return parseInt(id); };
                    formattedDateed = new Date().toISOString();
                    if (currentItem !== -1) {
                        approvalMatrix[updatedIndex] = tslib_1.__assign(tslib_1.__assign({}, approvalMatrix[updatedIndex]), { Status: "Send Back", Comment: Comment, ActionDate: formattedDateed });
                    }
                    updatedApprovalMatrix = JSON.stringify(approvalMatrix);
                    now = new Date();
                    formattedDate = new Date().toISOString();
                    workflowHistory = tslib_1.__spreadArray([], WorkflowHistory, true);
                    newHistoryEntry = {
                        CurrentApprover: currentUser_1.Title,
                        ActionTaken: "".concat(currentRole, " Send Back"),
                        Comment: Comment || "",
                        Date: formattedDate,
                        CurrentStatus: 'Send Back'
                    };
                    workflowHistory.push(newHistoryEntry);
                    setWorkflowHistory(workflowHistory);
                    updatedHistory = JSON.stringify(workflowHistory);
                    // const Empitems = await sp.web.lists
                    //     .getByTitle("EmployeeMaster")
                    //     .items
                    //     .filter(`EmployeeName eq '${item.EmployeeName}'`)
                    //     .select("*,Employee/Title,Employee/Id")
                    //     .expand("Employee")();
                    // const emp = Empitems[0];
                    // const EmpId = emp?.Employee?.Id || "";
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(Number(id))
                            .update({
                            Status: "Send Back",
                            PendingAt: 'Pending At Initiator',
                            CurrentApproverId: null,
                            WorkflowHistory: updatedHistory,
                            ApprovalMatrix: updatedApprovalMatrix,
                            CostCentre: CostCenterValue,
                            GLCode: GLCodeValue
                        })];
                case 4:
                    // const Empitems = await sp.web.lists
                    //     .getByTitle("EmployeeMaster")
                    //     .items
                    //     .filter(`EmployeeName eq '${item.EmployeeName}'`)
                    //     .select("*,Employee/Title,Employee/Id")
                    //     .expand("Employee")();
                    // const emp = Empitems[0];
                    // const EmpId = emp?.Employee?.Id || "";
                    _a.sent();
                    alert("AP team SendBack successfully.");
                    setComment("");
                    navigate('/APTeam');
                    return [3 /*break*/, 7];
                case 5:
                    error_3 = _a.sent();
                    console.error(error_3);
                    alert("Something went wrong.");
                    return [3 /*break*/, 7];
                case 6:
                    setIsSubmitting(false);
                    return [7 /*endfinally*/];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var itemId, spCrudOps, sp, currentUser_2, item, approvalMatrix, updatedIndex1, currentItem, currentRole, currentLevel, normalizeId, formattedDateed, updatedApprovalMatrix, now, formattedDate, workflowHistory, newHistoryEntry, updatedHistory, natureExpID, updateFields, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (isSubmitting)
                        return [2 /*return*/];
                    console.log(selectedGLCode);
                    if (!selectedGLCode) {
                        alert("Please select the GL code");
                        return [2 /*return*/];
                    }
                    console.log(NatureOfExpItems);
                    if (!CostCenterValue) {
                        alert("Please select the Cost center");
                        return [2 /*return*/];
                    }
                    if (!Comment || Comment.trim() === "") {
                        alert("Please enter a comment");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 6, 7, 8]);
                    itemId = Number(id);
                    return [4 /*yield*/, (0, newspcrudops_1.default)(props)];
                case 2:
                    spCrudOps = _a.sent();
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 3:
                    currentUser_2 = _a.sent();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("*")()];
                case 4:
                    item = _a.sent();
                    approvalMatrix = [];
                    approvalMatrix = JSON.parse(item.ApprovalMatrix || "[]");
                    updatedIndex1 = approvalMatrix.findIndex(function (x) {
                        return parseInt(x.UserID) === currentUser_2.Id && x.Role === "APPerformer";
                    });
                    currentItem = approvalMatrix.find(function (x) {
                        return parseInt(x.UserID) === (currentUser_2.Id) && x.Role === "APPerformer";
                    });
                    currentRole = currentItem.Role;
                    currentLevel = currentItem.Level;
                    normalizeId = function (id) { return parseInt(id); };
                    formattedDateed = new Date().toISOString();
                    if (currentItem !== -1) {
                        approvalMatrix[updatedIndex1] = tslib_1.__assign(tslib_1.__assign({}, approvalMatrix[updatedIndex1]), { Status: "Pending for Vouching", Comment: Comment, ActionDate: formattedDateed });
                    }
                    updatedApprovalMatrix = JSON.stringify(approvalMatrix);
                    now = new Date();
                    formattedDate = new Date().toISOString();
                    workflowHistory = tslib_1.__spreadArray([], WorkflowHistory, true);
                    newHistoryEntry = {
                        CurrentApprover: currentUser_2.Title,
                        ActionTaken: "".concat(currentRole, " Approved"),
                        Comment: Comment || "",
                        Date: formattedDate,
                        CurrentStatus: 'Pending for Vouching'
                    };
                    workflowHistory.push(newHistoryEntry);
                    setWorkflowHistory(workflowHistory);
                    updatedHistory = JSON.stringify(workflowHistory);
                    natureExpID = void 0;
                    if (NatureOfExpItems != null) {
                        natureExpID = NatureOfExpItems.Id;
                    }
                    else {
                        natureExpID = ExpItem;
                    }
                    updateFields = {};
                    updateFields = {
                        Status: "Pending for Vouching",
                        PendingAt: currentUser_2.Title,
                        ApproverStatus: "Pending for Vouching",
                        //Stage: updatedIndex + 1,
                        CurrentApproverId: currentUser_2.Id,
                        WorkflowHistory: updatedHistory,
                        ApprovalMatrix: updatedApprovalMatrix,
                        CostCentre: CostCenterValue,
                        GLCode: selectedGLCode, // GLCodeValue,
                        // NatureofExpenseId: NatureOfExpItems.Id,
                        NatureofExpenseId: natureExpID,
                        GLDescription: GLDescription,
                        CostCenterDescription: CostCenterDescription
                    };
                    // =====================================
                    // UPDATE SHAREPOINT ITEM
                    // =====================================
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .update(updateFields)];
                case 5:
                    // =====================================
                    // UPDATE SHAREPOINT ITEM
                    // =====================================
                    _a.sent();
                    // =====================================
                    // SUCCESS
                    // =====================================
                    alert("Request successfully approved by the ".concat(currentRole));
                    setComment("");
                    navigate('/APTeam');
                    return [3 /*break*/, 8];
                case 6:
                    error_4 = _a.sent();
                    console.error(error_4);
                    alert("Approval failed");
                    return [3 /*break*/, 8];
                case 7:
                    setIsSubmitting(false);
                    return [7 /*endfinally*/];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    var handleReject = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var itemId, sp, currentUser_3, item, approvalMatrix, currentIndex, currentRole, formattedDate, updatedApprovalMatrix, workflowHistory, newHistoryEntry, updatedHistory, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 4, 5, 6]);
                    if (!Comment || Comment.trim() === "") {
                        alert("Please enter a comment before Reject.");
                        return [2 /*return*/];
                    }
                    setIsSubmitting(true);
                    itemId = Number(id);
                    sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(props.currentSPContext));
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    currentUser_3 = _a.sent();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .select("*")()];
                case 2:
                    item = _a.sent();
                    approvalMatrix = [];
                    try {
                        approvalMatrix = JSON.parse(item.ApprovalMatrix || "[]");
                    }
                    catch (_b) {
                        alert("Invalid Approval Matrix");
                        return [2 /*return*/];
                    }
                    currentIndex = approvalMatrix.findIndex(function (x) {
                        return parseInt(x.UserID) === currentUser_3.Id;
                    });
                    if (currentIndex === -1) {
                        alert("You are not authorized");
                        return [2 /*return*/];
                    }
                    currentRole = approvalMatrix[currentIndex].Role;
                    formattedDate = new Date().toISOString();
                    approvalMatrix[currentIndex] = tslib_1.__assign(tslib_1.__assign({}, approvalMatrix[currentIndex]), { Status: "Rejected", Comment: Comment, ActionDate: formattedDate });
                    updatedApprovalMatrix = JSON.stringify(approvalMatrix);
                    workflowHistory = [];
                    try {
                        workflowHistory = JSON.parse(item.WorkflowHistory || "[]");
                    }
                    catch (_c) {
                        workflowHistory = [];
                    }
                    newHistoryEntry = {
                        CurrentApprover: currentUser_3.Title,
                        ActionTaken: "".concat(currentRole, " Rejected"),
                        Comment: Comment,
                        Date: formattedDate,
                        CurrentStatus: "Rejected"
                    };
                    workflowHistory.push(newHistoryEntry);
                    updatedHistory = JSON.stringify(workflowHistory);
                    // =====================================
                    // ✅ UPDATE SHAREPOINT ITEM
                    // =====================================
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("NonPO")
                            .items.getById(itemId)
                            .update({
                            Status: "Rejected",
                            ApproverStatus: "Rejected",
                            WorkflowHistory: updatedHistory,
                            ApprovalMatrix: updatedApprovalMatrix
                        })];
                case 3:
                    // =====================================
                    // ✅ UPDATE SHAREPOINT ITEM
                    // =====================================
                    _a.sent();
                    // =====================================
                    // ✅ SUCCESS
                    // =====================================
                    alert("Request rejected by ".concat(currentRole));
                    setComment("");
                    // ✅ Dynamic redirect
                    //  history.push(`/${currentRole}Dashboard`);
                    navigate('/APTeam');
                    return [3 /*break*/, 6];
                case 4:
                    error_5 = _a.sent();
                    console.error("Error while rejecting:", error_5);
                    alert("Something went wrong while rejecting.");
                    return [3 /*break*/, 6];
                case 5:
                    setIsSubmitting(false);
                    return [7 /*endfinally*/];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    var handleOpenFile = function (url) {
        window.open(url, "_blank", "noopener,noreferrer");
    };
    // ✅ UI must return something
    return (react_1.default.createElement("div", { className: 'MainUplodForm', style: { margin: "0px" } },
        react_1.default.createElement("div", { className: 'row' },
            react_1.default.createElement("div", { className: 'col-md-12' },
                react_1.default.createElement("div", { className: 'Main-Boxpoup' },
                    react_1.default.createElement("div", { className: "bordered" },
                        react_1.default.createElement("img", { src: sona_comstarlogo_png_1.default }),
                        react_1.default.createElement("h1", null, "Non PO Approval ")),
                    react_1.default.createElement("div", { className: 'displayWF' }, WorkflowJSX),
                    react_1.default.createElement("div", { className: 'borderedbox' },
                        react_1.default.createElement("div", { className: "heading1" },
                            react_1.default.createElement("label", null, "Requestor Information")),
                        react_1.default.createElement("div", { className: 'main-formcontainer' },
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Request Date : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        RequestDate)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "Employee Name  : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        EmployeeName)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "Email : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        Email))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "Contact No : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        contactNo)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Department : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        Department)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "Division : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        Divison))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Location : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        Location)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "RM : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        RMVal)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "HOD : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        HOD))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Employee Status : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        EmpStatus)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Status", className: 'font fontblock' }, "Status : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        Status)))),
                        react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                            react_1.default.createElement("label", null, "Invoice Details")),
                        react_1.default.createElement("div", { className: 'main-formcontainer' },
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Employee Code", className: 'font fontblock' }, "Vendor Code : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        VendorCode)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Employee Name", className: 'font fontblock' }, "Vendor Name  : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        VendorName)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Contact No", className: 'font fontblock' }, "Nature of Expense : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        NatureExpense))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Employee Status", className: 'font fontblock' }, "Invoice No : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        InvoiceNo)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "Location", className: 'font fontblock' }, "Invoice Date : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        InvoiceDate)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Basic Amount : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        BasicAmount))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "GST Amount : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        GSTAmt)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Other Charges (If any): : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        otherCharges)),
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Total Amount : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        TotalAmount))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-4' },
                                    react_1.default.createElement("label", { htmlFor: "RM", className: 'font fontblock' }, "Remarks for NON-PO Expense : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        PayRemark)))),
                        react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                            react_1.default.createElement("label", null, "Attached Documents")),
                        react_1.default.createElement("div", { className: 'main-formcontainer' },
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: 'col-md-12' }, loadingExisting ? (react_1.default.createElement("div", { className: "text-muted" }, "Loading documents\u2026")) : existingFiles.length === 0 ? (react_1.default.createElement("div", { style: { color: "#6b7280" } }, "No documents available.")) : (react_1.default.createElement("div", { style: { overflowX: "auto" } },
                                    react_1.default.createElement("table", { style: { width: "100%", borderCollapse: "collapse" } },
                                        react_1.default.createElement("thead", null,
                                            react_1.default.createElement("tr", { style: { background: "#f8fafc" } },
                                                react_1.default.createElement("th", { style: th }, "File"),
                                                react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 140 }) }, "Size"),
                                                react_1.default.createElement("th", { style: tslib_1.__assign(tslib_1.__assign({}, th), { width: 120 }) }, "Action"))),
                                        react_1.default.createElement("tbody", null, existingFiles.map(function (f) { return (react_1.default.createElement("tr", { key: "".concat(f.source, "-").concat(f.name) },
                                            react_1.default.createElement("td", { style: td },
                                                react_1.default.createElement("a", { onClick: function () { return handleOpenFile(f.url); }, style: { color: "#0a66c2" } }, f.name)),
                                            react_1.default.createElement("td", { style: tslib_1.__assign({}, td) }, f.sizeBytes ? "".concat((f.sizeBytes / (1024 * 1024)).toFixed(2), " MB") : "—"),
                                            react_1.default.createElement("td", { style: td },
                                                react_1.default.createElement("a", { className: "btn btn-sm btn-outline-primary", href: f.url, target: "_blank", rel: "noreferrer" }, "Download")))); })))))))),
                        react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                            react_1.default.createElement("label", null, "Work Flow History")),
                        react_1.default.createElement("div", { className: "main-formcontainer" },
                            react_1.default.createElement("div", { className: 'Workflowbox' }, WorkflowHistory && WorkflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "workflow-table", style: { width: '100%', borderCollapse: 'collapse' } },
                                react_1.default.createElement("thead", null,
                                    react_1.default.createElement("tr", null,
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Date"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action By"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Action Taken"),
                                        react_1.default.createElement("th", { style: { padding: '8px', textAlign: 'left' } }, "Comment"))),
                                react_1.default.createElement("tbody", null, WorkflowHistory.map(function (h, idx) { return (react_1.default.createElement("tr", { key: idx },
                                    react_1.default.createElement("td", { style: { padding: '8px' } }, h.Date ? new Date(h.Date).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replace(",", "") : ""),
                                    react_1.default.createElement("td", { style: { padding: '8px' } }, h.CurrentApprover || ''),
                                    react_1.default.createElement("td", { style: { padding: '8px' } }, h.ActionTaken || ''),
                                    react_1.default.createElement("td", { style: { padding: '8px' } }, h.Comment || ''))); })))) : (react_1.default.createElement("p", null, "No workflow history")))),
                        react_1.default.createElement("div", { className: "heading1", style: { marginTop: "10px" } },
                            react_1.default.createElement("label", null, "Remark Section")),
                        react_1.default.createElement("div", { className: "main-formcontainer" },
                            react_1.default.createElement("div", { className: 'row' },
                                react_1.default.createElement("div", { className: 'col-md-3' },
                                    react_1.default.createElement("label", { className: 'font' },
                                        "GL Code ",
                                        react_1.default.createElement("span", { className: 'Mantorystar' }, "*")),
                                    react_1.default.createElement(react_2.Dropdown, { options: GLCodeOptions, selectedKey: selectedGLCode, onChange: function (e, option) {
                                            var glCode = option === null || option === void 0 ? void 0 : option.key;
                                            setSelectedGLCode(glCode);
                                            // Find selected item immediately from state list
                                            var selectedItem = ExpenseTypemMastervalues.find(function (m) { return m.GLCode === glCode; });
                                            console.log(selectedItem);
                                            setNatureOfExpItems(selectedItem);
                                            // Set Nature of Expense
                                            setNatureExpense((selectedItem === null || selectedItem === void 0 ? void 0 : selectedItem.ExpenseType) || "");
                                            setGLDescription((selectedItem === null || selectedItem === void 0 ? void 0 : selectedItem.GLDescription) || "");
                                        } })),
                                react_1.default.createElement("div", { className: 'col-md-3' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "GL Description : \u00A0\u00A0"),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        GLDescription)),
                                react_1.default.createElement("div", { className: 'col-md-3' },
                                    react_1.default.createElement("label", { className: 'font' }, "Cost Center "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        CostCenterValue),
                                    react_1.default.createElement(react_2.Dropdown, { options: CostCenterOptions, selectedKey: selectedCostCenter, onChange: function (e, option) {
                                            var costCode = option === null || option === void 0 ? void 0 : option.key;
                                            setCostCenterValue(costCode);
                                            var selectedItem1 = CostCenterMaster.find(function (m) { return String(m.CostCentre) === String(costCode); });
                                            console.log(selectedItem1);
                                            setCostCenterDescription((selectedItem1 === null || selectedItem1 === void 0 ? void 0 : selectedItem1.CostCentreDescription) || "");
                                        } })),
                                react_1.default.createElement("div", { className: 'col-md-3' },
                                    react_1.default.createElement("label", { className: 'font fontblock' }, "Cost Center Description : \u00A0\u00A0 "),
                                    react_1.default.createElement("label", { className: 'fonttext' },
                                        "  ",
                                        CostCenterDescription))),
                            react_1.default.createElement("div", { className: 'row mb-20' },
                                react_1.default.createElement("div", { className: "col-md-12" },
                                    react_1.default.createElement("label", { className: "font" },
                                        " Remark ",
                                        react_1.default.createElement("span", { className: 'Mantorystar' }, "*")),
                                    react_1.default.createElement("textarea", { className: "form-control", rows: 3, value: Comment, onChange: function (e) { return setComment(e.target.value); }, style: { resize: "none" } })))),
                        react_1.default.createElement("div", { className: 'row my-3' },
                            react_1.default.createElement("div", { className: 'col-md-12' },
                                react_1.default.createElement("div", { style: { display: "flex", justifyContent: "center", gap: "5px" } },
                                    react_1.default.createElement("a", { className: "submit-btn", onClick: function () { return handleApprove(); } }, "Approve"),
                                    react_1.default.createElement("a", { className: "sendback-btn", onClick: function () { return handleSendback(); } }, "Send Back"),
                                    react_1.default.createElement("a", { className: "Reject-btn", onClick: function () { return handleReject(); } }, "Reject"),
                                    react_1.default.createElement("a", { className: "reset-btn", onClick: function () { return navigate("/APTeam"); } }, "Exit"))))))))));
};
exports.APTeamAcceptance = APTeamAcceptance;
//# sourceMappingURL=APTeamAcceptance.js.map