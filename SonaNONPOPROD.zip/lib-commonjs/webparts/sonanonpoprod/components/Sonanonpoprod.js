"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var Sidebar_1 = tslib_1.__importDefault(require("../components/Pages/Sidebar"));
var react_router_dom_1 = require("react-router-dom");
var NonPoRequest_1 = tslib_1.__importDefault(require("./Pages/NonPoRequest"));
var InitiatorLanding_1 = tslib_1.__importDefault(require("./Pages/InitiatorLanding"));
var MyApproval_1 = tslib_1.__importDefault(require("./Pages/MyApproval"));
var NonPoApproval_1 = require("./Pages/NonPoApproval");
//import NonPoApproval from "./Pages/NonPoApproval";
//import NonPoApproval from "./Pages/NonPoApproval"
var APTeam_1 = tslib_1.__importDefault(require("./Pages/APTeam"));
var APTeamAcceptance_1 = require("./Pages/APTeamAcceptance");
var Vouching_1 = require("./Pages/Vouching");
var InitiatorApproved_1 = require("./Pages/InitiatorApproved");
var InitiatorRejected_1 = require("./Pages/InitiatorRejected");
var InitiatorClosed_1 = require("./Pages/InitiatorClosed");
var MyApprovalApproved_1 = require("./Pages/MyApprovalApproved");
var MyApprovalRejected_1 = require("./Pages/MyApprovalRejected");
var ViewRequest_1 = require("./Pages/ViewRequest");
var PendingforVouching_1 = tslib_1.__importDefault(require("./Pages/PendingforVouching"));
var ClosedRequests_1 = tslib_1.__importDefault(require("./Pages/ClosedRequests"));
var ViewRequestSendBack_1 = require("./Pages/ViewRequestSendBack");
var DrrContent = function (props) {
    var location = (0, react_router_dom_1.useLocation)();
    (0, react_1.useEffect)(function () {
        var leftNav = document.getElementById("spLeftNav");
        if (leftNav) {
            leftNav.style.display = "none";
        }
    }, []);
    var hideSidebar = location.pathname.startsWith("/NonPoRequest") ||
        location.pathname.startsWith("/ViewRequest/") ||
        location.pathname.startsWith("/NonPoApproval/") ||
        location.pathname.startsWith("/ViewMonPo/") ||
        location.pathname.startsWith("/APTeamAcceptance/") ||
        location.pathname.startsWith("/Vouching/") ||
        location.pathname.startsWith("/ViewRequest/") ||
        location.pathname.startsWith("/ViewRequestSendBack/");
    return (React.createElement("div", { className: "container-fluid", style: { display: "flex", width: "100%" } },
        !hideSidebar && React.createElement(Sidebar_1.default, tslib_1.__assign({}, props)),
        React.createElement("div", { className: "main", style: {
                width: hideSidebar ? "100%" : "calc(100% - 250px)",
                transition: "width 0.3s ease"
            } },
            React.createElement(react_router_dom_1.Routes, null,
                React.createElement(react_router_dom_1.Route, { path: "/NonPoRequest", element: React.createElement(NonPoRequest_1.default, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/", element: React.createElement(InitiatorLanding_1.default, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/InitiatorApproved", element: React.createElement(InitiatorApproved_1.InitiatorApproved, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/InitiatorRejected", element: React.createElement(InitiatorRejected_1.InitiatorRejected, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/InitiatorClosed", element: React.createElement(InitiatorClosed_1.InitiatorClosed, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/MyApproval", element: React.createElement(MyApproval_1.default, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "MyApprovalApproved", element: React.createElement(MyApprovalApproved_1.MyApprovalApproved, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/MyApprovalRejected", element: React.createElement(MyApprovalRejected_1.MyApprovalRejected, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/NonPoApproval/:id", element: React.createElement(NonPoApproval_1.NonPoApproval, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/ViewMonPo:id", element: React.createElement(NonPoApproval_1.NonPoApproval, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/APTeam", element: React.createElement(APTeam_1.default, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/APTeamAcceptance/:id", element: React.createElement(APTeamAcceptance_1.APTeamAcceptance, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/APTeam/PendingforVouching", element: React.createElement(PendingforVouching_1.default, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/APTeam/ClosedRequests", element: React.createElement(ClosedRequests_1.default, tslib_1.__assign({}, props)) }),
                "g",
                React.createElement(react_router_dom_1.Route, { path: "/Vouching/:id", element: React.createElement(Vouching_1.Vouching, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/ViewRequest/:id", element: React.createElement(ViewRequest_1.ViewRequest, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "/ViewRequestSendBack/:id", element: React.createElement(ViewRequestSendBack_1.ViewRequestSendBack, tslib_1.__assign({}, props)) }),
                React.createElement(react_router_dom_1.Route, { path: "*", element: React.createElement(react_router_dom_1.Navigate, { to: "/NonPoRequest", replace: true }) })))));
};
var Drr = function (props) { return (React.createElement(react_router_dom_1.HashRouter, null,
    React.createElement(DrrContent, tslib_1.__assign({}, props)))); };
exports.default = Drr;
//# sourceMappingURL=Sonanonpoprod.js.map